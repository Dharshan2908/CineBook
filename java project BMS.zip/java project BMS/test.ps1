Write-Host "========================================================" -ForegroundColor Cyan
Write-Host "Running CineBook Integration Tests..." -ForegroundColor Cyan
Write-Host "========================================================" -ForegroundColor Cyan

& java -cp "bin;lib/*" test.SystemWorkflowTest
