Write-Host "========================================================" -ForegroundColor Cyan
Write-Host "Starting CineBook - Movie Ticket Booking System..." -ForegroundColor Cyan
Write-Host "========================================================" -ForegroundColor Cyan

& java -cp "bin;lib/*" Main
