Write-Host "========================================================" -ForegroundColor Cyan
Write-Host "Compiling CineBook - Movie Ticket Booking System..." -ForegroundColor Cyan
Write-Host "========================================================" -ForegroundColor Cyan

if (-not (Test-Path "bin")) {
    New-Item -ItemType Directory -Path "bin" | Out-Null
}

$sources = Get-ChildItem -Path "src" -Filter "*.java" -Recurse | ForEach-Object { $_.FullName }
& javac -encoding UTF-8 -cp "lib/*" -d bin $sources

if ($LASTEXITCODE -eq 0) {
    Write-Host "Compilation SUCCESSFUL! Binaries compiled into bin/" -ForegroundColor Green
} else {
    Write-Host "Compilation FAILED with exit code $LASTEXITCODE" -ForegroundColor Red
}
