@echo off
echo ========================================================
echo Starting CineBook - Movie Ticket Booking System...
echo ========================================================

java -cp "bin;lib/*" Main

if %ERRORLEVEL% NEQ 0 (
    echo.
    echo Application exited with error code %ERRORLEVEL%.
    pause
)
