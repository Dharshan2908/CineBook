# CineBook — Standalone Desktop Movie Ticket Booking System

A desktop **Movie Ticket Booking System** built with **Java SE (Java 26 / Java 17+)**, **Java Swing**, and **MySQL** via **JDBC**.

---

## 1. Technology Stack

* **Core Language:** Java (Standard Edition SE)
* **GUI Framework:** Java Swing (`JFrame`, `JTabbedPane`, `CardLayout`, `JTable`, `GridBagLayout`, `BorderLayout`, `GridLayout`, `FlowLayout`, etc.)
* **Relational Database:** MySQL 8.0+
* **Database Driver:** MySQL Connector/J 8.3.0 (`lib/mysql-connector-j-8.3.0.jar`)
* **Persistence Mechanism:** Raw JDBC with `PreparedStatement`, `ResultSet`, and ACID Transactions (`setAutoCommit(false)`, `commit()`, `rollback()`)
* **Strict Constraints Followed:** No Spring Boot, No Hibernate, No JPA, No ORM, No web frameworks, No Node/React. Pure standalone desktop Java application.

---

## 2. System Architecture & Project Structure

The project follows a **Tiered Enterprise Architecture** with clear Separation of Concerns (SoC):

```
java project BMS/
├── bin/                             # Compiled bytecode (.class files)
├── database/
│   └── movie_ticket_booking.sql     # Database schema, foreign keys, and seed data
├── lib/
│   └── mysql-connector-j-8.3.0.jar  # Official MySQL JDBC Driver
├── src/
│   ├── model/                       # Domain Entities (OOP Encapsulation)
│   │   ├── Movie.java
│   │   ├── Show.java
│   │   ├── Booking.java
│   │   └── Admin.java
│   │
│   ├── dao/                         # Data Access Object Pattern (JDBC abstraction)
│   │   ├── MovieDAO.java
│   │   ├── MovieDAOImpl.java
│   │   ├── ShowDAO.java
│   │   ├── ShowDAOImpl.java
│   │   ├── BookingDAO.java
│   │   ├── BookingDAOImpl.java
│   │   ├── AdminDAO.java
│   │   └── AdminDAOImpl.java
│   │
│   ├── service/                     # Business Logic & ACID Transaction Management
│   │   └── BookingService.java
│   │
│   ├── util/                        # Helpers and Configuration Singletons
│   │   ├── DatabaseConnection.java  # Connection factory & config management
│   │   ├── DatabaseInitializer.java # Script runner for database auto-setup
│   │   └── ValidationUtil.java      # Input validation & sanitization
│   │
│   ├── gui/                         # Swing Presentation Layer
│   │   ├── UITheme.java             # Design system (palette, fonts, components)
│   │   ├── SeatGridPanel.java       # Visual cinema seat grid layout (A1..E10)
│   │   ├── MoviePanel.java          # View movies and scheduled shows
│   │   ├── BookingPanel.java        # End-to-end seat reservation workflow
│   │   ├── ViewBookingPanel.java    # Search, inspect, and cancel booking
│   │   ├── ModifyBookingPanel.java  # Modify tickets and re-pick seats
│   │   ├── CustomerPanel.java       # Tabbed container for customer modules
│   │   ├── AdminLoginPanel.java     # Secure database authentication
│   │   ├── ManageMoviePanel.java    # Movie CRUD management (Add/Update/Delete)
│   │   ├── ManageShowPanel.java     # Showtimes & Hall capacity management
│   │   ├── ManageBookingPanel.java  # Audit & search all booking records
│   │   ├── SeatAvailabilityPanel.java # Live seat occupancy visualizer
│   │   ├── AdminDashboardPanel.java # KPI metrics & admin container
│   │   ├── DatabaseSettingsDialog.java # Dynamic DB config & 1-click schema init
│   │   └── MainFrame.java           # Main application window & card navigation
│   │
│   └── Main.java                    # Application Entry Point
├── db.properties                    # Database connection properties
├── compile.bat / compile.ps1        # Compilation scripts
├── run.bat / run.ps1                # Launch scripts
└── README.md                        # Documentation & Viva Reference
```

---

## 3. Database Setup & Configuration

### Option A: Automatic 1-Click Initialization (Recommended)
1. Run the application (`run.bat` or `.\run.ps1`).
2. If your MySQL credentials differ from `root` / `root`, click the **"DB Settings"** button in the top-right corner.
3. Enter your MySQL **Username** and **Password**.
4. Click **"Initialize DB Tables"**. The application will automatically execute `database/movie_ticket_booking.sql`, creating the database `movie_booking_db`, all tables, foreign key constraints, and sample movies/shows/admin accounts!
5. Click **"Save & Connect"**. The application is now live.

### Option B: Manual Setup via MySQL Command Line or Workbench
If you prefer running the SQL script manually:
```bash
mysql -u root -p < database/movie_ticket_booking.sql
```
Or open MySQL Workbench, load `database/movie_ticket_booking.sql`, and execute the entire script.

Then check `db.properties` in the project root:
```properties
db.host=localhost
db.port=3306
db.name=movie_booking_db
db.user=root
db.password=YOUR_PASSWORD
```

---

## 4. Default Admin Credentials

* **Username:** `admin`
* **Password:** `admin123`
*(Secondary Admin: `manager` / `manager123`)*

---

## 5. How to Compile and Run

### Using Batch Files (CMD):
```cmd
compile.bat
run.bat
test.bat
```

### Using PowerShell:
```powershell
.\compile.ps1
.\run.ps1
.\test.ps1
```

### Manual Command:
```bash
# Compile
javac -encoding UTF-8 -cp "lib/*" -d bin src/model/*.java src/dao/*.java src/service/*.java src/util/*.java src/gui/*.java src/Main.java

# Run
java -cp "bin;lib/*" Main
```

---

## 6. Key Features & Workflows

### 6.1 Customer Portal
1. **View Movies & Schedules:**
   * Browse available movies (Jailer 2, Bethlehem Kudumba Unit, Avengers Endgame, Dude, Paradise, Baththa, Vikram 2) with title, genre, language, and runtime.
   * Selecting any movie retrieves its **full 7-day screening schedule** (Morning, Matinee, Evening, and Night shows across an entire week with prices and live available seats).
   * "Book Selected Show" button directly launches the booking workflow.
2. **Interactive Visual Seat Booking:**
   * Enter customer name and 10-digit phone number.
   * Select ticket count.
   * Visual theater seating grid with **Cinema Screen** banner and interactive seat buttons (`A1` to `E10`):
     * **Green:** Available
     * **Blue:** Selected by user
     * **Grayed/Disabled:** Already reserved by other customers
   * Strict validation ensures selected seats match ticket count before booking.
   * Real-time price calculation (`tickets × show price`).
   * Displays formal booking confirmation receipt with unique `Booking ID`.
3. **View & Track Booking:**
   * Search by `Booking ID`.
   * Displays comprehensive details, status (`CONFIRMED` or `CANCELLED`), and booking timestamp.
4. **Modify Booking:**
   * Customer can update their name, phone, ticket quantity, and re-select seats.
   * **Smart Seat Release:** The customer's current seats temporarily become available for re-selection, while other customers' seats remain locked.
   * Real-time recalculation of total payable amount.
5. **Cancel Booking:**
   * Confirmation prompt prevents accidental cancellation.
   * Soft-delete via `status = 'CANCELLED'`.
   * Seats are immediately freed for subsequent bookings while preserving booking history.

### 6.2 Admin Portal
1. **Database Authentication:** Secure login screen verified against the `admin` table.
2. **Dashboard Overview:** Live KPI counters querying MySQL:
   * Total Movies
   * Total Scheduled Shows
   * Total Confirmed Bookings
   * Today's Bookings
   * Today's Revenue (₹)
3. **Manage Movies:** Full CRUD (Add, View in `JTable`, Update, Delete with safety checks).
4. **Manage Shows:** Add show with movie dropdown, view schedules in `JTable`, update prices/times, delete with safety checks.
5. **View & Search All Bookings:** Audit table with multi-parameter search (by `Booking ID`, customer name, or movie title).
6. **Seat Availability Visualizer:** Select any movie and show to inspect total seats, booked seats, remaining seats, and the live color-coded seat occupancy map.

---

## 7. Software Engineering & OOP Concepts Explained

### 1. Encapsulation
* Domain models (`Movie`, `Show`, `Booking`, `Admin`) maintain all state fields as `private`.
* Access is provided solely through public getters and setters.
* Enforces data validation and prevents external unauthorized mutations.

### 2. Interface Segregation & Abstraction (DAO Pattern)
* `MovieDAO`, `ShowDAO`, `BookingDAO`, and `AdminDAO` declare clean contracts without exposing SQL queries or JDBC specifics.
* Implementations (`MovieDAOImpl`, `ShowDAOImpl`, etc.) encapsulate all raw SQL queries, `PreparedStatement` parameters, and `ResultSet` mapping.
* The GUI layer has zero direct database imports or raw SQL queries.

### 3. Service Layer Architecture
* `BookingService` acts as the intermediary between the presentation layer and data access layer.
* Coordinates complex workflows, business rules (seat count validation, price calculation), and transactional boundaries.

### 4. ACID Database Transactions
* Critical operations such as booking creation and booking modification execute inside database transactions:
  ```java
  conn.setAutoCommit(false);
  try {
      // 1. Check concurrency / lock seats
      // 2. Insert or update booking
      conn.commit();
  } catch (Exception ex) {
      conn.rollback();
      throw ex;
  }
  ```
* Prevents partial bookings or double-booking race conditions.

### 5. PreparedStatements (SQL Injection Prevention)
* All queries utilize parameterized `PreparedStatement` (`?` placeholders).
* Eliminates SQL injection vulnerabilities and optimizes query execution plans.

---

## 8. Academic Viva Questions & Answers

**Q1: Why did you use the DAO pattern?**
> *Answer:* The DAO (Data Access Object) pattern completely isolates database operations from GUI and business logic. If the database schema or database engine changes, only the DAO implementation needs modification; the GUI and Service classes remain unaffected.

**Q2: How is seat concurrency and double-booking prevented?**
> *Answer:* Within `BookingService.createBooking()`, we disable auto-commit (`conn.setAutoCommit(false)`) and query currently booked seats using `SELECT ... FOR UPDATE` row-level locks before inserting the new booking. If any requested seat is already taken, a rollback is executed and an informative error is returned to the user.

**Q3: Why don't you physically DELETE cancelled bookings?**
> *Answer:* For audit and financial accounting reasons, soft deletion is standard practice. Setting `status = 'CANCELLED'` preserves historical customer transactions while releasing seats back to the available pool.

**Q4: How does the visual seat selection map work?**
> *Answer:* `SeatGridPanel` dynamically renders a grid of `JButton`s corresponding to the show's `total_seats`. Seats present in `bookedSeats` are colored gray/disabled. Unbooked seats are clickable and change to royal blue on selection. The grid enforces a maximum selection limit matching the number of selected tickets.
