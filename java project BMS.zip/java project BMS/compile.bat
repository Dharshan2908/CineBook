@echo off
echo ========================================================
echo Compiling CineBook - Movie Ticket Booking System...
echo ========================================================

if not exist bin mkdir bin

javac -encoding UTF-8 -cp "lib/*" -d bin src/model/*.java src/dao/*.java src/service/*.java src/util/*.java src/gui/*.java src/test/*.java src/Main.java

if %ERRORLEVEL% EQU 0 (
    echo Compilation SUCCESSFUL! Binaries placed in bin/
) else (
    echo Compilation FAILED with error code %ERRORLEVEL%
)
pause
