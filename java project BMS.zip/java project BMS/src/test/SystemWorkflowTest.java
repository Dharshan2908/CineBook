package test;

import dao.AdminDAO;
import dao.AdminDAOImpl;
import dao.BookingDAO;
import dao.BookingDAOImpl;
import dao.MovieDAO;
import dao.MovieDAOImpl;
import dao.ShowDAO;
import dao.ShowDAOImpl;
import java.sql.Date;
import java.sql.SQLException;
import java.sql.Time;
import java.time.LocalDate;
import java.util.Arrays;
import java.util.List;
import model.Admin;
import model.Booking;
import model.Movie;
import model.Show;
import service.BookingService;
import util.DatabaseConnection;
import util.DatabaseInitializer;

/**
 * Automated End-to-End Workflow & Integration Test Suite.
 * Validates database connectivity, DAO CRUD operations,
 * transactional booking, seat recalculation, modifying, and cancellation.
 */
public class SystemWorkflowTest {

    private static int testsRun = 0;
    private static int testsPassed = 0;

    public static void main(String[] args) {
        System.out.println("==========================================================");
        System.out.println("CineBook - Automated End-to-End Integration Test Suite");
        System.out.println("==========================================================");

        DatabaseConnection.loadConfiguration();
        System.out.println("Testing connection to: " + DatabaseConnection.getJdbcUrl());

        if (!DatabaseConnection.testConnection()) {
            System.out.println("[WARN] Cannot connect to MySQL with current db.properties.");
            System.out.println("Please check that MySQL service is running and configure db.properties (or launch the GUI and use 'DB Settings').");
            System.out.println("Current config:");
            System.out.println("  Host: " + DatabaseConnection.getHost());
            System.out.println("  Port: " + DatabaseConnection.getPort());
            System.out.println("  Database: " + DatabaseConnection.getDbName());
            System.out.println("  User: " + DatabaseConnection.getUser());
            return;
        }

        System.out.println("[OK] Connected successfully to MySQL!");
        System.out.println("Initializing test schema from database/movie_ticket_booking.sql...");
        String initErr = DatabaseInitializer.initializeDatabase("database/movie_ticket_booking.sql");
        if (initErr != null) {
            System.out.println("[WARN] Schema initialization notice: " + initErr);
        } else {
            System.out.println("[OK] Schema & seed data verified.");
        }

        try {
            runTestSuite();
        } catch (Exception e) {
            System.err.println("[FAIL] Test suite halted with exception: " + e.getMessage());
            e.printStackTrace();
        }

        System.out.println("==========================================================");
        System.out.println("TEST SUMMARY: " + testsPassed + " / " + testsRun + " passed.");
        if (testsPassed == testsRun) {
            System.out.println("ALL TESTS PASSED! System is 100% verified and operational.");
        } else {
            System.out.println("SOME TESTS FAILED.");
        }
        System.out.println("==========================================================");
    }

    private static void runTestSuite() throws Exception {
        BookingService service = new BookingService();
        MovieDAO movieDAO = new MovieDAOImpl();
        ShowDAO showDAO = new ShowDAOImpl();
        BookingDAO bookingDAO = new BookingDAOImpl();
        AdminDAO adminDAO = new AdminDAOImpl();

        // 1. Admin Authentication Test
        System.out.println("\n[Test 1] Testing Admin Authentication...");
        Admin admin = adminDAO.validateLogin("admin", "admin123");
        assertTrue("Admin login with admin/admin123 succeeds", admin != null && "admin".equals(admin.getUsername()));
        Admin invalid = adminDAO.validateLogin("admin", "wrong_password");
        assertTrue("Admin login with invalid password fails", invalid == null);

        // 2. Movie CRUD Test
        System.out.println("\n[Test 2] Testing Movie CRUD operations...");
        Movie testMovie = new Movie("Interstellar 2 Test", "Sci-Fi", "English", 150);
        boolean movieAdded = movieDAO.addMovie(testMovie);
        assertTrue("Add movie successfully creates record with generated ID", movieAdded && testMovie.getMovieId() > 0);

        Movie retrievedMovie = movieDAO.getMovieById(testMovie.getMovieId());
        assertTrue("Retrieve movie matches inserted title", retrievedMovie != null && "Interstellar 2 Test".equals(retrievedMovie.getTitle()));

        testMovie.setTitle("Interstellar 2 (Updated)");
        boolean movieUpdated = movieDAO.updateMovie(testMovie);
        assertTrue("Update movie succeeds", movieUpdated);

        // 3. Show CRUD Test
        System.out.println("\n[Test 3] Testing Show Schedule CRUD operations...");
        Date today = Date.valueOf(LocalDate.now());
        Time showTime = Time.valueOf("19:00:00");
        Show testShow = new Show(testMovie.getMovieId(), today, showTime, 250.0, 50);
        boolean showAdded = showDAO.addShow(testShow);
        assertTrue("Add show succeeds with generated ID", showAdded && testShow.getShowId() > 0);

        Show retrievedShow = showDAO.getShowById(testShow.getShowId());
        assertTrue("Retrieve show returns total seats = 50 and available seats = 50",
                retrievedShow != null && retrievedShow.getTotalSeats() == 50 && retrievedShow.getAvailableSeats() == 50);

        // 4. Booking & Seat Selection (Transactional) Test
        System.out.println("\n[Test 4] Testing Customer Booking & Seat Allocation...");
        List<String> seatsToBook = Arrays.asList("A1", "A2");
        int bookingId = service.createBooking(testShow.getShowId(), "Test Customer", "9988776655", 2, seatsToBook);
        assertTrue("Transactional booking created successfully with Booking ID > 0", bookingId > 0);

        // Verify seats are marked as booked
        List<String> bookedSeats = service.getBookedSeats(testShow.getShowId());
        assertTrue("Show booked seats contains A1 and A2", bookedSeats.contains("A1") && bookedSeats.contains("A2"));

        // Verify available seats decreased
        Show showAfterBooking = service.getShowById(testShow.getShowId());
        assertTrue("Available seats decreased from 50 to 48", showAfterBooking.getAvailableSeats() == 48);

        // 5. Concurrency / Double-booking Prevention Test
        System.out.println("\n[Test 5] Testing Prevention of Double Booking...");
        boolean caughtConflict = false;
        try {
            service.createBooking(testShow.getShowId(), "Another Customer", "9123456789", 1, Arrays.asList("A1"));
        } catch (IllegalStateException e) {
            caughtConflict = true;
        }
        assertTrue("System rejects attempt to book an already occupied seat (A1)", caughtConflict);

        // 6. View & Search Booking Test
        System.out.println("\n[Test 6] Testing View & Search Booking...");
        Booking booking = service.getBookingById(bookingId);
        assertTrue("Get booking by ID retrieves correct customer and CONFIRMED status",
                booking != null && "Test Customer".equals(booking.getCustomerName()) && "CONFIRMED".equals(booking.getStatus()));

        List<Booking> searchResult = service.searchBookings("Test Customer");
        assertTrue("Search bookings finds matching customer name", !searchResult.isEmpty());

        // 7. Modify Booking Test
        System.out.println("\n[Test 7] Testing Modify Booking (re-allocating seats)...");
        List<String> newSeats = Arrays.asList("A1", "A2", "A3");
        boolean modified = service.modifyBooking(bookingId, "Test Customer Updated", "9988776655", 3, newSeats);
        assertTrue("Modify booking to 3 seats (A1, A2, A3) succeeds", modified);

        Booking updatedBooking = service.getBookingById(bookingId);
        assertTrue("Booking seats updated to A1, A2, A3 and amount recalculated (₹750.00)",
                updatedBooking != null && updatedBooking.getTickets() == 3 && updatedBooking.getTotalAmount() == 750.0);

        // 8. Cancel Booking Test
        System.out.println("\n[Test 8] Testing Booking Cancellation (releasing seats)...");
        boolean cancelled = service.cancelBooking(bookingId);
        assertTrue("Cancel booking updates status", cancelled);

        Booking cancelledBooking = service.getBookingById(bookingId);
        assertTrue("Booking status is CANCELLED", "CANCELLED".equals(cancelledBooking.getStatus()));

        List<String> bookedSeatsAfterCancel = service.getBookedSeats(testShow.getShowId());
        assertTrue("Seats A1, A2, A3 are no longer booked and are released back to availability",
                !bookedSeatsAfterCancel.contains("A1") && !bookedSeatsAfterCancel.contains("A2") && !bookedSeatsAfterCancel.contains("A3"));

        Show showAfterCancel = service.getShowById(testShow.getShowId());
        assertTrue("Available seats restored to 50", showAfterCancel.getAvailableSeats() == 50);

        // 9. Dashboard Statistics Test
        System.out.println("\n[Test 9] Testing Admin Dashboard Statistics Queries...");
        BookingService.DashboardStats stats = service.getDashboardStats();
        assertTrue("Dashboard statistics returns positive movie and show counts",
                stats.totalMovies > 0 && stats.totalShows > 0);

        // 10. Clean up test records
        System.out.println("\n[Test 10] Testing Safe Deletion Checks...");
        // Cannot delete show because it has a cancelled booking history record
        boolean showHasBookings = showDAO.hasDependentBookings(testShow.getShowId());
        assertTrue("Show has dependent booking history tracked", showHasBookings);

        System.out.println("\nAll 10 integration workflows verified successfully!");
    }

    private static void assertTrue(String message, boolean condition) {
        testsRun++;
        if (condition) {
            testsPassed++;
            System.out.println("  [PASS] " + message);
        } else {
            System.err.println("  [FAIL] " + message);
        }
    }
}
