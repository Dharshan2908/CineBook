package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import model.Show;
import util.DatabaseConnection;

/**
 * JDBC Implementation of ShowDAO.
 */
public class ShowDAOImpl implements ShowDAO {

    @Override
    public boolean addShow(Show show) throws SQLException {
        String sql = "INSERT INTO shows (movie_id, show_date, show_time, price, total_seats) VALUES (?, ?, ?, ?, ?)";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            ps.setInt(1, show.getMovieId());
            ps.setDate(2, show.getShowDate());
            ps.setTime(3, show.getShowTime());
            ps.setDouble(4, show.getPrice());
            ps.setInt(5, show.getTotalSeats());

            int affectedRows = ps.executeUpdate();
            if (affectedRows > 0) {
                try (ResultSet rs = ps.getGeneratedKeys()) {
                    if (rs.next()) {
                        show.setShowId(rs.getInt(1));
                    }
                }
                return true;
            }
            return false;
        }
    }

    @Override
    public Show getShowById(int showId) throws SQLException {
        String sql = "SELECT s.show_id, s.movie_id, m.title AS movie_title, s.show_date, s.show_time, "
                   + "s.price, s.total_seats, "
                   + "(s.total_seats - COALESCE((SELECT SUM(b.tickets) FROM bookings b WHERE b.show_id = s.show_id AND b.status = 'CONFIRMED'), 0)) AS available_seats "
                   + "FROM shows s "
                   + "JOIN movies m ON s.movie_id = m.movie_id "
                   + "WHERE s.show_id = ?";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, showId);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    return mapRow(rs);
                }
            }
        }
        return null;
    }

    @Override
    public List<Show> getAllShows() throws SQLException {
        List<Show> list = new ArrayList<>();
        String sql = "SELECT s.show_id, s.movie_id, m.title AS movie_title, s.show_date, s.show_time, "
                   + "s.price, s.total_seats, "
                   + "(s.total_seats - COALESCE((SELECT SUM(b.tickets) FROM bookings b WHERE b.show_id = s.show_id AND b.status = 'CONFIRMED'), 0)) AS available_seats "
                   + "FROM shows s "
                   + "JOIN movies m ON s.movie_id = m.movie_id "
                   + "ORDER BY s.show_date ASC, s.show_time ASC";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {
            while (rs.next()) {
                list.add(mapRow(rs));
            }
        }
        return list;
    }

    @Override
    public List<Show> getShowsByMovieId(int movieId) throws SQLException {
        List<Show> list = new ArrayList<>();
        String sql = "SELECT s.show_id, s.movie_id, m.title AS movie_title, s.show_date, s.show_time, "
                   + "s.price, s.total_seats, "
                   + "(s.total_seats - COALESCE((SELECT SUM(b.tickets) FROM bookings b WHERE b.show_id = s.show_id AND b.status = 'CONFIRMED'), 0)) AS available_seats "
                   + "FROM shows s "
                   + "JOIN movies m ON s.movie_id = m.movie_id "
                   + "WHERE s.movie_id = ? "
                   + "ORDER BY s.show_date ASC, s.show_time ASC";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, movieId);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    list.add(mapRow(rs));
                }
            }
        }
        return list;
    }

    @Override
    public boolean updateShow(Show show) throws SQLException {
        String sql = "UPDATE shows SET movie_id = ?, show_date = ?, show_time = ?, price = ?, total_seats = ? WHERE show_id = ?";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, show.getMovieId());
            ps.setDate(2, show.getShowDate());
            ps.setTime(3, show.getShowTime());
            ps.setDouble(4, show.getPrice());
            ps.setInt(5, show.getTotalSeats());
            ps.setInt(6, show.getShowId());

            return ps.executeUpdate() > 0;
        }
    }

    @Override
    public boolean deleteShow(int showId) throws SQLException {
        String sql = "DELETE FROM shows WHERE show_id = ?";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, showId);
            return ps.executeUpdate() > 0;
        }
    }

    @Override
    public boolean hasDependentBookings(int showId) throws SQLException {
        String sql = "SELECT COUNT(*) FROM bookings WHERE show_id = ?";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, showId);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    return rs.getInt(1) > 0;
                }
            }
        }
        return false;
    }

    @Override
    public int getBookedSeatsCount(int showId) throws SQLException {
        String sql = "SELECT COALESCE(SUM(tickets), 0) FROM bookings WHERE show_id = ? AND status = 'CONFIRMED'";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, showId);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    return rs.getInt(1);
                }
            }
        }
        return 0;
    }

    @Override
    public int getAvailableSeatsCount(int showId) throws SQLException {
        Show show = getShowById(showId);
        if (show == null) {
            return 0;
        }
        return show.getAvailableSeats();
    }

    private Show mapRow(ResultSet rs) throws SQLException {
        Show show = new Show(
                rs.getInt("show_id"),
                rs.getInt("movie_id"),
                rs.getDate("show_date"),
                rs.getTime("show_time"),
                rs.getDouble("price"),
                rs.getInt("total_seats")
        );
        show.setMovieTitle(rs.getString("movie_title"));
        show.setAvailableSeats(Math.max(0, rs.getInt("available_seats")));
        return show;
    }
}
