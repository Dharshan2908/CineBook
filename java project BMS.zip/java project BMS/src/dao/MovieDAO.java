package dao;

import java.sql.SQLException;
import java.util.List;
import model.Movie;

/**
 * Data Access Object (DAO) interface for Movie entity.
 * Defines standard CRUD operations for movies.
 */
public interface MovieDAO {
    boolean addMovie(Movie movie) throws SQLException;
    Movie getMovieById(int movieId) throws SQLException;
    List<Movie> getAllMovies() throws SQLException;
    boolean updateMovie(Movie movie) throws SQLException;
    boolean deleteMovie(int movieId) throws SQLException;
    boolean hasDependentShows(int movieId) throws SQLException;
}
