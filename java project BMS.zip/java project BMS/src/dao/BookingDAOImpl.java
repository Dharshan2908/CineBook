package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import model.Booking;
import util.DatabaseConnection;

/**
 * JDBC Implementation of BookingDAO.
 * Manages bookings, transactional seat queries, and admin dashboard metrics.
 */
public class BookingDAOImpl implements BookingDAO {

    @Override
    public int addBooking(Booking booking) throws SQLException {
        String sql = "INSERT INTO bookings (show_id, customer_name, phone, tickets, seats, total_amount, status) "
                   + "VALUES (?, ?, ?, ?, ?, ?, ?)";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            ps.setInt(1, booking.getShowId());
            ps.setString(2, booking.getCustomerName());
            ps.setString(3, booking.getPhone());
            ps.setInt(4, booking.getTickets());
            ps.setString(5, booking.getSeats());
            ps.setDouble(6, booking.getTotalAmount());
            ps.setString(7, booking.getStatus() != null ? booking.getStatus() : "CONFIRMED");

            int affectedRows = ps.executeUpdate();
            if (affectedRows > 0) {
                try (ResultSet rs = ps.getGeneratedKeys()) {
                    if (rs.next()) {
                        int generatedId = rs.getInt(1);
                        booking.setBookingId(generatedId);
                        return generatedId;
                    }
                }
            }
            return -1;
        }
    }

    @Override
    public Booking getBookingById(int bookingId) throws SQLException {
        String sql = "SELECT b.booking_id, b.show_id, b.customer_name, b.phone, b.tickets, b.seats, "
                   + "b.total_amount, b.booking_date, b.status, "
                   + "m.title AS movie_title, s.show_date, s.show_time "
                   + "FROM bookings b "
                   + "JOIN shows s ON b.show_id = s.show_id "
                   + "JOIN movies m ON s.movie_id = m.movie_id "
                   + "WHERE b.booking_id = ?";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, bookingId);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    return mapRow(rs);
                }
            }
        }
        return null;
    }

    @Override
    public List<Booking> getAllBookings() throws SQLException {
        List<Booking> list = new ArrayList<>();
        String sql = "SELECT b.booking_id, b.show_id, b.customer_name, b.phone, b.tickets, b.seats, "
                   + "b.total_amount, b.booking_date, b.status, "
                   + "m.title AS movie_title, s.show_date, s.show_time "
                   + "FROM bookings b "
                   + "JOIN shows s ON b.show_id = s.show_id "
                   + "JOIN movies m ON s.movie_id = m.movie_id "
                   + "ORDER BY b.booking_id DESC";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {
            while (rs.next()) {
                list.add(mapRow(rs));
            }
        }
        return list;
    }

    @Override
    public List<Booking> searchBookings(String query) throws SQLException {
        List<Booking> list = new ArrayList<>();
        if (query == null || query.trim().isEmpty()) {
            return getAllBookings();
        }
        String trimmed = query.trim();

        String sql = "SELECT b.booking_id, b.show_id, b.customer_name, b.phone, b.tickets, b.seats, "
                   + "b.total_amount, b.booking_date, b.status, "
                   + "m.title AS movie_title, s.show_date, s.show_time "
                   + "FROM bookings b "
                   + "JOIN shows s ON b.show_id = s.show_id "
                   + "JOIN movies m ON s.movie_id = m.movie_id "
                   + "WHERE CAST(b.booking_id AS CHAR) = ? "
                   + "   OR LOWER(b.customer_name) LIKE LOWER(?) "
                   + "   OR LOWER(m.title) LIKE LOWER(?) "
                   + "ORDER BY b.booking_id DESC";

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, trimmed);
            ps.setString(2, "%" + trimmed + "%");
            ps.setString(3, "%" + trimmed + "%");

            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    list.add(mapRow(rs));
                }
            }
        }
        return list;
    }

    @Override
    public boolean updateBooking(Booking booking) throws SQLException {
        String sql = "UPDATE bookings SET customer_name = ?, phone = ?, tickets = ?, seats = ?, total_amount = ? "
                   + "WHERE booking_id = ?";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, booking.getCustomerName());
            ps.setString(2, booking.getPhone());
            ps.setInt(3, booking.getTickets());
            ps.setString(4, booking.getSeats());
            ps.setDouble(5, booking.getTotalAmount());
            ps.setInt(6, booking.getBookingId());

            return ps.executeUpdate() > 0;
        }
    }

    @Override
    public boolean cancelBooking(int bookingId) throws SQLException {
        String sql = "UPDATE bookings SET status = 'CANCELLED' WHERE booking_id = ?";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, bookingId);
            return ps.executeUpdate() > 0;
        }
    }

    @Override
    public List<String> getBookedSeatsForShow(int showId) throws SQLException {
        return getBookedSeatsForShowExcludingBooking(showId, -1);
    }

    @Override
    public List<String> getBookedSeatsForShowExcludingBooking(int showId, int excludedBookingId) throws SQLException {
        List<String> bookedSeats = new ArrayList<>();
        String sql = "SELECT seats FROM bookings WHERE show_id = ? AND status = 'CONFIRMED' AND booking_id != ?";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, showId);
            ps.setInt(2, excludedBookingId);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    String seatStr = rs.getString("seats");
                    if (seatStr != null && !seatStr.trim().isEmpty()) {
                        String[] parts = seatStr.split(",");
                        for (String part : parts) {
                            String trimmedSeat = part.trim().toUpperCase();
                            if (!trimmedSeat.isEmpty() && !bookedSeats.contains(trimmedSeat)) {
                                bookedSeats.add(trimmedSeat);
                            }
                        }
                    }
                }
            }
        }
        Collections.sort(bookedSeats);
        return bookedSeats;
    }

    @Override
    public int getTotalMoviesCount() throws SQLException {
        String sql = "SELECT COUNT(*) FROM movies";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {
            if (rs.next()) {
                return rs.getInt(1);
            }
        }
        return 0;
    }

    @Override
    public int getTotalShowsCount() throws SQLException {
        String sql = "SELECT COUNT(*) FROM shows";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {
            if (rs.next()) {
                return rs.getInt(1);
            }
        }
        return 0;
    }

    @Override
    public int getTotalBookingsCount() throws SQLException {
        String sql = "SELECT COUNT(*) FROM bookings WHERE status = 'CONFIRMED'";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {
            if (rs.next()) {
                return rs.getInt(1);
            }
        }
        return 0;
    }

    @Override
    public int getTodayBookingsCount() throws SQLException {
        String sql = "SELECT COUNT(*) FROM bookings WHERE DATE(booking_date) = CURDATE() AND status = 'CONFIRMED'";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {
            if (rs.next()) {
                return rs.getInt(1);
            }
        }
        return 0;
    }

    @Override
    public double getTodayRevenue() throws SQLException {
        String sql = "SELECT COALESCE(SUM(total_amount), 0.0) FROM bookings WHERE DATE(booking_date) = CURDATE() AND status = 'CONFIRMED'";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {
            if (rs.next()) {
                return rs.getDouble(1);
            }
        }
        return 0.0;
    }

    private Booking mapRow(ResultSet rs) throws SQLException {
        Booking booking = new Booking(
                rs.getInt("booking_id"),
                rs.getInt("show_id"),
                rs.getString("customer_name"),
                rs.getString("phone"),
                rs.getInt("tickets"),
                rs.getString("seats"),
                rs.getDouble("total_amount"),
                rs.getTimestamp("booking_date"),
                rs.getString("status")
        );
        booking.setMovieTitle(rs.getString("movie_title"));
        booking.setShowDate(rs.getDate("show_date"));
        booking.setShowTime(rs.getTime("show_time"));
        return booking;
    }
}
