package dao;

import java.sql.SQLException;
import java.util.List;
import model.Show;

/**
 * Data Access Object (DAO) interface for Show entity.
 * Handles show scheduling, queries, and capacity calculations.
 */
public interface ShowDAO {
    boolean addShow(Show show) throws SQLException;
    Show getShowById(int showId) throws SQLException;
    List<Show> getAllShows() throws SQLException;
    List<Show> getShowsByMovieId(int movieId) throws SQLException;
    boolean updateShow(Show show) throws SQLException;
    boolean deleteShow(int showId) throws SQLException;
    boolean hasDependentBookings(int showId) throws SQLException;
    int getBookedSeatsCount(int showId) throws SQLException;
    int getAvailableSeatsCount(int showId) throws SQLException;
}
