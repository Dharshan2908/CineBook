package dao;

import java.sql.SQLException;
import model.Admin;

/**
 * Data Access Object (DAO) interface for Admin operations.
 */
public interface AdminDAO {
    Admin validateLogin(String username, String password) throws SQLException;
    boolean addAdmin(Admin admin) throws SQLException;
}
