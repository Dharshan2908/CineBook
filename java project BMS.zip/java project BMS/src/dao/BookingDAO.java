package dao;

import java.sql.SQLException;
import java.util.List;
import model.Booking;

/**
 * Data Access Object (DAO) interface for Booking operations.
 */
public interface BookingDAO {
    int addBooking(Booking booking) throws SQLException;
    Booking getBookingById(int bookingId) throws SQLException;
    List<Booking> getAllBookings() throws SQLException;
    List<Booking> searchBookings(String query) throws SQLException;
    boolean updateBooking(Booking booking) throws SQLException;
    boolean cancelBooking(int bookingId) throws SQLException;

    List<String> getBookedSeatsForShow(int showId) throws SQLException;
    List<String> getBookedSeatsForShowExcludingBooking(int showId, int excludedBookingId) throws SQLException;

    // Dashboard Statistics Queries
    int getTotalMoviesCount() throws SQLException;
    int getTotalShowsCount() throws SQLException;
    int getTotalBookingsCount() throws SQLException;
    int getTodayBookingsCount() throws SQLException;
    double getTodayRevenue() throws SQLException;
}
