package service;

import dao.AdminDAO;
import dao.AdminDAOImpl;
import dao.BookingDAO;
import dao.BookingDAOImpl;
import dao.MovieDAO;
import dao.MovieDAOImpl;
import dao.ShowDAO;
import dao.ShowDAOImpl;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import model.Admin;
import model.Booking;
import model.Movie;
import model.Show;
import util.DatabaseConnection;

/**
 * Service Layer for business logic, validations, calculations,
 * and database transaction management.
 */
public class BookingService {

    private final MovieDAO movieDAO;
    private final ShowDAO showDAO;
    private final BookingDAO bookingDAO;
    private final AdminDAO adminDAO;

    public BookingService() {
        this.movieDAO = new MovieDAOImpl();
        this.showDAO = new ShowDAOImpl();
        this.bookingDAO = new BookingDAOImpl();
        this.adminDAO = new AdminDAOImpl();
    }

    // Constructor injection for testability
    public BookingService(MovieDAO movieDAO, ShowDAO showDAO, BookingDAO bookingDAO, AdminDAO adminDAO) {
        this.movieDAO = movieDAO;
        this.showDAO = showDAO;
        this.bookingDAO = bookingDAO;
        this.adminDAO = adminDAO;
    }

    // ==========================================
    // MOVIE OPERATIONS
    // ==========================================

    public List<Movie> getAllMovies() throws SQLException {
        return movieDAO.getAllMovies();
    }

    public Movie getMovieById(int movieId) throws SQLException {
        return movieDAO.getMovieById(movieId);
    }

    public boolean addMovie(String title, String genre, String language, int duration) throws SQLException {
        Movie movie = new Movie(title, genre, language, duration);
        return movieDAO.addMovie(movie);
    }

    public boolean updateMovie(int movieId, String title, String genre, String language, int duration) throws SQLException {
        Movie movie = new Movie(movieId, title, genre, language, duration);
        return movieDAO.updateMovie(movie);
    }

    public boolean deleteMovie(int movieId) throws SQLException {
        if (movieDAO.hasDependentShows(movieId)) {
            throw new IllegalStateException("Cannot delete movie: It has scheduled shows. Delete or reassign those shows first.");
        }
        return movieDAO.deleteMovie(movieId);
    }

    // ==========================================
    // SHOW OPERATIONS
    // ==========================================

    public List<Show> getAllShows() throws SQLException {
        return showDAO.getAllShows();
    }

    public List<Show> getShowsByMovieId(int movieId) throws SQLException {
        return showDAO.getShowsByMovieId(movieId);
    }

    public Show getShowById(int showId) throws SQLException {
        return showDAO.getShowById(showId);
    }

    public boolean addShow(int movieId, java.sql.Date showDate, java.sql.Time showTime, double price, int totalSeats) throws SQLException {
        Show show = new Show(movieId, showDate, showTime, price, totalSeats);
        return showDAO.addShow(show);
    }

    public boolean updateShow(int showId, int movieId, java.sql.Date showDate, java.sql.Time showTime, double price, int totalSeats) throws SQLException {
        Show show = new Show(showId, movieId, showDate, showTime, price, totalSeats);
        return showDAO.updateShow(show);
    }

    public boolean deleteShow(int showId) throws SQLException {
        if (showDAO.hasDependentBookings(showId)) {
            throw new IllegalStateException("Cannot delete show: Existing customer bookings depend on this show.");
        }
        return showDAO.deleteShow(showId);
    }

    // ==========================================
    // SEAT & BOOKING OPERATIONS (TRANSACTIONAL)
    // ==========================================

    public List<String> getBookedSeats(int showId) throws SQLException {
        return bookingDAO.getBookedSeatsForShow(showId);
    }

    public List<String> getBookedSeatsExcludingBooking(int showId, int excludedBookingId) throws SQLException {
        return bookingDAO.getBookedSeatsForShowExcludingBooking(showId, excludedBookingId);
    }

    /**
     * Confirms and creates a booking within a safe JDBC database transaction.
     * Validates ticket count, seat availability, and recalculates total amount.
     */
    public int createBooking(int showId, String customerName, String phone, int tickets, List<String> selectedSeats) throws SQLException {
        if (selectedSeats == null || selectedSeats.size() != tickets) {
            throw new IllegalArgumentException("Selected seat count (" + (selectedSeats == null ? 0 : selectedSeats.size()) 
                    + ") does not match number of tickets (" + tickets + ").");
        }

        Show show = showDAO.getShowById(showId);
        if (show == null) {
            throw new IllegalArgumentException("Show not found for ID: " + showId);
        }

        double totalAmount = tickets * show.getPrice();
        String seatsString = String.join(", ", selectedSeats);

        // Transaction handling
        try (Connection conn = DatabaseConnection.getConnection()) {
            conn.setAutoCommit(false);
            try {
                // 1. Double-check seat availability in transaction
                List<String> currentlyBooked = new ArrayList<>();
                String checkSql = "SELECT seats FROM bookings WHERE show_id = ? AND status = 'CONFIRMED' FOR UPDATE";
                try (PreparedStatement ps = conn.prepareStatement(checkSql)) {
                    ps.setInt(1, showId);
                    try (ResultSet rs = ps.executeQuery()) {
                        while (rs.next()) {
                            String s = rs.getString("seats");
                            if (s != null) {
                                for (String seat : s.split(",")) {
                                    currentlyBooked.add(seat.trim().toUpperCase());
                                }
                            }
                        }
                    }
                }

                for (String requestedSeat : selectedSeats) {
                    if (currentlyBooked.contains(requestedSeat.toUpperCase())) {
                        throw new IllegalStateException("Seat " + requestedSeat + " was just booked by another customer. Please select another seat.");
                    }
                }

                // 2. Insert booking
                int generatedId = -1;
                String insertSql = "INSERT INTO bookings (show_id, customer_name, phone, tickets, seats, total_amount, status) VALUES (?, ?, ?, ?, ?, ?, 'CONFIRMED')";
                try (PreparedStatement ps = conn.prepareStatement(insertSql, PreparedStatement.RETURN_GENERATED_KEYS)) {
                    ps.setInt(1, showId);
                    ps.setString(2, customerName.trim());
                    ps.setString(3, phone.trim());
                    ps.setInt(4, tickets);
                    ps.setString(5, seatsString);
                    ps.setDouble(6, totalAmount);

                    int affected = ps.executeUpdate();
                    if (affected > 0) {
                        try (ResultSet rs = ps.getGeneratedKeys()) {
                            if (rs.next()) {
                                generatedId = rs.getInt(1);
                            }
                        }
                    }
                }

                if (generatedId <= 0) {
                    throw new SQLException("Failed to generate booking ID.");
                }

                // Commit transaction
                conn.commit();
                return generatedId;
            } catch (Exception ex) {
                conn.rollback();
                throw ex;
            } finally {
                conn.setAutoCommit(true);
            }
        }
    }

    /**
     * Modifies an existing booking. Re-evaluates ticket count, new seats,
     * and recalculates the total amount.
     */
    public boolean modifyBooking(int bookingId, String customerName, String phone, int newTickets, List<String> newSeats) throws SQLException {
        Booking existing = bookingDAO.getBookingById(bookingId);
        if (existing == null) {
            throw new IllegalArgumentException("Booking not found with ID: " + bookingId);
        }
        if (!"CONFIRMED".equalsIgnoreCase(existing.getStatus())) {
            throw new IllegalStateException("Cannot modify a cancelled booking.");
        }
        if (newSeats == null || newSeats.size() != newTickets) {
            throw new IllegalArgumentException("Selected seat count (" + (newSeats == null ? 0 : newSeats.size()) 
                    + ") must match the new number of tickets (" + newTickets + ").");
        }

        Show show = showDAO.getShowById(existing.getShowId());
        if (show == null) {
            throw new IllegalStateException("Show information missing for this booking.");
        }

        double newTotalAmount = newTickets * show.getPrice();
        String seatsString = String.join(", ", newSeats);

        // Transaction handling
        try (Connection conn = DatabaseConnection.getConnection()) {
            conn.setAutoCommit(false);
            try {
                // Check if any newly selected seat is booked by someone else
                List<String> bookedByOthers = new ArrayList<>();
                String checkSql = "SELECT seats FROM bookings WHERE show_id = ? AND status = 'CONFIRMED' AND booking_id != ? FOR UPDATE";
                try (PreparedStatement ps = conn.prepareStatement(checkSql)) {
                    ps.setInt(1, existing.getShowId());
                    ps.setInt(2, bookingId);
                    try (ResultSet rs = ps.executeQuery()) {
                        while (rs.next()) {
                            String s = rs.getString("seats");
                            if (s != null) {
                                for (String seat : s.split(",")) {
                                    bookedByOthers.add(seat.trim().toUpperCase());
                                }
                            }
                        }
                    }
                }

                for (String requestedSeat : newSeats) {
                    if (bookedByOthers.contains(requestedSeat.toUpperCase())) {
                        throw new IllegalStateException("Seat " + requestedSeat + " is already reserved by another customer.");
                    }
                }

                // Update booking
                String updateSql = "UPDATE bookings SET customer_name = ?, phone = ?, tickets = ?, seats = ?, total_amount = ? WHERE booking_id = ?";
                try (PreparedStatement ps = conn.prepareStatement(updateSql)) {
                    ps.setString(1, customerName.trim());
                    ps.setString(2, phone.trim());
                    ps.setInt(3, newTickets);
                    ps.setString(4, seatsString);
                    ps.setDouble(5, newTotalAmount);
                    ps.setInt(6, bookingId);

                    int rows = ps.executeUpdate();
                    if (rows <= 0) {
                        throw new SQLException("Failed to update booking record.");
                    }
                }

                conn.commit();
                return true;
            } catch (Exception ex) {
                conn.rollback();
                throw ex;
            } finally {
                conn.setAutoCommit(true);
            }
        }
    }

    /**
     * Cancels an existing booking, marking status = 'CANCELLED'
     * so that its seats become available again while keeping the audit trail.
     */
    public boolean cancelBooking(int bookingId) throws SQLException {
        Booking existing = bookingDAO.getBookingById(bookingId);
        if (existing == null) {
            throw new IllegalArgumentException("Booking not found with ID: " + bookingId);
        }
        if ("CANCELLED".equalsIgnoreCase(existing.getStatus())) {
            throw new IllegalStateException("Booking #" + bookingId + " is already cancelled.");
        }
        return bookingDAO.cancelBooking(bookingId);
    }

    public Booking getBookingById(int bookingId) throws SQLException {
        return bookingDAO.getBookingById(bookingId);
    }

    public List<Booking> getAllBookings() throws SQLException {
        return bookingDAO.getAllBookings();
    }

    public List<Booking> searchBookings(String query) throws SQLException {
        return bookingDAO.searchBookings(query);
    }

    // ==========================================
    // ADMIN AUTHENTICATION & DASHBOARD STATS
    // ==========================================

    public Admin authenticateAdmin(String username, String password) throws SQLException {
        return adminDAO.validateLogin(username, password);
    }

    public DashboardStats getDashboardStats() throws SQLException {
        int movies = bookingDAO.getTotalMoviesCount();
        int shows = bookingDAO.getTotalShowsCount();
        int bookings = bookingDAO.getTotalBookingsCount();
        int todayBookings = bookingDAO.getTodayBookingsCount();
        double todayRevenue = bookingDAO.getTodayRevenue();
        return new DashboardStats(movies, shows, bookings, todayBookings, todayRevenue);
    }

    /**
     * Simple DTO for Dashboard stats.
     */
    public static class DashboardStats {
        public final int totalMovies;
        public final int totalShows;
        public final int totalBookings;
        public final int todayBookings;
        public final double todayRevenue;

        public DashboardStats(int totalMovies, int totalShows, int totalBookings, int todayBookings, double todayRevenue) {
            this.totalMovies = totalMovies;
            this.totalShows = totalShows;
            this.totalBookings = totalBookings;
            this.todayBookings = todayBookings;
            this.todayRevenue = todayRevenue;
        }
    }
}
