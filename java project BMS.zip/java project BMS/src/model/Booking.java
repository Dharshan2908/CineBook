package model;

import java.sql.Timestamp;

/**
 * Model class representing a ticket Booking entity.
 * Holds transactional booking information and associated show/movie details.
 */
public class Booking {
    private int bookingId;
    private int showId;
    private String customerName;
    private String phone;
    private int tickets;
    private String seats; // e.g. "A1, A2"
    private double totalAmount;
    private Timestamp bookingDate;
    private String status; // "CONFIRMED", "CANCELLED"

    // Joined fields for display in tables and reports
    private String movieTitle;
    private java.sql.Date showDate;
    private java.sql.Time showTime;

    public Booking() {
    }

    public Booking(int showId, String customerName, String phone, int tickets, String seats, double totalAmount, String status) {
        this.showId = showId;
        this.customerName = customerName;
        this.phone = phone;
        this.tickets = tickets;
        this.seats = seats;
        this.totalAmount = totalAmount;
        this.status = status;
    }

    public Booking(int bookingId, int showId, String customerName, String phone, int tickets, String seats, double totalAmount, Timestamp bookingDate, String status) {
        this.bookingId = bookingId;
        this.showId = showId;
        this.customerName = customerName;
        this.phone = phone;
        this.tickets = tickets;
        this.seats = seats;
        this.totalAmount = totalAmount;
        this.bookingDate = bookingDate;
        this.status = status;
    }

    public int getBookingId() {
        return bookingId;
    }

    public void setBookingId(int bookingId) {
        this.bookingId = bookingId;
    }

    public int getShowId() {
        return showId;
    }

    public void setShowId(int showId) {
        this.showId = showId;
    }

    public String getCustomerName() {
        return customerName;
    }

    public void setCustomerName(String customerName) {
        this.customerName = customerName;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public int getTickets() {
        return tickets;
    }

    public void setTickets(int tickets) {
        this.tickets = tickets;
    }

    public String getSeats() {
        return seats;
    }

    public void setSeats(String seats) {
        this.seats = seats;
    }

    public double getTotalAmount() {
        return totalAmount;
    }

    public void setTotalAmount(double totalAmount) {
        this.totalAmount = totalAmount;
    }

    public Timestamp getBookingDate() {
        return bookingDate;
    }

    public void setBookingDate(Timestamp bookingDate) {
        this.bookingDate = bookingDate;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getMovieTitle() {
        return movieTitle;
    }

    public void setMovieTitle(String movieTitle) {
        this.movieTitle = movieTitle;
    }

    public java.sql.Date getShowDate() {
        return showDate;
    }

    public void setShowDate(java.sql.Date showDate) {
        this.showDate = showDate;
    }

    public java.sql.Time getShowTime() {
        return showTime;
    }

    public void setShowTime(java.sql.Time showTime) {
        this.showTime = showTime;
    }

    @Override
    public String toString() {
        return "Booking #" + bookingId + " [" + customerName + " - " + movieTitle + " - " + seats + " (" + status + ")]";
    }
}
