package model;

import java.sql.Date;
import java.sql.Time;

/**
 * Model class representing a movie Show/Screening entity.
 * Demonstrates relational association with Movie.
 */
public class Show {
    private int showId;
    private int movieId;
    private String movieTitle; // Joined field for easy display
    private Date showDate;
    private Time showTime;
    private double price;
    private int totalSeats;
    private int availableSeats; // Calculated or dynamically loaded

    public Show() {
    }

    public Show(int movieId, Date showDate, Time showTime, double price, int totalSeats) {
        this.movieId = movieId;
        this.showDate = showDate;
        this.showTime = showTime;
        this.price = price;
        this.totalSeats = totalSeats;
    }

    public Show(int showId, int movieId, Date showDate, Time showTime, double price, int totalSeats) {
        this.showId = showId;
        this.movieId = movieId;
        this.showDate = showDate;
        this.showTime = showTime;
        this.price = price;
        this.totalSeats = totalSeats;
    }

    public int getShowId() {
        return showId;
    }

    public void setShowId(int showId) {
        this.showId = showId;
    }

    public int getMovieId() {
        return movieId;
    }

    public void setMovieId(int movieId) {
        this.movieId = movieId;
    }

    public String getMovieTitle() {
        return movieTitle;
    }

    public void setMovieTitle(String movieTitle) {
        this.movieTitle = movieTitle;
    }

    public Date getShowDate() {
        return showDate;
    }

    public void setShowDate(Date showDate) {
        this.showDate = showDate;
    }

    public Time getShowTime() {
        return showTime;
    }

    public void setShowTime(Time showTime) {
        this.showTime = showTime;
    }

    public double getPrice() {
        return price;
    }

    public void setPrice(double price) {
        this.price = price;
    }

    public int getTotalSeats() {
        return totalSeats;
    }

    public void setTotalSeats(int totalSeats) {
        this.totalSeats = totalSeats;
    }

    public int getAvailableSeats() {
        return availableSeats;
    }

    public void setAvailableSeats(int availableSeats) {
        this.availableSeats = availableSeats;
    }

    @Override
    public String toString() {
        String titleStr = (movieTitle != null && !movieTitle.isEmpty()) ? movieTitle : ("Movie #" + movieId);
        return "Show #" + showId + " - " + titleStr + " [" + showDate + " " + showTime + "] (₹" + price + ")";
    }
}
