package model;

/**
 * Model class representing a Movie entity.
 * Demonstrates encapsulation with private fields, getters, setters,
 * and parameterized constructors.
 */
public class Movie {
    private int movieId;
    private String title;
    private String genre;
    private String language;
    private int duration; // in minutes

    public Movie() {
    }

    public Movie(String title, String genre, String language, int duration) {
        this.title = title;
        this.genre = genre;
        this.language = language;
        this.duration = duration;
    }

    public Movie(int movieId, String title, String genre, String language, int duration) {
        this.movieId = movieId;
        this.title = title;
        this.genre = genre;
        this.language = language;
        this.duration = duration;
    }

    public int getMovieId() {
        return movieId;
    }

    public void setMovieId(int movieId) {
        this.movieId = movieId;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getGenre() {
        return genre;
    }

    public void setGenre(String genre) {
        this.genre = genre;
    }

    public String getLanguage() {
        return language;
    }

    public void setLanguage(String language) {
        this.language = language;
    }

    public int getDuration() {
        return duration;
    }

    public void setDuration(int duration) {
        this.duration = duration;
    }

    @Override
    public String toString() {
        return movieId + " - " + title + " (" + language + ")";
    }
}
