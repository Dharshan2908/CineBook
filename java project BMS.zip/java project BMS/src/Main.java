import gui.MainFrame;
import javax.swing.JOptionPane;
import javax.swing.SwingUtilities;
import javax.swing.UIManager;

/**
 * Entry Point for the Standalone Desktop Movie Ticket Booking System.
 * Initializes Swing GUI on the Event Dispatch Thread (EDT)
 * and sets up standard Look-and-Feel.
 */
public class Main {

    public static void main(String[] args) {
        // Configure Look and Feel for modern appearance
        try {
            for (UIManager.LookAndFeelInfo info : UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (Exception e) {
            try {
                UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
            } catch (Exception ignored) {
            }
        }

        // Global uncaught exception handler
        Thread.setDefaultUncaughtExceptionHandler((thread, throwable) -> {
            System.err.println("Uncaught exception on thread " + thread.getName() + ": " + throwable.getMessage());
            throwable.printStackTrace();
            SwingUtilities.invokeLater(() -> JOptionPane.showMessageDialog(null,
                    "An unexpected error occurred:\n" + throwable.getMessage(),
                    "Application Error", JOptionPane.ERROR_MESSAGE));
        });

        // Launch application on Event Dispatch Thread
        SwingUtilities.invokeLater(() -> {
            try {
                MainFrame frame = new MainFrame();
                frame.setVisible(true);
            } catch (Exception e) {
                JOptionPane.showMessageDialog(null,
                        "Failed to launch application:\n" + e.getMessage(),
                        "Fatal Launch Error", JOptionPane.ERROR_MESSAGE);
            }
        });
    }
}
