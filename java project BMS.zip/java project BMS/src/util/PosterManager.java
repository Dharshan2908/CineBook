package util;

import java.awt.AlphaComposite;
import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Font;
import java.awt.GradientPaint;
import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.RadialGradientPaint;
import java.awt.RenderingHints;
import java.awt.geom.Point2D;
import java.awt.geom.RoundRectangle2D;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import javax.imageio.ImageIO;
import javax.swing.ImageIcon;

/**
 * Manages movie poster assets for CineBook.
 * Automatically generates stunning, high-resolution (300x450) cinematic poster PNG files
 * for all featured movies if not already present on disk in assets/posters/.
 * Allows users to drop their own image files anytime.
 */
public class PosterManager {

    private static final String POSTER_DIR = "assets/posters";
    private static final Map<String, ImageIcon> CACHE = new HashMap<>();

    static {
        ensurePostersExist();
    }

    public static void main(String[] args) {
        System.out.println("Generating cinematic movie posters...");
        ensurePostersExist();
        System.out.println("All posters generated successfully in assets/posters/!");
    }

    /**
     * Normalizes a movie title to a filename slug.
     */
    public static String getSlug(String movieTitle) {
        if (movieTitle == null) return "default";
        String s = movieTitle.toLowerCase().replaceAll("[^a-z0-9]", "_").replaceAll("_+", "_");
        if (s.startsWith("_")) s = s.substring(1);
        if (s.endsWith("_")) s = s.substring(0, s.length() - 1);
        return s;
    }

    /**
     * Gets a scaled ImageIcon for a movie poster.
     */
    public static ImageIcon getPoster(String movieTitle, int width, int height) {
        String slug = getSlug(movieTitle);
        String cacheKey = slug + "_" + width + "x" + height;
        if (CACHE.containsKey(cacheKey)) {
            return CACHE.get(cacheKey);
        }

        File posterFile = new File(POSTER_DIR, slug + ".png");
        if (!posterFile.exists()) {
            generatePoster(movieTitle, posterFile);
        }

        try {
            BufferedImage img = ImageIO.read(posterFile);
            if (img != null) {
                Image scaled = img.getScaledInstance(width, height, Image.SCALE_SMOOTH);
                ImageIcon icon = new ImageIcon(scaled);
                CACHE.put(cacheKey, icon);
                return icon;
            }
        } catch (IOException e) {
            System.err.println("Failed to read poster image for: " + movieTitle + " (" + e.getMessage() + ")");
        }

        return createFallbackIcon(movieTitle, width, height);
    }

    /**
     * Ensures all default posters exist on disk.
     */
    public static void ensurePostersExist() {
        File dir = new File(POSTER_DIR);
        if (!dir.exists()) {
            dir.mkdirs();
        }

        String[] titles = {
                "Jailer 2",
                "Bethlehem Kudumba Unit",
                "Avengers Endgame",
                "Dude",
                "Paradise",
                "Baththa",
                "Vikram 2"
        };

        for (String title : titles) {
            File f = new File(dir, getSlug(title) + ".png");
            if (!f.exists()) {
                generatePoster(title, f);
            }
        }
    }

    /**
     * Programmatically renders an artistic 300x450 poster and writes it to file.
     */
    public static void generatePoster(String title, File outputFile) {
        int w = 300;
        int h = 450;
        BufferedImage img = new BufferedImage(w, h, BufferedImage.TYPE_INT_ARGB);
        Graphics2D g = img.createGraphics();

        g.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        g.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING, RenderingHints.VALUE_TEXT_ANTIALIAS_ON);
        g.setRenderingHint(RenderingHints.KEY_RENDERING, RenderingHints.VALUE_RENDER_QUALITY);

        String slug = getSlug(title);

        // Customize aesthetic palette and motifs based on movie
        Color topC, botC, accentC;
        String ratingText = "★ 9.0/10 15K+ Votes";
        String tagLine = "CINEMA RELEASE";
        String cert = "UA 16+";
        String lang = "TAMIL";

        if (slug.contains("baththa")) {
            topC = new Color(74, 18, 5);      // Deep Crimson Amber
            botC = new Color(20, 8, 4);       // Dark Earth
            accentC = new Color(245, 158, 11);// Golden Amber
            ratingText = "★ 9.2/10 10.9K+ Votes";
            tagLine = "RAGE OF THE SOIL";
            cert = "UA 13+";
            lang = "TAMIL";
        } else if (slug.contains("jailer")) {
            topC = new Color(55, 12, 10);     // Explosive Fiery Maroon
            botC = new Color(15, 10, 15);     // Deep Charcoal
            accentC = new Color(244, 63, 94); // Cinema Rose
            ratingText = "★ 9.5/10 84.2K+ Votes";
            tagLine = "TIGER KA HUKUM";
            cert = "UA 16+";
            lang = "TAMIL";
        } else if (slug.contains("avengers")) {
            topC = new Color(30, 15, 60);     // Cosmic Purple
            botC = new Color(8, 12, 35);      // Deep Space Blue
            accentC = new Color(6, 182, 212); // Electric Cyan
            ratingText = "★ 9.7/10 215K+ Votes";
            tagLine = "WHATEVER IT TAKES";
            cert = "UA 13+";
            lang = "ENGLISH";
        } else if (slug.contains("bethlehem")) {
            topC = new Color(13, 59, 46);     // Lush Kerala Forest
            botC = new Color(10, 25, 20);     // Deep Shaded Green
            accentC = new Color(52, 211, 153);// Emerald Mint
            ratingText = "★ 8.9/10 18.5K+ Votes";
            tagLine = "A WARM FAMILY CELEBRATION";
            cert = "U";
            lang = "MALAYALAM";
        } else if (slug.contains("dude")) {
            topC = new Color(88, 28, 135);    // Vibrant Purple
            botC = new Color(23, 10, 48);     // Midnight Violet
            accentC = new Color(236, 72, 153);// Neon Pink
            ratingText = "★ 8.7/10 14.1K+ Votes";
            tagLine = "COOL. CRAZY. CHAOS.";
            cert = "UA 13+";
            lang = "TAMIL";
        } else if (slug.contains("paradise")) {
            topC = new Color(15, 45, 65);     // Atmospheric Twilight Blue
            botC = new Color(5, 15, 25);      // Deep Abyssal Slate
            accentC = new Color(56, 189, 248);// Sky Blue
            ratingText = "★ 9.1/10 12.8K+ Votes";
            tagLine = "AN UNFORGETTABLE JOURNEY";
            cert = "UA 16+";
            lang = "MALAYALAM";
        } else if (slug.contains("vikram")) {
            topC = new Color(40, 10, 18);     // Gritty Blood Crimson
            botC = new Color(12, 14, 20);     // Matte Gunmetal Navy
            accentC = new Color(239, 68, 68); // Red Laser Crosshair
            ratingText = "★ 9.4/10 76.5K+ Votes";
            tagLine = "ONCE UPON A TIME THERE LIVED A GHOST";
            cert = "A";
            lang = "TAMIL";
        } else {
            topC = new Color(20, 25, 45);
            botC = new Color(10, 12, 22);
            accentC = new Color(99, 102, 241);
        }

        // 1. Background Gradient
        GradientPaint bgGp = new GradientPaint(0, 0, topC, 0, h, botC);
        g.setPaint(bgGp);
        g.fillRect(0, 0, w, h);

        // 2. Cinematic Center Glow / Radial Light
        Point2D center = new Point2D.Float(w / 2f, h * 0.38f);
        float radius = w * 0.75f;
        float[] dist = {0.0f, 0.5f, 1.0f};
        Color[] colors = {
                new Color(accentC.getRed(), accentC.getGreen(), accentC.getBlue(), 90),
                new Color(accentC.getRed(), accentC.getGreen(), accentC.getBlue(), 25),
                new Color(0, 0, 0, 0)
        };
        RadialGradientPaint rgp = new RadialGradientPaint(center, radius, dist, colors);
        g.setPaint(rgp);
        g.fillOval(0, (int) (h * 0.1), w, (int) (h * 0.6));

        // 3. Cinematic Vignette & Abstract Art Silhouette
        g.setColor(new Color(255, 255, 255, 12));
        g.setStroke(new BasicStroke(1.5f));
        g.drawOval(w / 2 - 80, (int) (h * 0.22), 160, 160);
        g.drawOval(w / 2 - 95, (int) (h * 0.20), 190, 190);

        // Center Motif Icon / Stylized Silhouette
        drawMovieEmblem(g, slug, w / 2, (int) (h * 0.38), accentC);

        // 4. Header Badges: Language & Certificate
        g.setColor(new Color(0, 0, 0, 140));
        g.fillRoundRect(14, 14, 60, 22, 10, 10);
        g.setColor(new Color(255, 255, 255, 220));
        g.setFont(new Font("Segoe UI", Font.BOLD, 10));
        g.drawString(cert, 23, 29);

        g.setColor(new Color(0, 0, 0, 140));
        g.fillRoundRect(w - 74, 14, 60, 22, 10, 10);
        g.setColor(accentC);
        g.drawString(lang, w - 64, 29);

        // 5. Lower Content Shading Gradient (for high text contrast)
        GradientPaint lowerShade = new GradientPaint(0, h * 0.55f, new Color(0, 0, 0, 0), 0, h, new Color(10, 12, 18, 250));
        g.setPaint(lowerShade);
        g.fillRect(0, (int) (h * 0.55), w, (int) (h * 0.45));

        // 6. Tagline
        g.setColor(accentC);
        g.setFont(new Font("Segoe UI", Font.BOLD, 9));
        int tagW = g.getFontMetrics().stringWidth(tagLine);
        g.drawString(tagLine, (w - tagW) / 2, h - 110);

        // 7. Movie Title (Bold & Stylized)
        drawStylizedTitle(g, title, w, h - 70, accentC);

        // 8. BookMyShow-style Rating Badge overlay
        int badgeW = 210;
        int badgeH = 26;
        int badgeX = (w - badgeW) / 2;
        int badgeY = h - 40;

        g.setColor(new Color(15, 23, 42, 230));
        g.fillRoundRect(badgeX, badgeY, badgeW, badgeH, 14, 14);
        g.setColor(new Color(244, 63, 94));
        g.setStroke(new BasicStroke(1.2f));
        g.drawRoundRect(badgeX, badgeY, badgeW, badgeH, 14, 14);

        g.setColor(new Color(244, 63, 94));
        g.setFont(new Font("Segoe UI", Font.BOLD, 11));
        g.drawString("★", badgeX + 10, badgeY + 17);

        g.setColor(Color.WHITE);
        g.drawString(ratingText, badgeX + 24, badgeY + 17);

        // 9. Frame Border
        g.setColor(new Color(255, 255, 255, 30));
        g.setStroke(new BasicStroke(1.0f));
        g.drawRoundRect(1, 1, w - 2, h - 2, 8, 8);

        g.dispose();

        // Save PNG to disk
        try {
            if (!outputFile.getParentFile().exists()) {
                outputFile.getParentFile().mkdirs();
            }
            ImageIO.write(img, "PNG", outputFile);
        } catch (IOException e) {
            System.err.println("Could not save poster to " + outputFile.getAbsolutePath() + ": " + e.getMessage());
        }
    }

    private static void drawMovieEmblem(Graphics2D g, String slug, int cx, int cy, Color accent) {
        g.setColor(accent);
        if (slug.contains("avengers")) {
            // Stylized 'A' Emblem
            g.setFont(new Font("Segoe UI", Font.BOLD, 72));
            g.drawString("A", cx - 25, cy + 26);
            g.setStroke(new BasicStroke(3.5f));
            g.drawOval(cx - 45, cy - 45, 90, 90);
            g.drawLine(cx - 50, cy + 5, cx + 50, cy - 10);
        } else if (slug.contains("jailer")) {
            // Crown / Gun silhouette emblem
            g.setFont(new Font("Segoe UI", Font.BOLD, 54));
            g.drawString("⚡", cx - 20, cy + 18);
            g.setFont(new Font("Segoe UI", Font.BOLD, 14));
            g.drawString("1975 • RETRO", cx - 42, cy + 42);
        } else if (slug.contains("baththa")) {
            // Rugged Axe / Shield motif
            g.setFont(new Font("Segoe UI", Font.BOLD, 56));
            g.drawString("🔥", cx - 22, cy + 18);
            g.setFont(new Font("Segoe UI", Font.BOLD, 12));
            g.drawString("PRIDE & BLOOD", cx - 44, cy + 42);
        } else if (slug.contains("vikram")) {
            // Eagle silhouette motif
            g.setFont(new Font("Segoe UI", Font.BOLD, 56));
            g.drawString("🦅", cx - 24, cy + 18);
            g.setFont(new Font("Segoe UI", Font.BOLD, 12));
            g.drawString("GHOST SQUAD", cx - 42, cy + 42);
        } else if (slug.contains("dude")) {
            // Neon Sunglasses
            g.setFont(new Font("Segoe UI", Font.BOLD, 56));
            g.drawString("🕶️", cx - 28, cy + 18);
            g.setFont(new Font("Segoe UI", Font.BOLD, 12));
            g.drawString("PARTY TIME", cx - 36, cy + 42);
        } else if (slug.contains("bethlehem")) {
            // Family & Lantern
            g.setFont(new Font("Segoe UI", Font.BOLD, 54));
            g.drawString("🏡", cx - 24, cy + 18);
            g.setFont(new Font("Segoe UI", Font.BOLD, 12));
            g.drawString("SWEET HOME", cx - 40, cy + 42);
        } else {
            // Scenic Star / Paradise
            g.setFont(new Font("Segoe UI", Font.BOLD, 54));
            g.drawString("✨", cx - 22, cy + 18);
            g.setFont(new Font("Segoe UI", Font.BOLD, 12));
            g.drawString("ESCAPE TO PEACE", cx - 52, cy + 42);
        }
    }

    private static void drawStylizedTitle(Graphics2D g, String title, int w, int y, Color accent) {
        // Multi-line wrap if title is long (like Bethlehem Kudumba Unit)
        String[] words = title.split(" ");
        if (words.length > 2) {
            String l1 = words[0] + " " + words[1];
            StringBuilder l2 = new StringBuilder();
            for (int i = 2; i < words.length; i++) {
                if (l2.length() > 0) l2.append(" ");
                l2.append(words[i]);
            }
            g.setFont(new Font("Segoe UI", Font.BOLD, 22));
            int w1 = g.getFontMetrics().stringWidth(l1.toUpperCase());
            g.setColor(new Color(0, 0, 0, 180));
            g.drawString(l1.toUpperCase(), (w - w1) / 2 + 1, y - 18 + 1);
            g.setColor(Color.WHITE);
            g.drawString(l1.toUpperCase(), (w - w1) / 2, y - 18);

            g.setFont(new Font("Segoe UI", Font.BOLD, 20));
            int w2 = g.getFontMetrics().stringWidth(l2.toString().toUpperCase());
            g.setColor(new Color(0, 0, 0, 180));
            g.drawString(l2.toString().toUpperCase(), (w - w2) / 2 + 1, y + 8 + 1);
            g.setColor(accent);
            g.drawString(l2.toString().toUpperCase(), (w - w2) / 2, y + 8);
        } else {
            g.setFont(new Font("Segoe UI", Font.BOLD, 26));
            int tw = g.getFontMetrics().stringWidth(title.toUpperCase());
            // Shadow
            g.setColor(new Color(0, 0, 0, 200));
            g.drawString(title.toUpperCase(), (w - tw) / 2 + 2, y + 2);
            // Main text
            g.setColor(Color.WHITE);
            g.drawString(title.toUpperCase(), (w - tw) / 2, y);
        }
    }

    private static ImageIcon createFallbackIcon(String title, int w, int h) {
        BufferedImage img = new BufferedImage(w, h, BufferedImage.TYPE_INT_ARGB);
        Graphics2D g = img.createGraphics();
        g.setColor(new Color(30, 41, 59));
        g.fillRect(0, 0, w, h);
        g.setColor(Color.WHITE);
        g.setFont(new Font("Segoe UI", Font.BOLD, 14));
        g.drawString(title, 10, h / 2);
        g.dispose();
        return new ImageIcon(img);
    }
}
