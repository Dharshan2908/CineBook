package util;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Properties;

/**
 * Utility class to manage MySQL JDBC database connections.
 * Follows the Singleton pattern for configuration and provides
 * safe Connection instances across the application.
 */
public class DatabaseConnection {

    private static final String CONFIG_FILE = "db.properties";
    private static String host = "localhost";
    private static int port = 3306;
    private static String dbName = "movie_booking_db";
    private static String user = "root";
    private static String password = "root";

    static {
        // Register MySQL Connector/J driver
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
        } catch (ClassNotFoundException e) {
            System.err.println("MySQL JDBC Driver not found in classpath: " + e.getMessage());
        }
        loadConfiguration();
    }

    private DatabaseConnection() {
        // Private constructor to prevent instantiation
    }

    /**
     * Loads database configuration from db.properties if it exists.
     */
    public static synchronized void loadConfiguration() {
        File file = new File(CONFIG_FILE);
        if (file.exists()) {
            try (InputStream input = new FileInputStream(file)) {
                Properties prop = new Properties();
                prop.load(input);
                host = prop.getProperty("db.host", host).trim();
                port = Integer.parseInt(prop.getProperty("db.port", String.valueOf(port)).trim());
                dbName = prop.getProperty("db.name", dbName).trim();
                user = prop.getProperty("db.user", user).trim();
                password = prop.getProperty("db.password", password).trim();
            } catch (Exception e) {
                System.err.println("Warning: Could not read db.properties, using defaults: " + e.getMessage());
            }
        }
    }

    /**
     * Saves updated configuration to db.properties.
     */
    public static synchronized void saveConfiguration(String newHost, int newPort, String newDbName, String newUser, String newPassword) throws IOException {
        host = newHost;
        port = newPort;
        dbName = newDbName;
        user = newUser;
        password = newPassword;

        Properties prop = new Properties();
        prop.setProperty("db.host", host);
        prop.setProperty("db.port", String.valueOf(port));
        prop.setProperty("db.name", dbName);
        prop.setProperty("db.user", user);
        prop.setProperty("db.password", password);

        try (OutputStream output = new FileOutputStream(CONFIG_FILE)) {
            prop.store(output, "Movie Ticket Booking System - Database Configuration");
        }
    }

    /**
     * Constructs JDBC connection URL.
     */
    public static String getJdbcUrl() {
        return "jdbc:mysql://" + host + ":" + port + "/" + dbName
                + "?useSSL=false&allowPublicKeyRetrieval=true&serverTimezone=UTC&characterEncoding=UTF-8";
    }

    /**
     * Constructs server-level JDBC connection URL (without specific database)
     * used for creating the database if it doesn't exist.
     */
    public static String getServerJdbcUrl() {
        return "jdbc:mysql://" + host + ":" + port
                + "/?useSSL=false&allowPublicKeyRetrieval=true&serverTimezone=UTC&characterEncoding=UTF-8";
    }

    /**
     * Obtains a new database Connection.
     * Callers are responsible for closing the connection.
     *
     * @return Connection to movie_booking_db
     * @throws SQLException if a database access error occurs
     */
    public static Connection getConnection() throws SQLException {
        return DriverManager.getConnection(getJdbcUrl(), user, password);
    }

    /**
     * Tests whether the database connection can be established.
     *
     * @return true if successful, false otherwise
     */
    public static boolean testConnection() {
        try (Connection conn = getConnection()) {
            return conn != null && !conn.isClosed();
        } catch (SQLException e) {
            return false;
        }
    }

    /**
     * Tests connection with custom credentials before saving.
     */
    public static boolean testCustomConnection(String testHost, int testPort, String testDb, String testUser, String testPass) {
        String testUrl = "jdbc:mysql://" + testHost + ":" + testPort + "/" + testDb
                + "?useSSL=false&allowPublicKeyRetrieval=true&serverTimezone=UTC&characterEncoding=UTF-8";
        try (Connection conn = DriverManager.getConnection(testUrl, testUser, testPass)) {
            return conn != null && !conn.isClosed();
        } catch (SQLException e) {
            return false;
        }
    }

    // Getters
    public static String getHost() { return host; }
    public static int getPort() { return port; }
    public static String getDbName() { return dbName; }
    public static String getUser() { return user; }
    public static String getPassword() { return password; }
}
