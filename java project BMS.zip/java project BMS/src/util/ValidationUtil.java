package util;

/**
 * Utility class for validating user inputs across the GUI layers.
 * Provides reusable validation rules and sanitization.
 */
public class ValidationUtil {

    private ValidationUtil() {
    }

    /**
     * Checks if a string is null or empty after trimming.
     */
    public static boolean isEmpty(String str) {
        return str == null || str.trim().isEmpty();
    }

    /**
     * Validates customer name.
     */
    public static boolean isValidName(String name) {
        if (isEmpty(name)) {
            return false;
        }
        String trimmed = name.trim();
        return trimmed.length() >= 2 && trimmed.matches("^[a-zA-Z\\s.'-]+$");
    }

    /**
     * Validates phone number (strictly 10 digits as preferred).
     */
    public static boolean isValidPhone(String phone) {
        if (isEmpty(phone)) {
            return false;
        }
        String trimmed = phone.trim();
        return trimmed.matches("^[0-9]{10}$");
    }

    /**
     * Parses and validates a positive integer (> 0).
     */
    public static boolean isPositiveInteger(String str) {
        if (isEmpty(str)) {
            return false;
        }
        try {
            int val = Integer.parseInt(str.trim());
            return val > 0;
        } catch (NumberFormatException e) {
            return false;
        }
    }

    /**
     * Parses and validates a positive double (> 0.0).
     */
    public static boolean isPositiveDouble(String str) {
        if (isEmpty(str)) {
            return false;
        }
        try {
            double val = Double.parseDouble(str.trim());
            return val > 0.0;
        } catch (NumberFormatException e) {
            return false;
        }
    }

    /**
     * Validates standard date string format (YYYY-MM-DD).
     */
    public static boolean isValidDateFormat(String dateStr) {
        if (isEmpty(dateStr)) {
            return false;
        }
        try {
            java.sql.Date.valueOf(dateStr.trim());
            return true;
        } catch (IllegalArgumentException e) {
            return false;
        }
    }

    /**
     * Validates standard time string format (HH:MM:SS or HH:MM).
     */
    public static boolean isValidTimeFormat(String timeStr) {
        if (isEmpty(timeStr)) {
            return false;
        }
        String trimmed = timeStr.trim();
        if (trimmed.length() == 5) {
            trimmed += ":00";
        }
        try {
            java.sql.Time.valueOf(trimmed);
            return true;
        } catch (IllegalArgumentException e) {
            return false;
        }
    }
}
