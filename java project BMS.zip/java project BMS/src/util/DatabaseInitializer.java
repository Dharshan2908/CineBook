package util;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

/**
 * Utility to initialize the MySQL database schema and seed data.
 * Can be run from GUI settings or standalone.
 */
public class DatabaseInitializer {

    /**
     * Executes the SQL script located at database/movie_ticket_booking.sql.
     * First connects to the MySQL server (without specifying DB) to ensure
     * the database itself exists, then switches to the database.
     *
     * @return Result message or null if successful
     */
    public static String initializeDatabase(String scriptPath) {
        File file = new File(scriptPath);
        if (!file.exists()) {
            return "SQL script file not found at: " + file.getAbsolutePath();
        }

        String serverUrl = DatabaseConnection.getServerJdbcUrl();
        String user = DatabaseConnection.getUser();
        String pass = DatabaseConnection.getPassword();

        // 1. Ensure database exists
        try (Connection serverConn = DriverManager.getConnection(serverUrl, user, pass);
             Statement stmt = serverConn.createStatement()) {
            stmt.executeUpdate("CREATE DATABASE IF NOT EXISTS " + DatabaseConnection.getDbName());
        } catch (SQLException e) {
            return "Failed to connect to MySQL server or create database: " + e.getMessage();
        }

        // 2. Connect to the database and run the script statements
        try (Connection dbConn = DatabaseConnection.getConnection();
             Statement stmt = dbConn.createStatement();
             BufferedReader reader = new BufferedReader(new FileReader(file))) {

            StringBuilder sqlBuilder = new StringBuilder();
            String line;
            while ((line = reader.readLine()) != null) {
                line = line.trim();
                // Skip comments and empty lines
                if (line.isEmpty() || line.startsWith("--") || line.startsWith("//") || line.startsWith("/*")) {
                    continue;
                }
                sqlBuilder.append(line).append(" ");
                if (line.endsWith(";")) {
                    String query = sqlBuilder.toString().trim();
                    // Remove trailing semicolon
                    if (query.endsWith(";")) {
                        query = query.substring(0, query.length() - 1).trim();
                    }
                    if (!query.isEmpty() && !query.toUpperCase().startsWith("CREATE DATABASE") && !query.toUpperCase().startsWith("USE ")) {
                        try {
                            stmt.execute(query);
                        } catch (SQLException ex) {
                            System.err.println("Notice executing SQL statement: " + ex.getMessage());
                        }
                    }
                    sqlBuilder.setLength(0);
                }
            }
            return null; // Success
        } catch (IOException e) {
            return "I/O error reading SQL script: " + e.getMessage();
        } catch (SQLException e) {
            return "Database error executing schema script: " + e.getMessage();
        }
    }
}
