package gui;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.GridLayout;
import java.sql.SQLException;
import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTabbedPane;
import model.Admin;
import service.BookingService;

/**
 * Admin Dashboard Container.
 * Features live KPI metrics and integrated management tabs:
 * 1. Overview & Statistics
 * 2. Manage Movies
 * 3. Manage Shows
 * 4. View & Search Bookings
 * 5. Seat Availability
 * 6. Logout
 */
public class AdminDashboardPanel extends JPanel {

    public interface LogoutListener {
        void onLogout();
    }

    private final BookingService bookingService;
    private final JTabbedPane tabbedPane;
    private final ManageMoviePanel manageMoviePanel;
    private final ManageShowPanel manageShowPanel;
    private final ManageBookingPanel manageBookingPanel;
    private final SeatAvailabilityPanel seatAvailabilityPanel;

    private final JLabel lblTotalMoviesVal;
    private final JLabel lblTotalShowsVal;
    private final JLabel lblTotalBookingsVal;
    private final JLabel lblTodayBookingsVal;
    private final JLabel lblTodayRevenueVal;
    private final JLabel adminGreetingLabel;

    private Admin currentAdmin;
    private LogoutListener logoutListener;

    public AdminDashboardPanel(BookingService bookingService) {
        this.bookingService = bookingService;
        setLayout(new BorderLayout());
        setBackground(UITheme.BG_DARK);

        // Top Header Bar
        JPanel topHeader = new UITheme.GradientPanel(new Color(10, 14, 26), new Color(30, 27, 75));
        topHeader.setLayout(new BorderLayout());
        topHeader.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createMatteBorder(0, 0, 2, 0, UITheme.ACCENT_CYAN),
                BorderFactory.createEmptyBorder(12, 22, 12, 22)
        ));

        JPanel titleBlock = new JPanel(new GridLayout(2, 1, 2, 2));
        titleBlock.setOpaque(false);
        JLabel title = new JLabel("⚡ Admin Control Center");
        title.setFont(UITheme.FONT_TITLE);
        title.setForeground(Color.WHITE);

        adminGreetingLabel = new JLabel("Logged in as: Administrator");
        adminGreetingLabel.setFont(UITheme.FONT_SMALL);
        adminGreetingLabel.setForeground(UITheme.TEXT_MUTED);

        titleBlock.add(title);
        titleBlock.add(adminGreetingLabel);
        topHeader.add(titleBlock, BorderLayout.WEST);

        JButton logoutBtn = UITheme.createDangerButton("🚪 Log Out");
        logoutBtn.addActionListener(e -> {
            int c = JOptionPane.showConfirmDialog(this, "Are you sure you want to log out of the Admin panel?", "Confirm Logout", JOptionPane.YES_NO_OPTION);
            if (c == JOptionPane.YES_OPTION && logoutListener != null) {
                logoutListener.onLogout();
            }
        });
        topHeader.add(logoutBtn, BorderLayout.EAST);
        add(topHeader, BorderLayout.NORTH);

        // Tabbed Pane for admin modules
        tabbedPane = new JTabbedPane();
        tabbedPane.setFont(UITheme.FONT_BOLD);
        tabbedPane.setBackground(UITheme.CARD_BG);
        tabbedPane.setForeground(UITheme.TEXT_LIGHT);

        // Tab 1: Dashboard Overview
        JPanel overviewPanel = new JPanel(new BorderLayout(16, 16));
        overviewPanel.setBackground(UITheme.BG_DARK);
        overviewPanel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));

        JPanel statGrid = new JPanel(new GridLayout(2, 3, 16, 16));
        statGrid.setBackground(UITheme.BG_DARK);

        lblTotalMoviesVal = new JLabel("0");
        lblTotalShowsVal = new JLabel("0");
        lblTotalBookingsVal = new JLabel("0");
        lblTodayBookingsVal = new JLabel("0");
        lblTodayRevenueVal = new JLabel("₹0.00");

        statGrid.add(createKpiCard("TOTAL MOVIES", lblTotalMoviesVal, UITheme.ACCENT_CYAN));
        statGrid.add(createKpiCard("TOTAL SCHEDULED SHOWS", lblTotalShowsVal, UITheme.PRIMARY));
        statGrid.add(createKpiCard("CONFIRMED BOOKINGS", lblTotalBookingsVal, UITheme.ACCENT_ROSE));
        statGrid.add(createKpiCard("TODAY'S BOOKINGS", lblTodayBookingsVal, UITheme.ACCENT_GOLD));
        statGrid.add(createKpiCard("TODAY'S REVENUE", lblTodayRevenueVal, UITheme.SUCCESS));

        // Management Sub-panels
        manageMoviePanel = new ManageMoviePanel(bookingService);
        manageShowPanel = new ManageShowPanel(bookingService);
        manageBookingPanel = new ManageBookingPanel(bookingService);
        seatAvailabilityPanel = new SeatAvailabilityPanel(bookingService);

        // Quick Actions Card in Overview
        JPanel quickActions = UITheme.createCardPanel();
        quickActions.setLayout(new GridLayout(3, 1, 6, 6));
        JLabel qaTitle = new JLabel("Quick Navigation");
        qaTitle.setFont(UITheme.FONT_SUBTITLE);
        qaTitle.setForeground(UITheme.TEXT_LIGHT);
        quickActions.add(qaTitle);

        JButton btnGoMovies = UITheme.createSecondaryButton("Manage Movies Catalog");
        btnGoMovies.addActionListener(e -> tabbedPane.setSelectedComponent(manageMoviePanel));
        quickActions.add(btnGoMovies);

        JButton btnGoShows = UITheme.createSecondaryButton("Manage Show Schedules");
        btnGoShows.addActionListener(e -> tabbedPane.setSelectedComponent(manageShowPanel));
        quickActions.add(btnGoShows);

        statGrid.add(quickActions);

        overviewPanel.add(statGrid, BorderLayout.NORTH);

        JPanel refreshBar = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        refreshBar.setBackground(UITheme.BG_DARK);
        JButton refreshStatsBtn = UITheme.createPrimaryButton("↻ Refresh Statistics");
        refreshStatsBtn.addActionListener(e -> refreshDashboardStats());
        refreshBar.add(refreshStatsBtn);
        overviewPanel.add(refreshBar, BorderLayout.SOUTH);

        tabbedPane.addTab("  Dashboard Overview  ", overviewPanel);
        tabbedPane.addTab("  Manage Movies  ", manageMoviePanel);
        tabbedPane.addTab("  Manage Shows  ", manageShowPanel);
        tabbedPane.addTab("  All Bookings  ", manageBookingPanel);
        tabbedPane.addTab("  Seat Availability  ", seatAvailabilityPanel);

        tabbedPane.addChangeListener(e -> {
            if (tabbedPane.getSelectedComponent() == overviewPanel) {
                refreshDashboardStats();
            } else if (tabbedPane.getSelectedComponent() == manageShowPanel) {
                manageShowPanel.loadMoviesCombo();
                manageShowPanel.loadShows();
            } else if (tabbedPane.getSelectedComponent() == manageBookingPanel) {
                manageBookingPanel.loadAllBookings();
            } else if (tabbedPane.getSelectedComponent() == seatAvailabilityPanel) {
                seatAvailabilityPanel.refreshData();
            }
        });

        add(tabbedPane, BorderLayout.CENTER);
    }

    private JPanel createKpiCard(String labelText, JLabel valueLabel, Color accentColor) {
        JPanel card = UITheme.createCardPanel();
        card.setLayout(new BorderLayout(6, 6));
        card.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createMatteBorder(0, 5, 0, 0, accentColor),
                BorderFactory.createCompoundBorder(
                        BorderFactory.createLineBorder(UITheme.CARD_BORDER, 1, true),
                        BorderFactory.createEmptyBorder(14, 18, 14, 18)
                )
        ));

        JLabel titleLbl = new JLabel(labelText);
        titleLbl.setFont(UITheme.FONT_SMALL);
        titleLbl.setForeground(UITheme.TEXT_MUTED);

        valueLabel.setFont(new Font("Segoe UI", Font.BOLD, 26));
        valueLabel.setForeground(accentColor);

        card.add(titleLbl, BorderLayout.NORTH);
        card.add(valueLabel, BorderLayout.CENTER);
        return card;
    }

    public void setAdmin(Admin admin) {
        this.currentAdmin = admin;
        if (admin != null) {
            adminGreetingLabel.setText("Logged in as: " + admin.getUsername() + " (ID: #" + admin.getAdminId() + ")");
        }
        refreshDashboardStats();
    }

    public void refreshDashboardStats() {
        try {
            BookingService.DashboardStats stats = bookingService.getDashboardStats();
            lblTotalMoviesVal.setText(String.valueOf(stats.totalMovies));
            lblTotalShowsVal.setText(String.valueOf(stats.totalShows));
            lblTotalBookingsVal.setText(String.valueOf(stats.totalBookings));
            lblTodayBookingsVal.setText(String.valueOf(stats.todayBookings));
            lblTodayRevenueVal.setText(String.format("₹%.2f", stats.todayRevenue));
        } catch (SQLException e) {
            System.err.println("Could not refresh dashboard stats: " + e.getMessage());
        }
    }

    public void setLogoutListener(LogoutListener listener) {
        this.logoutListener = listener;
    }
}
