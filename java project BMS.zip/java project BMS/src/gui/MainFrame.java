package gui;

import java.awt.BorderLayout;
import java.awt.CardLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import model.Admin;
import service.BookingService;
import util.DatabaseConnection;

/**
 * Main application window for the Movie Ticket Booking System.
 * Hosts role switching (Customer vs. Admin), global top navigation bar,
 * database configuration access, and card-based module switching.
 */
public class MainFrame extends JFrame {

    private final BookingService bookingService;
    private final CardLayout cardLayout;
    private final JPanel mainContentPanel;

    private final CustomerPanel customerPanel;
    private final AdminLoginPanel adminLoginPanel;
    private final AdminDashboardPanel adminDashboardPanel;

    private final JButton btnCustomerRole;
    private final JButton btnAdminRole;
    private final JLabel dbStatusLabel;

    public static final String CARD_CUSTOMER = "CUSTOMER";
    public static final String CARD_ADMIN_LOGIN = "ADMIN_LOGIN";
    public static final String CARD_ADMIN_DASHBOARD = "ADMIN_DASHBOARD";

    private Admin activeAdmin = null;

    public MainFrame() {
        super("CineBook - Movie Ticket Booking System (Java Swing + MySQL)");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(1260, 840);
        setMinimumSize(new Dimension(1000, 680));
        setLocationRelativeTo(null);
        // Start maximized so all controls, posters, and buttons have maximum visibility
        setExtendedState(JFrame.MAXIMIZED_BOTH);

        this.bookingService = new BookingService();

        // 1. Global Navigation / Brand Top Bar
        JPanel topNavBar = new UITheme.GradientPanel(new Color(10, 14, 26), new Color(30, 27, 75));
        topNavBar.setLayout(new BorderLayout());
        topNavBar.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createMatteBorder(0, 0, 2, 0, UITheme.ACCENT_ROSE),
                BorderFactory.createEmptyBorder(12, 22, 12, 22)
        ));

        // Brand Title
        JPanel brandPanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 10, 0));
        brandPanel.setOpaque(false);
        JLabel brandIcon = new JLabel("🎬");
        brandIcon.setFont(new Font("Segoe UI Emoji", Font.PLAIN, 26));

        JLabel brandText = new JLabel("CINEBOOK");
        brandText.setFont(UITheme.FONT_BRAND);
        brandText.setForeground(Color.WHITE);

        JLabel subBrand = new JLabel("| Ultimate Cinema Reservation Hub");
        subBrand.setFont(UITheme.FONT_SMALL);
        subBrand.setForeground(UITheme.TEXT_MUTED);

        brandPanel.add(brandIcon);
        brandPanel.add(brandText);
        brandPanel.add(subBrand);
        topNavBar.add(brandPanel, BorderLayout.WEST);

        // Center: Role Switcher Buttons
        JPanel roleSwitcher = new JPanel(new FlowLayout(FlowLayout.CENTER, 12, 0));
        roleSwitcher.setOpaque(false);

        btnCustomerRole = UITheme.createPrimaryButton("Customer Portal");
        btnAdminRole = UITheme.createSecondaryButton("Admin Portal");

        btnCustomerRole.setPreferredSize(new Dimension(160, 38));
        btnAdminRole.setPreferredSize(new Dimension(160, 38));

        roleSwitcher.add(btnCustomerRole);
        roleSwitcher.add(btnAdminRole);
        topNavBar.add(roleSwitcher, BorderLayout.CENTER);

        // Right: DB Settings button & Status Indicator
        JPanel rightBar = new JPanel(new FlowLayout(FlowLayout.RIGHT, 14, 0));
        rightBar.setOpaque(false);

        dbStatusLabel = new JLabel("● DB Online");
        dbStatusLabel.setFont(UITheme.FONT_BOLD);
        dbStatusLabel.setForeground(UITheme.SUCCESS);
        rightBar.add(dbStatusLabel);

        JButton dbConfigBtn = UITheme.createSecondaryButton("⚙ DB Settings");
        dbConfigBtn.addActionListener(e -> openDbSettings());
        rightBar.add(dbConfigBtn);

        topNavBar.add(rightBar, BorderLayout.EAST);
        getContentPane().add(topNavBar, BorderLayout.NORTH);

        // 2. Center Card Panel
        cardLayout = new CardLayout();
        mainContentPanel = new JPanel(cardLayout);
        mainContentPanel.setBackground(UITheme.BG_DARK);

        customerPanel = new CustomerPanel(bookingService);
        adminLoginPanel = new AdminLoginPanel(bookingService);
        adminDashboardPanel = new AdminDashboardPanel(bookingService);

        mainContentPanel.add(customerPanel, CARD_CUSTOMER);
        mainContentPanel.add(adminLoginPanel, CARD_ADMIN_LOGIN);
        mainContentPanel.add(adminDashboardPanel, CARD_ADMIN_DASHBOARD);

        getContentPane().add(mainContentPanel, BorderLayout.CENTER);

        // 3. Status Bar
        JPanel statusBar = new JPanel(new BorderLayout());
        statusBar.setBackground(new Color(10, 14, 26));
        statusBar.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createMatteBorder(1, 0, 0, 0, UITheme.CARD_BORDER),
                BorderFactory.createEmptyBorder(8, 18, 8, 18)
        ));
        JLabel statusMsg = new JLabel("✨ Standalone Java SE + Java Swing + MySQL JDBC Architecture | Academic Project");
        statusMsg.setFont(UITheme.FONT_SMALL);
        statusMsg.setForeground(UITheme.TEXT_MUTED);
        statusBar.add(statusMsg, BorderLayout.WEST);

        JLabel copyright = new JLabel("CineBook Luxury System");
        copyright.setFont(UITheme.FONT_SMALL);
        copyright.setForeground(UITheme.ACCENT_CYAN);
        statusBar.add(copyright, BorderLayout.EAST);
        getContentPane().add(statusBar, BorderLayout.SOUTH);

        // 4. Role Navigation Handlers
        btnCustomerRole.addActionListener(e -> switchToCustomer());
        btnAdminRole.addActionListener(e -> switchToAdmin());

        adminLoginPanel.setLoginSuccessListener(admin -> {
            activeAdmin = admin;
            adminDashboardPanel.setAdmin(admin);
            cardLayout.show(mainContentPanel, CARD_ADMIN_DASHBOARD);
            btnAdminRole.setText("Admin (" + admin.getUsername() + ")");
            highlightRoleButton(btnAdminRole);
        });

        adminDashboardPanel.setLogoutListener(() -> {
            activeAdmin = null;
            btnAdminRole.setText("Admin Portal");
            cardLayout.show(mainContentPanel, CARD_ADMIN_LOGIN);
            highlightRoleButton(btnAdminRole);
        });

        // Initial view
        switchToCustomer();
        checkDatabaseConnectivity();
    }

    private void switchToCustomer() {
        cardLayout.show(mainContentPanel, CARD_CUSTOMER);
        customerPanel.refreshCustomerData();
        highlightRoleButton(btnCustomerRole);
    }

    private void switchToAdmin() {
        if (activeAdmin != null) {
            adminDashboardPanel.refreshDashboardStats();
            cardLayout.show(mainContentPanel, CARD_ADMIN_DASHBOARD);
        } else {
            cardLayout.show(mainContentPanel, CARD_ADMIN_LOGIN);
        }
        highlightRoleButton(btnAdminRole);
    }

    private void highlightRoleButton(JButton activeBtn) {
        if (activeBtn == btnCustomerRole) {
            btnCustomerRole.setBackground(UITheme.ACCENT_ROSE);
            btnCustomerRole.setForeground(Color.WHITE);
            btnAdminRole.setBackground(UITheme.CARD_BG);
            btnAdminRole.setForeground(UITheme.TEXT_MUTED);
        } else {
            btnAdminRole.setBackground(UITheme.ACCENT_ROSE);
            btnAdminRole.setForeground(Color.WHITE);
            btnCustomerRole.setBackground(UITheme.CARD_BG);
            btnCustomerRole.setForeground(UITheme.TEXT_MUTED);
        }
    }

    public void checkDatabaseConnectivity() {
        boolean ok = DatabaseConnection.testConnection();
        if (ok) {
            dbStatusLabel.setText("● DB Online");
            dbStatusLabel.setForeground(UITheme.SUCCESS);
        } else {
            dbStatusLabel.setText("● DB Offline");
            dbStatusLabel.setForeground(UITheme.DANGER);

            int choice = JOptionPane.showConfirmDialog(this,
                    "Unable to connect to MySQL database (" + DatabaseConnection.getDbName() + ") with current settings.\n\n"
                            + "Would you like to open Database Settings to configure your password or initialize tables now?",
                    "Database Connection Notice", JOptionPane.YES_NO_OPTION, JOptionPane.WARNING_MESSAGE);

            if (choice == JOptionPane.YES_OPTION) {
                openDbSettings();
            }
        }
    }

    private void openDbSettings() {
        DatabaseSettingsDialog dlg = new DatabaseSettingsDialog(this);
        dlg.setVisible(true);

        boolean ok = DatabaseConnection.testConnection();
        if (ok) {
            dbStatusLabel.setText("● DB Online");
            dbStatusLabel.setForeground(UITheme.SUCCESS);
            customerPanel.refreshCustomerData();
            if (activeAdmin != null) {
                adminDashboardPanel.refreshDashboardStats();
            }
        } else {
            dbStatusLabel.setText("● DB Offline");
            dbStatusLabel.setForeground(UITheme.DANGER);
        }
    }
}
