package gui;

import java.awt.Color;
import java.awt.Component;
import java.awt.Cursor;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.GradientPaint;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableCellRenderer;

/**
 * Styling and Theme configuration for CineBook.
 * Features an electrifying, vibrant modern Cinema Luxury aesthetic:
 * Deep Cosmic Indigo & Midnight Slate backgrounds, glowing neon accents,
 * vivid emerald seats, luminous gold selections, and sleek dark cards.
 */
public class UITheme {

    // Background Gradient & Foundation
    public static final Color BG_DARK = new Color(15, 23, 42);          // Midnight Navy #0F172A
    public static final Color BG_GRADIENT_END = new Color(30, 27, 75);  // Deep Cosmic Indigo #1E1B4B
    public static final Color CARD_BG = new Color(30, 41, 59);          // Rich Slate Navy #1E293B
    public static final Color CARD_BG_ALT = new Color(24, 32, 47);      // Deep Shaded Navy
    public static final Color CARD_BORDER = new Color(71, 85, 105);     // Slate Slate #475569
    public static final Color INPUT_BG = new Color(15, 23, 42);         // Dark Field Background #0F172A

    // Vibrant Neon & Cinema Accents
    public static final Color PRIMARY = new Color(99, 102, 241);        // Electric Royal Indigo #6366F1
    public static final Color PRIMARY_HOVER = new Color(79, 70, 229);   // #4F46E5
    public static final Color ACCENT_ROSE = new Color(244, 63, 94);     // Cinema Crimson / Rose #F43F5E
    public static final Color ACCENT_ROSE_HOVER = new Color(225, 29, 72);// #E11D48
    public static final Color ACCENT_CYAN = new Color(6, 182, 212);     // Electric Cyan #06B6D4
    public static final Color ACCENT_GOLD = new Color(245, 158, 11);    // Luminous Amber Gold #F59E0B
    public static final Color SUCCESS = new Color(16, 185, 129);        // Vibrant Emerald #10B981
    public static final Color DANGER = new Color(239, 68, 68);          // Bright Coral Danger #EF4444
    public static final Color WARNING = new Color(245, 158, 11);        // Amber Warning

    // Color Aliases
    public static final Color CYAN = ACCENT_CYAN;
    public static final Color GOLD = ACCENT_GOLD;
    public static final Color BORDER_COLOR = CARD_BORDER;
    public static final Color BG_INPUT = INPUT_BG;

    // Typography Colors
    public static final Color TEXT_LIGHT = new Color(248, 250, 252);    // Pure Crisp White #F8FAFC
    public static final Color TEXT_MUTED = new Color(148, 163, 184);    // Warm Silver #94A3B8
    public static final Color TEXT_ACCENT = new Color(56, 189, 248);    // Bright Sky Cyan #38BDF8
    public static final Color TEXT_DARK = new Color(241, 245, 249);     // Crisp bright text for dark cards

    // Seat Colors
    public static final Color SEAT_AVAILABLE = new Color(16, 185, 129); // Vibrant Emerald #10B981
    public static final Color SEAT_SELECTED = new Color(245, 158, 11);  // Glowing Gold #F59E0B
    public static final Color SEAT_BOOKED = new Color(51, 65, 85);      // Muted Charcoal #334155
    public static final Color SEAT_BOOKED_TEXT = new Color(148, 163, 184);

    // Fonts
    public static final Font FONT_BRAND = new Font("Segoe UI", Font.BOLD, 22);
    public static final Font FONT_TITLE = new Font("Segoe UI", Font.BOLD, 18);
    public static final Font FONT_SUBTITLE = new Font("Segoe UI", Font.BOLD, 14);
    public static final Font FONT_BOLD = new Font("Segoe UI", Font.BOLD, 13);
    public static final Font FONT_REGULAR = new Font("Segoe UI", Font.PLAIN, 13);
    public static final Font FONT_SMALL = new Font("Segoe UI", Font.PLAIN, 11);
    public static final Font FONT_SEAT = new Font("Segoe UI", Font.BOLD, 11);

    /**
     * Custom JPanel with a vibrant linear diagonal gradient background.
     */
    public static class GradientPanel extends JPanel {
        private final Color topColor;
        private final Color bottomColor;

        public GradientPanel(Color topColor, Color bottomColor) {
            this.topColor = topColor;
            this.bottomColor = bottomColor;
            setOpaque(false);
        }

        public GradientPanel() {
            this(BG_DARK, BG_GRADIENT_END);
        }

        @Override
        protected void paintComponent(Graphics g) {
            super.paintComponent(g);
            Graphics2D g2d = (Graphics2D) g.create();
            g2d.setRenderingHint(RenderingHints.KEY_RENDERING, RenderingHints.VALUE_RENDER_QUALITY);
            int w = getWidth();
            int h = getHeight();
            GradientPaint gp = new GradientPaint(0, 0, topColor, w, h, bottomColor);
            g2d.setPaint(gp);
            g2d.fillRect(0, 0, w, h);
            g2d.dispose();
        }
    }

    public static JButton createButton(String text, Color bg, Color fg) {
        JButton btn = new JButton(text);
        btn.setFont(FONT_BOLD);
        btn.setBackground(bg);
        btn.setForeground(fg);
        btn.setFocusPainted(false);
        btn.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(bg.darker(), 1, true),
                BorderFactory.createEmptyBorder(8, 18, 8, 18)
        ));
        btn.setCursor(new Cursor(Cursor.HAND_CURSOR));
        return btn;
    }

    public static JButton createPrimaryButton(String text) {
        return createButton(text, ACCENT_ROSE, Color.WHITE);
    }

    public static JButton createSuccessButton(String text) {
        return createButton(text, SUCCESS, Color.WHITE);
    }

    public static JButton createDangerButton(String text) {
        return createButton(text, DANGER, Color.WHITE);
    }

    public static JButton createSecondaryButton(String text) {
        JButton btn = createButton(text, CARD_BG, TEXT_LIGHT);
        btn.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(CARD_BORDER, 1, true),
                BorderFactory.createEmptyBorder(8, 16, 8, 16)
        ));
        return btn;
    }

    public static JTextField createTextField(int columns) {
        JTextField field = new JTextField(columns);
        field.setFont(FONT_REGULAR);
        field.setBackground(INPUT_BG);
        field.setForeground(TEXT_LIGHT);
        field.setCaretColor(TEXT_LIGHT);
        field.setPreferredSize(new Dimension(field.getPreferredSize().width, 36));
        field.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(CARD_BORDER, 1, true),
                BorderFactory.createEmptyBorder(6, 10, 6, 10)
        ));
        return field;
    }

    public static JPanel createCardPanel() {
        JPanel panel = new JPanel();
        panel.setBackground(CARD_BG);
        panel.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(CARD_BORDER, 1, true),
                BorderFactory.createEmptyBorder(16, 16, 16, 16)
        ));
        return panel;
    }

    public static JLabel createHeaderLabel(String text) {
        JLabel label = new JLabel(text);
        label.setFont(FONT_TITLE);
        label.setForeground(TEXT_LIGHT);
        return label;
    }

    public static void styleTable(JTable table) {
        table.setFont(FONT_REGULAR);
        table.setRowHeight(30);
        table.setBackground(CARD_BG);
        table.setForeground(TEXT_LIGHT);
        table.setSelectionBackground(ACCENT_ROSE);
        table.setSelectionForeground(Color.WHITE);
        table.setGridColor(CARD_BORDER);

        table.getTableHeader().setFont(FONT_BOLD);
        table.getTableHeader().setBackground(PRIMARY);
        table.getTableHeader().setForeground(Color.WHITE);
        table.getTableHeader().setPreferredSize(new Dimension(100, 34));

        DefaultTableCellRenderer renderer = new DefaultTableCellRenderer() {
            @Override
            public Component getTableCellRendererComponent(JTable tbl, Object value, boolean isSelected, boolean hasFocus, int row, int column) {
                Component c = super.getTableCellRendererComponent(tbl, value, isSelected, hasFocus, row, column);
                if (!isSelected) {
                    c.setBackground(row % 2 == 0 ? CARD_BG : CARD_BG_ALT);
                    c.setForeground(TEXT_LIGHT);
                } else {
                    c.setBackground(ACCENT_ROSE);
                    c.setForeground(Color.WHITE);
                }
                return c;
            }
        };

        for (int i = 0; i < table.getColumnCount(); i++) {
            table.getColumnModel().getColumn(i).setCellRenderer(renderer);
        }
    }
}
