package gui;

import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.sql.SQLException;
import java.util.List;
import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;
import model.Booking;
import service.BookingService;

/**
 * Admin Panel: View & Search All Bookings.
 * Allows searching by Booking ID, Customer Name, or Movie title across the database.
 */
public class ManageBookingPanel extends JPanel {

    private final BookingService bookingService;
    private final JTable bookingTable;
    private final DefaultTableModel tableModel;
    private final JTextField searchField;
    private final JLabel recordCountLabel;

    public ManageBookingPanel(BookingService bookingService) {
        this.bookingService = bookingService;
        setLayout(new BorderLayout(14, 14));
        setBackground(UITheme.BG_DARK);
        setBorder(BorderFactory.createEmptyBorder(16, 16, 16, 16));

        // Top Header
        JPanel topHeader = new JPanel(new BorderLayout());
        topHeader.setBackground(UITheme.BG_DARK);
        JLabel title = UITheme.createHeaderLabel("📋 All Cinema Ticket Bookings");
        JLabel sub = new JLabel("Audit reservations, search across customer records, and inspect ticket states.");
        sub.setFont(UITheme.FONT_REGULAR);
        sub.setForeground(UITheme.TEXT_MUTED);
        topHeader.add(title, BorderLayout.NORTH);
        topHeader.add(sub, BorderLayout.SOUTH);
        add(topHeader, BorderLayout.NORTH);

        // Center Container
        JPanel centerCard = UITheme.createCardPanel();
        centerCard.setLayout(new BorderLayout(10, 10));

        // Filter / Search Toolbar
        JPanel searchBar = new JPanel(new FlowLayout(FlowLayout.LEFT, 10, 5));
        searchBar.setBackground(UITheme.CARD_BG);

        JLabel searchLbl = new JLabel("Search (Booking ID, Customer Name, Movie):");
        searchLbl.setFont(UITheme.FONT_BOLD);
        searchLbl.setForeground(UITheme.TEXT_LIGHT);
        searchBar.add(searchLbl);

        searchField = UITheme.createTextField(18);
        searchBar.add(searchField);

        JButton searchBtn = UITheme.createPrimaryButton("🔍 Search");
        searchBtn.addActionListener(e -> executeSearch());
        searchBar.add(searchBtn);

        JButton resetBtn = UITheme.createSecondaryButton("Show All");
        resetBtn.addActionListener(e -> {
            searchField.setText("");
            loadAllBookings();
        });
        searchBar.add(resetBtn);

        recordCountLabel = new JLabel("Records: 0");
        recordCountLabel.setFont(UITheme.FONT_BOLD);
        recordCountLabel.setForeground(UITheme.ACCENT_CYAN);
        searchBar.add(recordCountLabel);

        centerCard.add(searchBar, BorderLayout.NORTH);

        // Table
        String[] columns = {"Booking ID", "Customer Name", "Phone", "Movie", "Show", "Seats", "Tickets", "Total Amount", "Status"};
        tableModel = new DefaultTableModel(columns, 0) {
            @Override
            public boolean isCellEditable(int row, int col) { return false; }
        };
        bookingTable = new JTable(tableModel);
        UITheme.styleTable(bookingTable);
        bookingTable.getTableHeader().setBackground(UITheme.PRIMARY);
        bookingTable.getTableHeader().setForeground(java.awt.Color.WHITE);

        centerCard.add(new JScrollPane(bookingTable), BorderLayout.CENTER);
        add(centerCard, BorderLayout.CENTER);

        searchField.addActionListener(e -> executeSearch());

        loadAllBookings();
    }

    public void loadAllBookings() {
        try {
            List<Booking> list = bookingService.getAllBookings();
            populateTable(list);
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Error fetching bookings: " + e.getMessage(), "Database Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void executeSearch() {
        String query = searchField.getText().trim();
        try {
            List<Booking> list = bookingService.searchBookings(query);
            populateTable(list);
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Error searching bookings: " + e.getMessage(), "Database Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void populateTable(List<Booking> list) {
        tableModel.setRowCount(0);
        for (Booking b : list) {
            tableModel.addRow(new Object[]{
                    b.getBookingId(),
                    b.getCustomerName(),
                    b.getPhone(),
                    b.getMovieTitle(),
                    b.getShowDate() + " " + b.getShowTime(),
                    b.getSeats(),
                    b.getTickets(),
                    String.format("₹%.2f", b.getTotalAmount()),
                    b.getStatus()
            });
        }
        recordCountLabel.setText("Records: " + list.size());
    }
}
