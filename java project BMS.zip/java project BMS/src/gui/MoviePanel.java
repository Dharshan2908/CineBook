package gui;

import java.awt.BorderLayout;
import java.awt.CardLayout;
import java.awt.Color;
import java.awt.Cursor;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.GridLayout;
import java.awt.Insets;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.sql.Date;
import java.sql.SQLException;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import javax.swing.BorderFactory;
import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextField;
import javax.swing.SwingConstants;
import model.Movie;
import model.Show;
import service.BookingService;
import util.PosterManager;

/**
 * Customer Movie Panel inspired by BookMyShow:
 * 1. "Recommended Movies" gallery featuring high-resolution movie posters,
 *    ratings, certification & duration badges, and instant booking.
 * 2. BookMyShow-style Showtimes screen featuring horizontal 7-day date selector,
 *    filter/status legend, cinema screens, and green time slot pill buttons.
 */
public class MoviePanel extends JPanel {

    public interface ShowBookActionListener {
        void onBookShowSelected(Movie movie, Show show);
    }

    private static final String VIEW_GALLERY = "GALLERY";
    private static final String VIEW_SHOWTIMES = "SHOWTIMES";

    private final BookingService bookingService;
    private final CardLayout cardLayout;
    private final JPanel mainContentContainer;

    // Gallery components
    private final JPanel movieGridPanel;
    private final JTextField searchField;
    private List<Movie> allMovies = new ArrayList<>();
    private String selectedLanguageFilter = "ALL";

    // Showtimes components
    private final JPanel showtimesContainer;
    private final JPanel dateBarPanel;
    private final JPanel cinemasPanel;
    private final JLabel detailTitleLabel;
    private final JLabel detailBadgesLabel;
    private final JLabel detailPosterLabel;
    private Movie activeMovie = null;
    private LocalDate activeDate = LocalDate.now();
    private List<Show> activeMovieShows = new ArrayList<>();

    private ShowBookActionListener bookListener;

    public MoviePanel(BookingService bookingService) {
        this.bookingService = bookingService;
        this.cardLayout = new CardLayout();
        this.mainContentContainer = new JPanel(cardLayout);
        this.searchField = new JTextField(28);

        setLayout(new BorderLayout());
        setBackground(UITheme.BG_DARK);

        // 1. Top Navigation Bar (BookMyShow style)
        JPanel topNavBar = createTopNavBar();
        add(topNavBar, BorderLayout.NORTH);

        // 2. View A: Movie Gallery (Recommended Movies)
        movieGridPanel = new JPanel(new GridLayout(0, 4, 18, 22));
        movieGridPanel.setBackground(UITheme.BG_DARK);
        movieGridPanel.setBorder(BorderFactory.createEmptyBorder(16, 20, 24, 20));

        JPanel galleryWrapper = new JPanel(new BorderLayout());
        galleryWrapper.setBackground(UITheme.BG_DARK);

        JPanel galleryHeader = createGalleryHeader();
        galleryWrapper.add(galleryHeader, BorderLayout.NORTH);

        JScrollPane galleryScroll = new JScrollPane(movieGridPanel);
        galleryScroll.setBorder(null);
        galleryScroll.setBackground(UITheme.BG_DARK);
        galleryScroll.getViewport().setBackground(UITheme.BG_DARK);
        galleryScroll.getVerticalScrollBar().setUnitIncrement(16);
        galleryWrapper.add(galleryScroll, BorderLayout.CENTER);

        // 3. View B: BookMyShow Showtimes View
        showtimesContainer = new JPanel(new BorderLayout());
        showtimesContainer.setBackground(UITheme.BG_DARK);

        // Details banner
        JPanel movieBanner = new JPanel(new BorderLayout(16, 8));
        movieBanner.setBackground(UITheme.CARD_BG);
        movieBanner.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createMatteBorder(0, 0, 1, 0, UITheme.CARD_BORDER),
                BorderFactory.createEmptyBorder(14, 20, 14, 20)
        ));

        JButton backBtn = UITheme.createSecondaryButton("← Back to Movies");
        backBtn.setFont(UITheme.FONT_BOLD);
        backBtn.addActionListener(e -> cardLayout.show(mainContentContainer, VIEW_GALLERY));

        JPanel bannerLeft = new JPanel(new FlowLayout(FlowLayout.LEFT, 14, 0));
        bannerLeft.setOpaque(false);
        bannerLeft.add(backBtn);

        detailPosterLabel = new JLabel();
        detailPosterLabel.setPreferredSize(new Dimension(65, 95));
        detailPosterLabel.setBorder(BorderFactory.createLineBorder(UITheme.CARD_BORDER, 1));
        bannerLeft.add(detailPosterLabel);

        JPanel titleBlock = new JPanel(new GridLayout(2, 1, 4, 4));
        titleBlock.setOpaque(false);
        detailTitleLabel = new JLabel("Movie Title");
        detailTitleLabel.setFont(new Font("Segoe UI", Font.BOLD, 22));
        detailTitleLabel.setForeground(UITheme.TEXT_LIGHT);

        detailBadgesLabel = new JLabel("Badges");
        detailBadgesLabel.setFont(UITheme.FONT_REGULAR);
        detailBadgesLabel.setForeground(UITheme.TEXT_MUTED);

        titleBlock.add(detailTitleLabel);
        titleBlock.add(detailBadgesLabel);
        bannerLeft.add(titleBlock);

        movieBanner.add(bannerLeft, BorderLayout.WEST);

        // Date Bar (7-day horizontal selector)
        dateBarPanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 10, 8));
        dateBarPanel.setBackground(new Color(24, 32, 47));
        dateBarPanel.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createMatteBorder(0, 0, 1, 0, UITheme.CARD_BORDER),
                BorderFactory.createEmptyBorder(6, 16, 6, 16)
        ));

        // Legend bar
        JPanel legendBar = createLegendBar();

        JPanel bannerStack = new JPanel();
        bannerStack.setLayout(new BoxLayout(bannerStack, BoxLayout.Y_AXIS));
        bannerStack.add(movieBanner);
        bannerStack.add(dateBarPanel);
        bannerStack.add(legendBar);

        showtimesContainer.add(bannerStack, BorderLayout.NORTH);

        // Cinemas listing panel
        cinemasPanel = new JPanel();
        cinemasPanel.setLayout(new BoxLayout(cinemasPanel, BoxLayout.Y_AXIS));
        cinemasPanel.setBackground(UITheme.BG_DARK);
        cinemasPanel.setBorder(BorderFactory.createEmptyBorder(16, 20, 20, 20));

        JScrollPane cinemaScroll = new JScrollPane(cinemasPanel);
        cinemaScroll.setBorder(null);
        cinemaScroll.setBackground(UITheme.BG_DARK);
        cinemaScroll.getViewport().setBackground(UITheme.BG_DARK);
        cinemaScroll.getVerticalScrollBar().setUnitIncrement(16);
        showtimesContainer.add(cinemaScroll, BorderLayout.CENTER);

        // Add views to card layout
        mainContentContainer.add(galleryWrapper, VIEW_GALLERY);
        mainContentContainer.add(showtimesContainer, VIEW_SHOWTIMES);

        add(mainContentContainer, BorderLayout.CENTER);

        // Initial Data Load
        loadMovies();
    }

    private JPanel createTopNavBar() {
        JPanel nav = new JPanel(new BorderLayout(14, 0));
        nav.setBackground(new Color(15, 23, 42));
        nav.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createMatteBorder(0, 0, 1, 0, new Color(51, 65, 85)),
                BorderFactory.createEmptyBorder(10, 20, 10, 20)
        ));

        // Brand / Logo
        JPanel brandPanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 10, 0));
        brandPanel.setOpaque(false);
        JLabel logo = new JLabel("🍿 CineBook");
        logo.setFont(new Font("Segoe UI", Font.BOLD, 20));
        logo.setForeground(UITheme.ACCENT_ROSE);

        JLabel location = new JLabel("📍 Chennai ▼");
        location.setFont(UITheme.FONT_BOLD);
        location.setForeground(UITheme.TEXT_MUTED);
        location.setCursor(new Cursor(Cursor.HAND_CURSOR));

        brandPanel.add(logo);
        brandPanel.add(Box.createHorizontalStrut(8));
        brandPanel.add(location);
        nav.add(brandPanel, BorderLayout.WEST);

        // Search Bar in center
        JPanel searchBox = new JPanel(new FlowLayout(FlowLayout.CENTER, 0, 0));
        searchBox.setOpaque(false);
        searchField.setFont(UITheme.FONT_REGULAR);
        searchField.setBackground(UITheme.CARD_BG);
        searchField.setForeground(UITheme.TEXT_LIGHT);
        searchField.setCaretColor(UITheme.TEXT_LIGHT);
        searchField.setText("");
        searchField.setToolTipText("Search for Movies, Genres, or Languages...");
        searchField.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(UITheme.CARD_BORDER, 1, true),
                BorderFactory.createEmptyBorder(7, 12, 7, 12)
        ));
        searchField.addKeyListener(new KeyAdapter() {
            @Override
            public void keyReleased(KeyEvent e) {
                filterGallery(searchField.getText().trim());
            }
        });
        searchBox.add(searchField);
        nav.add(searchBox, BorderLayout.CENTER);

        // Filter chips on right
        JPanel chips = new JPanel(new FlowLayout(FlowLayout.RIGHT, 6, 0));
        chips.setOpaque(false);
        String[] langs = {"ALL", "Tamil", "Malayalam", "English"};
        for (String l : langs) {
            JButton chip = new JButton(l);
            chip.setFont(UITheme.FONT_SMALL);
            chip.setFocusPainted(false);
            chip.setCursor(new Cursor(Cursor.HAND_CURSOR));
            chip.setBackground(l.equals("ALL") ? UITheme.ACCENT_ROSE : UITheme.CARD_BG);
            chip.setForeground(Color.WHITE);
            chip.setBorder(BorderFactory.createCompoundBorder(
                    BorderFactory.createLineBorder(UITheme.CARD_BORDER, 1, true),
                    BorderFactory.createEmptyBorder(4, 10, 4, 10)
            ));
            chip.addActionListener(e -> {
                selectedLanguageFilter = l;
                for (java.awt.Component c : chips.getComponents()) {
                    if (c instanceof JButton) {
                        c.setBackground(UITheme.CARD_BG);
                    }
                }
                chip.setBackground(UITheme.ACCENT_ROSE);
                filterGallery(searchField.getText().trim());
            });
            chips.add(chip);
        }
        nav.add(chips, BorderLayout.EAST);

        return nav;
    }

    private JPanel createGalleryHeader() {
        JPanel h = new JPanel(new BorderLayout());
        h.setBackground(UITheme.BG_DARK);
        h.setBorder(BorderFactory.createEmptyBorder(14, 20, 6, 20));

        JLabel title = new JLabel("Recommended Movies");
        title.setFont(new Font("Segoe UI", Font.BOLD, 22));
        title.setForeground(UITheme.TEXT_LIGHT);

        JLabel subtitle = new JLabel("Now Showing in Theatres • Explore ratings, genres & pick your preferred showtime");
        subtitle.setFont(UITheme.FONT_REGULAR);
        subtitle.setForeground(UITheme.TEXT_MUTED);

        JPanel left = new JPanel(new GridLayout(2, 1, 2, 2));
        left.setOpaque(false);
        left.add(title);
        left.add(subtitle);
        h.add(left, BorderLayout.WEST);

        JButton refreshBtn = UITheme.createSecondaryButton("↻ Refresh Movies");
        refreshBtn.addActionListener(e -> loadMovies());
        h.add(refreshBtn, BorderLayout.EAST);

        return h;
    }

    private JPanel createLegendBar() {
        JPanel bar = new JPanel(new BorderLayout());
        bar.setBackground(new Color(15, 23, 42));
        bar.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createMatteBorder(0, 0, 1, 0, UITheme.CARD_BORDER),
                BorderFactory.createEmptyBorder(6, 20, 6, 20)
        ));

        // Format tag on left
        JPanel left = new JPanel(new FlowLayout(FlowLayout.LEFT, 8, 0));
        left.setOpaque(false);
        JLabel tag = new JLabel("Tamil / Malayalam / English • 2D / DOLBY ATMOS");
        tag.setFont(UITheme.FONT_SMALL);
        tag.setForeground(UITheme.TEXT_MUTED);
        left.add(tag);
        bar.add(left, BorderLayout.WEST);

        // Legend indicators on right
        JPanel right = new JPanel(new FlowLayout(FlowLayout.RIGHT, 14, 0));
        right.setOpaque(false);

        JLabel avail = new JLabel("● AVAILABLE");
        avail.setFont(UITheme.FONT_SMALL);
        avail.setForeground(UITheme.SUCCESS);

        JLabel fast = new JLabel("● FAST FILLING");
        fast.setFont(UITheme.FONT_SMALL);
        fast.setForeground(UITheme.ACCENT_GOLD);

        JLabel house = new JLabel("● HOUSEFULL");
        house.setFont(UITheme.FONT_SMALL);
        house.setForeground(UITheme.TEXT_MUTED);

        right.add(avail);
        right.add(fast);
        right.add(house);
        bar.add(right, BorderLayout.EAST);

        return bar;
    }

    public void loadMovies() {
        try {
            allMovies = bookingService.getAllMovies();
            filterGallery("");
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this,
                    "Database error while loading movies: " + ex.getMessage(),
                    "Connection Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void filterGallery(String query) {
        movieGridPanel.removeAll();
        String q = query.toLowerCase();

        for (Movie m : allMovies) {
            boolean matchesLang = selectedLanguageFilter.equals("ALL")
                    || m.getLanguage().equalsIgnoreCase(selectedLanguageFilter);

            boolean matchesQuery = q.isEmpty()
                    || m.getTitle().toLowerCase().contains(q)
                    || m.getGenre().toLowerCase().contains(q)
                    || m.getLanguage().toLowerCase().contains(q);

            if (matchesLang && matchesQuery) {
                movieGridPanel.add(createMovieCard(m));
            }
        }

        if (movieGridPanel.getComponentCount() == 0) {
            JPanel empty = new JPanel(new FlowLayout(FlowLayout.CENTER, 0, 40));
            empty.setOpaque(false);
            JLabel lbl = new JLabel("No movies match your search. Try another filter!");
            lbl.setFont(UITheme.FONT_SUBTITLE);
            lbl.setForeground(UITheme.TEXT_MUTED);
            empty.add(lbl);
            movieGridPanel.add(empty);
        }

        movieGridPanel.revalidate();
        movieGridPanel.repaint();
    }

    /**
     * Creates a BookMyShow-style Movie Card with poster, rating badge, title, genre, and action button.
     */
    private JPanel createMovieCard(Movie movie) {
        JPanel card = new JPanel();
        card.setLayout(new BoxLayout(card, BoxLayout.Y_AXIS));
        card.setBackground(UITheme.CARD_BG);
        card.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(UITheme.CARD_BORDER, 1, true),
                BorderFactory.createEmptyBorder(10, 10, 12, 10)
        ));
        card.setCursor(new Cursor(Cursor.HAND_CURSOR));

        // Poster Image (185 x 265)
        ImageIcon posterIcon = PosterManager.getPoster(movie.getTitle(), 185, 265);
        JLabel posterLabel = new JLabel(posterIcon);
        posterLabel.setAlignmentX(0.5f);
        posterLabel.setBorder(BorderFactory.createLineBorder(new Color(71, 85, 105), 1));
        card.add(posterLabel);

        card.add(Box.createVerticalStrut(10));

        // Movie Title (Bold & Crisp)
        JLabel titleLabel = new JLabel(movie.getTitle());
        titleLabel.setFont(new Font("Segoe UI", Font.BOLD, 15));
        titleLabel.setForeground(UITheme.TEXT_LIGHT);
        titleLabel.setAlignmentX(0.5f);
        card.add(titleLabel);

        card.add(Box.createVerticalStrut(3));

        // Genre
        JLabel genreLabel = new JLabel(movie.getGenre());
        genreLabel.setFont(UITheme.FONT_SMALL);
        genreLabel.setForeground(UITheme.TEXT_MUTED);
        genreLabel.setAlignmentX(0.5f);
        card.add(genreLabel);

        card.add(Box.createVerticalStrut(2));

        // Language & Duration Badge
        int hours = movie.getDuration() / 60;
        int mins = movie.getDuration() % 60;
        String durStr = hours > 0 ? (hours + "h " + mins + "m") : (mins + "m");
        JLabel metaLabel = new JLabel(movie.getLanguage() + " • " + durStr);
        metaLabel.setFont(UITheme.FONT_SMALL);
        metaLabel.setForeground(UITheme.CYAN);
        metaLabel.setAlignmentX(0.5f);
        card.add(metaLabel);

        card.add(Box.createVerticalStrut(10));

        // "Book Tickets" Action Button
        JButton bookBtn = UITheme.createPrimaryButton("🎟 Book Tickets");
        bookBtn.setFont(new Font("Segoe UI", Font.BOLD, 12));
        bookBtn.setAlignmentX(0.5f);
        bookBtn.setMaximumSize(new Dimension(175, 34));
        bookBtn.addActionListener(e -> openMovieShowtimes(movie));
        card.add(bookBtn);

        // Click on entire card opens showtimes
        MouseAdapter clickHandler = new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                openMovieShowtimes(movie);
            }
        };
        card.addMouseListener(clickHandler);
        posterLabel.addMouseListener(clickHandler);

        return card;
    }

    /**
     * Opens BookMyShow-style Showtimes view for the selected movie.
     */
    private void openMovieShowtimes(Movie movie) {
        this.activeMovie = movie;
        detailTitleLabel.setText(movie.getTitle() + " - (" + movie.getLanguage() + ")");

        int hours = movie.getDuration() / 60;
        int mins = movie.getDuration() % 60;
        detailBadgesLabel.setText(String.format("Movie runtime: %dh %02dm  •  UA 16+  •  %s  •  Tickets from ₹200.00",
                hours, mins, movie.getGenre()));

        // Poster thumbnail
        detailPosterLabel.setIcon(PosterManager.getPoster(movie.getTitle(), 65, 95));

        // Load shows from service
        try {
            activeMovieShows = bookingService.getShowsByMovieId(movie.getMovieId());
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, "Failed to load shows: " + ex.getMessage(), "Database Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        // Default to today or the first date available
        activeDate = LocalDate.now();
        renderDateSelectorBar();
        renderCinemasForDate(activeDate);

        cardLayout.show(mainContentContainer, VIEW_SHOWTIMES);
    }

    /**
     * Renders the 7-day horizontal date selector bar (BookMyShow style).
     */
    private void renderDateSelectorBar() {
        dateBarPanel.removeAll();

        DateTimeFormatter dayFmt = DateTimeFormatter.ofPattern("EEE", Locale.ENGLISH);
        DateTimeFormatter numFmt = DateTimeFormatter.ofPattern("dd", Locale.ENGLISH);
        DateTimeFormatter monFmt = DateTimeFormatter.ofPattern("MMM", Locale.ENGLISH);

        LocalDate today = LocalDate.now();

        for (int i = 0; i < 7; i++) {
            LocalDate date = today.plusDays(i);
            boolean isSelected = date.equals(activeDate);

            JPanel dateCard = new JPanel();
            dateCard.setLayout(new BoxLayout(dateCard, BoxLayout.Y_AXIS));
            dateCard.setPreferredSize(new Dimension(64, 66));
            dateCard.setCursor(new Cursor(Cursor.HAND_CURSOR));

            if (isSelected) {
                dateCard.setBackground(UITheme.ACCENT_ROSE);
                dateCard.setBorder(BorderFactory.createCompoundBorder(
                        BorderFactory.createLineBorder(new Color(251, 113, 133), 1, true),
                        BorderFactory.createEmptyBorder(6, 6, 6, 6)
                ));
            } else {
                dateCard.setBackground(UITheme.CARD_BG);
                dateCard.setBorder(BorderFactory.createCompoundBorder(
                        BorderFactory.createLineBorder(UITheme.CARD_BORDER, 1, true),
                        BorderFactory.createEmptyBorder(6, 6, 6, 6)
                ));
            }

            JLabel dayLbl = new JLabel(date.format(dayFmt).toUpperCase());
            dayLbl.setFont(new Font("Segoe UI", Font.BOLD, 11));
            dayLbl.setForeground(isSelected ? Color.WHITE : UITheme.TEXT_MUTED);
            dayLbl.setAlignmentX(0.5f);

            JLabel numLbl = new JLabel(date.format(numFmt));
            numLbl.setFont(new Font("Segoe UI", Font.BOLD, 18));
            numLbl.setForeground(isSelected ? Color.WHITE : UITheme.TEXT_LIGHT);
            numLbl.setAlignmentX(0.5f);

            JLabel monLbl = new JLabel(date.format(monFmt).toUpperCase());
            monLbl.setFont(new Font("Segoe UI", Font.BOLD, 10));
            monLbl.setForeground(isSelected ? Color.WHITE : UITheme.TEXT_MUTED);
            monLbl.setAlignmentX(0.5f);

            dateCard.add(dayLbl);
            dateCard.add(numLbl);
            dateCard.add(monLbl);

            dateCard.addMouseListener(new MouseAdapter() {
                @Override
                public void mouseClicked(MouseEvent e) {
                    activeDate = date;
                    renderDateSelectorBar();
                    renderCinemasForDate(date);
                }
            });

            dateBarPanel.add(dateCard);
        }

        dateBarPanel.revalidate();
        dateBarPanel.repaint();
    }

    /**
     * Renders cinemas and time slot pill buttons for the chosen date.
     */
    private void renderCinemasForDate(LocalDate date) {
        cinemasPanel.removeAll();

        Date targetSqlDate = Date.valueOf(date);
        List<Show> dateShows = new ArrayList<>();
        for (Show s : activeMovieShows) {
            if (s.getShowDate().equals(targetSqlDate)) {
                dateShows.add(s);
            }
        }

        if (dateShows.isEmpty()) {
            JPanel noShows = new JPanel(new FlowLayout(FlowLayout.CENTER, 0, 40));
            noShows.setOpaque(false);
            JLabel msg = new JLabel("No shows currently scheduled for " + date + ". Please select another date above.");
            msg.setFont(UITheme.FONT_SUBTITLE);
            msg.setForeground(UITheme.TEXT_MUTED);
            noShows.add(msg);
            cinemasPanel.add(noShows);
            cinemasPanel.revalidate();
            cinemasPanel.repaint();
            return;
        }

        // Mock Cinema Venue Names (like BookMyShow's multiplex screens)
        String[][] cinemas = {
                {"PVR Grand Galada: OMR, Kelambakkam", "Dolby Atmos 7.1 • 4K Laser Screen 1", "Non-cancellable"},
                {"Rakki Cinemas: Screen 2", "RGB Laser • Immersive Surround", "M-Ticket Available"}
        };

        // Split shows between the 2 cinema screens (e.g. 2 morning/afternoon, 2 evening/night)
        List<Show> hall1Shows = new ArrayList<>();
        List<Show> hall2Shows = new ArrayList<>();

        for (int i = 0; i < dateShows.size(); i++) {
            if (i % 2 == 0) {
                hall1Shows.add(dateShows.get(i));
            } else {
                hall2Shows.add(dateShows.get(i));
            }
        }

        if (!hall1Shows.isEmpty()) {
            cinemasPanel.add(createCinemaVenueCard(cinemas[0][0], cinemas[0][1], cinemas[0][2], hall1Shows));
            cinemasPanel.add(Box.createVerticalStrut(14));
        }

        if (!hall2Shows.isEmpty()) {
            cinemasPanel.add(createCinemaVenueCard(cinemas[1][0], cinemas[1][1], cinemas[1][2], hall2Shows));
            cinemasPanel.add(Box.createVerticalStrut(14));
        }

        cinemasPanel.revalidate();
        cinemasPanel.repaint();
    }

    /**
     * Creates a BookMyShow Cinema Row with venue name and horizontal time slot pill buttons.
     */
    private JPanel createCinemaVenueCard(String cinemaName, String techInfo, String badgeInfo, List<Show> shows) {
        JPanel venueCard = new JPanel(new BorderLayout(14, 10));
        venueCard.setBackground(UITheme.CARD_BG);
        venueCard.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(UITheme.CARD_BORDER, 1, true),
                BorderFactory.createEmptyBorder(14, 18, 14, 18)
        ));

        // Venue Header
        JPanel venueHeader = new JPanel(new BorderLayout());
        venueHeader.setOpaque(false);

        JLabel nameLbl = new JLabel("🎬 " + cinemaName);
        nameLbl.setFont(new Font("Segoe UI", Font.BOLD, 15));
        nameLbl.setForeground(UITheme.TEXT_LIGHT);

        JLabel infoLbl = new JLabel(techInfo + "  •  " + badgeInfo);
        infoLbl.setFont(UITheme.FONT_SMALL);
        infoLbl.setForeground(UITheme.TEXT_MUTED);

        JPanel headerText = new JPanel(new GridLayout(2, 1, 2, 2));
        headerText.setOpaque(false);
        headerText.add(nameLbl);
        headerText.add(infoLbl);
        venueHeader.add(headerText, BorderLayout.WEST);

        venueCard.add(venueHeader, BorderLayout.NORTH);

        // Time Slots Flow Bar (BookMyShow green bordered pill buttons)
        JPanel timeSlotsBar = new JPanel(new FlowLayout(FlowLayout.LEFT, 12, 6));
        timeSlotsBar.setOpaque(false);

        for (Show show : shows) {
            JButton timeBtn = createTimeSlotButton(show);
            timeSlotsBar.add(timeBtn);
        }

        venueCard.add(timeSlotsBar, BorderLayout.CENTER);

        return venueCard;
    }

    /**
     * Creates an individual BookMyShow time slot pill button with green border and seat availability.
     */
    private JButton createTimeSlotButton(Show show) {
        int avail = show.getAvailableSeats();
        boolean isHousefull = avail <= 0;
        boolean isFastFilling = avail > 0 && avail < 20;

        Color borderColor = isHousefull ? UITheme.CARD_BORDER : (isFastFilling ? UITheme.ACCENT_GOLD : UITheme.SUCCESS);
        Color textColor = isHousefull ? UITheme.TEXT_MUTED : UITheme.TEXT_LIGHT;

        // Clean time format, e.g. 10:30:00 -> 10:30 AM
        String timeStr = show.getShowTime().toString();
        try {
            java.time.LocalTime lt = show.getShowTime().toLocalTime();
            timeStr = lt.format(DateTimeFormatter.ofPattern("hh:mm a", Locale.ENGLISH));
        } catch (Exception ignored) {}

        String btnHtml = String.format(
                "<html><center><b style='font-size:12px;color:%s;'>%s</b><br>"
                        + "<span style='font-size:9px;color:%s;'>%s</span></center></html>",
                isHousefull ? "#94A3B8" : "#FFFFFF",
                timeStr,
                isHousefull ? "#EF4444" : (isFastFilling ? "#F59E0B" : "#10B981"),
                isHousefull ? "HOUSEFULL" : (isFastFilling ? "FAST FILLING (" + avail + ")" : "₹" + String.format("%.0f", show.getPrice()) + " • " + avail + " LEFT")
        );

        JButton btn = new JButton(btnHtml);
        btn.setFont(UITheme.FONT_BOLD);
        btn.setBackground(new Color(15, 23, 42));
        btn.setFocusPainted(false);
        btn.setCursor(new Cursor(Cursor.HAND_CURSOR));
        btn.setPreferredSize(new Dimension(135, 52));
        btn.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(borderColor, 2, true),
                BorderFactory.createEmptyBorder(4, 8, 4, 8)
        ));

        if (isHousefull) {
            btn.setEnabled(false);
        } else {
            btn.addActionListener(e -> {
                if (bookListener != null && activeMovie != null) {
                    bookListener.onBookShowSelected(activeMovie, show);
                }
            });
        }

        return btn;
    }

    public void setShowBookActionListener(ShowBookActionListener listener) {
        this.bookListener = listener;
    }
}
