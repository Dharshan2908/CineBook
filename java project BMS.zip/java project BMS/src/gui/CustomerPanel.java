package gui;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JPanel;
import javax.swing.JTabbedPane;
import service.BookingService;

/**
 * Main Customer Container Panel.
 * Hosts tabs for:
 * 1. View Movies & Shows
 * 2. Book Ticket
 * 3. View Booking
 * 4. Modify Booking
 */
public class CustomerPanel extends JPanel {

    private final BookingService bookingService;
    private final JTabbedPane tabbedPane;
    private final MoviePanel moviePanel;
    private final BookingPanel bookingPanel;
    private final ViewBookingPanel viewBookingPanel;
    private final ModifyBookingPanel modifyBookingPanel;

    public CustomerPanel(BookingService bookingService) {
        this.bookingService = bookingService;
        setLayout(new BorderLayout());
        setBackground(UITheme.BG_DARK);

        tabbedPane = new JTabbedPane();
        tabbedPane.setFont(UITheme.FONT_BOLD);
        tabbedPane.setBackground(UITheme.CARD_BG);
        tabbedPane.setForeground(UITheme.TEXT_LIGHT);

        moviePanel = new MoviePanel(bookingService);
        bookingPanel = new BookingPanel(bookingService);
        viewBookingPanel = new ViewBookingPanel(bookingService);
        modifyBookingPanel = new ModifyBookingPanel(bookingService);

        tabbedPane.addTab("  1. Movies & Shows  ", moviePanel);
        tabbedPane.addTab("  2. Book Ticket  ", bookingPanel);
        tabbedPane.addTab("  3. View / Cancel Booking  ", viewBookingPanel);
        tabbedPane.addTab("  4. Modify Booking  ", modifyBookingPanel);

        add(tabbedPane, BorderLayout.CENTER);

        // Inter-panel action bindings
        moviePanel.setShowBookActionListener((movie, show) -> {
            bookingPanel.preselectShow(movie, show);
            tabbedPane.setSelectedComponent(bookingPanel);
        });

        bookingPanel.setBookingSuccessListener(bookingId -> {
            viewBookingPanel.searchForBookingId(bookingId);
            tabbedPane.setSelectedComponent(viewBookingPanel);
            moviePanel.loadMovies();
        });

        viewBookingPanel.setBookingActionListener(new ViewBookingPanel.BookingActionListener() {
            @Override
            public void onModifyRequested(int bookingId) {
                modifyBookingPanel.loadBookingForModification(bookingId);
                tabbedPane.setSelectedComponent(modifyBookingPanel);
            }

            @Override
            public void onBookingCancelled() {
                moviePanel.loadMovies();
                bookingPanel.refreshData();
            }
        });

        modifyBookingPanel.setModificationSuccessListener(bookingId -> {
            viewBookingPanel.searchForBookingId(bookingId);
            tabbedPane.setSelectedComponent(viewBookingPanel);
            moviePanel.loadMovies();
            bookingPanel.refreshData();
        });
    }

    public void refreshCustomerData() {
        moviePanel.loadMovies();
        bookingPanel.refreshData();
    }
}
