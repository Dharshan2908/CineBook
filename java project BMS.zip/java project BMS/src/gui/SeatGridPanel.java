package gui;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.GridLayout;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.SwingConstants;

/**
 * Reusable visual seat layout panel representing cinema seats.
 * Supports available, selected, and already-booked states with a cinema screen banner.
 */
public class SeatGridPanel extends JPanel {

    public interface SeatSelectionListener {
        void onSeatSelectionChanged(List<String> selectedSeats);
    }

    private final JPanel seatsContainer;
    private final List<JButton> seatButtons = new ArrayList<>();
    private final Set<String> bookedSeats = new HashSet<>();
    private final Set<String> selectedSeats = new HashSet<>();
    private int maxSelectable = 1;
    private boolean interactive = true;
    private SeatSelectionListener listener;

    public SeatGridPanel() {
        setLayout(new BorderLayout(10, 10));
        setBackground(UITheme.CARD_BG_ALT);
        setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        // 1. Cinema Screen Banner with Glowing Neon Border
        JPanel screenPanel = new JPanel(new BorderLayout());
        screenPanel.setBackground(new Color(15, 23, 42));
        screenPanel.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createMatteBorder(0, 0, 3, 0, UITheme.ACCENT_CYAN),
                BorderFactory.createEmptyBorder(8, 12, 8, 12)
        ));
        JLabel screenLabel = new JLabel("✨ ═══════════════ CINEMA SCREEN / STAGE ═══════════════ ✨", SwingConstants.CENTER);
        screenLabel.setFont(UITheme.FONT_SUBTITLE);
        screenLabel.setForeground(UITheme.ACCENT_CYAN);
        screenPanel.add(screenLabel, BorderLayout.CENTER);
        add(screenPanel, BorderLayout.NORTH);

        // 2. Seats Grid (Rows A-E, Cols 1-10 = 50 seats)
        seatsContainer = new JPanel();
        seatsContainer.setBackground(UITheme.CARD_BG_ALT);
        add(seatsContainer, BorderLayout.CENTER);

        // 3. Legend Panel
        JPanel legendPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 25, 8));
        legendPanel.setBackground(UITheme.CARD_BG_ALT);
        legendPanel.add(createLegendBadge("Available", UITheme.SEAT_AVAILABLE, Color.WHITE));
        legendPanel.add(createLegendBadge("Selected", UITheme.SEAT_SELECTED, Color.BLACK));
        legendPanel.add(createLegendBadge("Booked", UITheme.SEAT_BOOKED, UITheme.SEAT_BOOKED_TEXT));
        add(legendPanel, BorderLayout.SOUTH);

        // Initialize default 50-seat layout
        buildGrid(50);
    }

    private JPanel createLegendBadge(String label, Color bg, Color fg) {
        JPanel p = new JPanel(new FlowLayout(FlowLayout.LEFT, 8, 0));
        p.setBackground(UITheme.CARD_BG_ALT);
        JButton sample = new JButton();
        sample.setPreferredSize(new Dimension(20, 20));
        sample.setBackground(bg);
        sample.setEnabled(false);
        sample.setBorder(BorderFactory.createLineBorder(bg.darker(), 1));
        JLabel lbl = new JLabel(label);
        lbl.setFont(UITheme.FONT_SMALL);
        lbl.setForeground(UITheme.TEXT_DARK);
        p.add(sample);
        p.add(lbl);
        return p;
    }

    /**
     * Builds the seat grid based on total seat capacity.
     */
    public void buildGrid(int totalSeats) {
        seatsContainer.removeAll();
        seatButtons.clear();
        selectedSeats.clear();

        int cols = 10;
        int rows = (int) Math.ceil((double) totalSeats / cols);
        if (rows < 1) rows = 1;

        seatsContainer.setLayout(new GridLayout(rows, cols, 6, 6));
        char rowLetter = 'A';

        for (int r = 0; r < rows; r++) {
            char currentLetter = (char) (rowLetter + r);
            for (int c = 1; c <= cols; c++) {
                int seatIndex = r * cols + c;
                if (seatIndex <= totalSeats) {
                    String seatCode = "" + currentLetter + c;
                    JButton btn = createSeatButton(seatCode);
                    seatButtons.add(btn);
                    seatsContainer.add(btn);
                } else {
                    // Empty placeholder
                    JPanel empty = new JPanel();
                    empty.setOpaque(false);
                    seatsContainer.add(empty);
                }
            }
        }
        seatsContainer.revalidate();
        seatsContainer.repaint();
    }

    private JButton createSeatButton(String seatCode) {
        JButton btn = new JButton(seatCode);
        btn.setFont(UITheme.FONT_SEAT);
        btn.setPreferredSize(new Dimension(48, 36));
        btn.setFocusPainted(false);
        btn.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));

        applySeatVisualState(btn, seatCode);

        btn.addActionListener(e -> {
            if (!interactive) return;
            if (bookedSeats.contains(seatCode)) return;

            if (selectedSeats.contains(seatCode)) {
                selectedSeats.remove(seatCode);
            } else {
                if (selectedSeats.size() >= maxSelectable) {
                    // Can optionally notify or keep limit
                    return;
                }
                selectedSeats.add(seatCode);
            }
            applySeatVisualState(btn, seatCode);
            if (listener != null) {
                listener.onSeatSelectionChanged(getSelectedSeats());
            }
        });

        return btn;
    }

    private void applySeatVisualState(JButton btn, String seatCode) {
        if (bookedSeats.contains(seatCode)) {
            btn.setBackground(UITheme.SEAT_BOOKED);
            btn.setForeground(UITheme.SEAT_BOOKED_TEXT);
            btn.setBorder(BorderFactory.createLineBorder(new Color(30, 41, 59), 1));
            btn.setEnabled(false);
        } else if (selectedSeats.contains(seatCode)) {
            btn.setBackground(UITheme.SEAT_SELECTED);
            btn.setForeground(Color.BLACK);
            btn.setBorder(BorderFactory.createLineBorder(new Color(251, 191, 36), 2));
            btn.setEnabled(true);
        } else {
            btn.setBackground(UITheme.SEAT_AVAILABLE);
            btn.setForeground(Color.WHITE);
            btn.setBorder(BorderFactory.createLineBorder(new Color(5, 150, 105), 1));
            btn.setEnabled(true);
        }
    }

    public void setBookedSeats(List<String> booked) {
        bookedSeats.clear();
        selectedSeats.clear();
        if (booked != null) {
            for (String s : booked) {
                bookedSeats.add(s.trim().toUpperCase());
            }
        }
        for (JButton btn : seatButtons) {
            applySeatVisualState(btn, btn.getText());
        }
        if (listener != null) {
            listener.onSeatSelectionChanged(getSelectedSeats());
        }
    }

    public void setSelectedSeats(List<String> seats) {
        selectedSeats.clear();
        if (seats != null) {
            for (String s : seats) {
                String code = s.trim().toUpperCase();
                if (!bookedSeats.contains(code)) {
                    selectedSeats.add(code);
                }
            }
        }
        for (JButton btn : seatButtons) {
            applySeatVisualState(btn, btn.getText());
        }
        if (listener != null) {
            listener.onSeatSelectionChanged(getSelectedSeats());
        }
    }

    public List<String> getSelectedSeats() {
        List<String> list = new ArrayList<>(selectedSeats);
        Collections.sort(list);
        return list;
    }

    public void setMaxSelectable(int max) {
        this.maxSelectable = max;
        // If current selection exceeds new max, trim
        if (selectedSeats.size() > max) {
            List<String> list = new ArrayList<>(selectedSeats);
            selectedSeats.clear();
            for (int i = 0; i < max && i < list.size(); i++) {
                selectedSeats.add(list.get(i));
            }
            for (JButton btn : seatButtons) {
                applySeatVisualState(btn, btn.getText());
            }
            if (listener != null) {
                listener.onSeatSelectionChanged(getSelectedSeats());
            }
        }
    }

    public int getMaxSelectable() {
        return maxSelectable;
    }

    public void setInteractive(boolean interactive) {
        this.interactive = interactive;
        for (JButton btn : seatButtons) {
            if (!bookedSeats.contains(btn.getText())) {
                btn.setEnabled(interactive);
            }
        }
    }

    public void setSeatSelectionListener(SeatSelectionListener listener) {
        this.listener = listener;
    }

    public void clearSelection() {
        selectedSeats.clear();
        for (JButton btn : seatButtons) {
            applySeatVisualState(btn, btn.getText());
        }
        if (listener != null) {
            listener.onSeatSelectionChanged(getSelectedSeats());
        }
    }
}
