package gui;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Frame;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;
import util.DatabaseConnection;
import util.DatabaseInitializer;

/**
 * Configuration Dialog to adjust MySQL database credentials,
 * test connectivity, and run database initialization script.
 */
public class DatabaseSettingsDialog extends JDialog {

    private final JTextField hostField;
    private final JTextField portField;
    private final JTextField dbNameField;
    private final JTextField userField;
    private final JPasswordField passwordField;
    private boolean connectedSuccessfully = false;

    public DatabaseSettingsDialog(Frame owner) {
        super(owner, "Database Connection Settings", true);
        setLayout(new BorderLayout(12, 12));
        setSize(460, 420);
        setLocationRelativeTo(owner);
        getContentPane().setBackground(UITheme.BG_DARK);

        JPanel content = UITheme.createCardPanel();
        content.setLayout(new GridBagLayout());
        content.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(UITheme.BORDER_COLOR, 1),
                BorderFactory.createEmptyBorder(18, 22, 18, 22)
        ));

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.insets = new Insets(6, 6, 6, 6);
        gbc.weightx = 1.0;

        int row = 0;

        gbc.gridx = 0; gbc.gridy = row++;
        gbc.gridwidth = 2;
        JLabel header = new JLabel("⚡ MySQL Database Configuration");
        header.setFont(UITheme.FONT_SUBTITLE);
        header.setForeground(UITheme.CYAN);
        content.add(header, gbc);

        gbc.gridy = row++;
        JLabel sub = new JLabel("Adjust host, user, or password to connect to your local MySQL server.");
        sub.setFont(UITheme.FONT_SMALL);
        sub.setForeground(UITheme.TEXT_MUTED);
        content.add(sub, gbc);

        gbc.gridwidth = 1;

        // Helper to create styled label
        java.util.function.Function<String, JLabel> makeLbl = text -> {
            JLabel l = new JLabel(text);
            l.setFont(UITheme.FONT_BOLD);
            l.setForeground(UITheme.TEXT_LIGHT);
            return l;
        };

        // Host
        gbc.gridx = 0; gbc.gridy = row;
        content.add(makeLbl.apply("Host:"), gbc);
        gbc.gridx = 1;
        hostField = UITheme.createTextField(15);
        hostField.setText(DatabaseConnection.getHost());
        content.add(hostField, gbc);
        row++;

        // Port
        gbc.gridx = 0; gbc.gridy = row;
        content.add(makeLbl.apply("Port:"), gbc);
        gbc.gridx = 1;
        portField = UITheme.createTextField(15);
        portField.setText(String.valueOf(DatabaseConnection.getPort()));
        content.add(portField, gbc);
        row++;

        // DB Name
        gbc.gridx = 0; gbc.gridy = row;
        content.add(makeLbl.apply("Database Name:"), gbc);
        gbc.gridx = 1;
        dbNameField = UITheme.createTextField(15);
        dbNameField.setText(DatabaseConnection.getDbName());
        content.add(dbNameField, gbc);
        row++;

        // User
        gbc.gridx = 0; gbc.gridy = row;
        content.add(makeLbl.apply("Username:"), gbc);
        gbc.gridx = 1;
        userField = UITheme.createTextField(15);
        userField.setText(DatabaseConnection.getUser());
        content.add(userField, gbc);
        row++;

        // Password
        gbc.gridx = 0; gbc.gridy = row;
        content.add(makeLbl.apply("Password:"), gbc);
        gbc.gridx = 1;
        passwordField = new JPasswordField(15);
        passwordField.setText(DatabaseConnection.getPassword());
        passwordField.setBackground(UITheme.BG_INPUT);
        passwordField.setForeground(UITheme.TEXT_LIGHT);
        passwordField.setCaretColor(UITheme.TEXT_LIGHT);
        passwordField.setFont(UITheme.FONT_REGULAR);
        passwordField.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(UITheme.BORDER_COLOR, 1),
                BorderFactory.createEmptyBorder(6, 10, 6, 10)
        ));
        passwordField.setPreferredSize(new Dimension(passwordField.getPreferredSize().width, 34));
        content.add(passwordField, gbc);
        row++;

        add(content, BorderLayout.CENTER);

        // Buttons
        JPanel btnBar = new JPanel(new FlowLayout(FlowLayout.RIGHT, 10, 10));
        btnBar.setBackground(UITheme.BG_DARK);

        JButton testBtn = UITheme.createSecondaryButton("Test Connection");
        JButton initBtn = UITheme.createPrimaryButton("Initialize DB Tables");
        JButton saveBtn = UITheme.createSuccessButton("Save & Connect");

        btnBar.add(testBtn);
        btnBar.add(initBtn);
        btnBar.add(saveBtn);
        add(btnBar, BorderLayout.SOUTH);

        testBtn.addActionListener(e -> {
            String h = hostField.getText().trim();
            int p = Integer.parseInt(portField.getText().trim());
            String db = dbNameField.getText().trim();
            String u = userField.getText().trim();
            String pass = new String(passwordField.getPassword());

            boolean ok = DatabaseConnection.testCustomConnection(h, p, db, u, pass);
            if (ok) {
                JOptionPane.showMessageDialog(this, "Connection successful to " + db + "!", "Connection Test", JOptionPane.INFORMATION_MESSAGE);
            } else {
                JOptionPane.showMessageDialog(this,
                        "Could not connect to MySQL with these settings.\n"
                                + "Ensure MySQL Server service is running and credentials are valid.\n"
                                + "You can also click 'Initialize DB Tables' to automatically create the database schema.",
                        "Connection Failed", JOptionPane.WARNING_MESSAGE);
            }
        });

        initBtn.addActionListener(e -> {
            // First save config temporarily
            try {
                DatabaseConnection.saveConfiguration(
                        hostField.getText().trim(),
                        Integer.parseInt(portField.getText().trim()),
                        dbNameField.getText().trim(),
                        userField.getText().trim(),
                        new String(passwordField.getPassword())
                );
                String err = DatabaseInitializer.initializeDatabase("database/movie_ticket_booking.sql");
                if (err == null) {
                    JOptionPane.showMessageDialog(this,
                            "Database 'movie_booking_db' and all required tables were successfully created and populated with sample data!",
                            "Database Initialized", JOptionPane.INFORMATION_MESSAGE);
                } else {
                    JOptionPane.showMessageDialog(this, "Initialization notice:\n" + err, "Notice", JOptionPane.WARNING_MESSAGE);
                }
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(this, "Error during schema initialization: " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
            }
        });

        saveBtn.addActionListener(e -> {
            try {
                DatabaseConnection.saveConfiguration(
                        hostField.getText().trim(),
                        Integer.parseInt(portField.getText().trim()),
                        dbNameField.getText().trim(),
                        userField.getText().trim(),
                        new String(passwordField.getPassword())
                );
                connectedSuccessfully = true;
                dispose();
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(this, "Failed to save configuration: " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
            }
        });
    }

    public boolean isConnectedSuccessfully() {
        return connectedSuccessfully;
    }
}
