package gui;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.sql.Date;
import java.sql.SQLException;
import java.sql.Time;
import java.time.LocalDate;
import java.util.List;
import javax.swing.BorderFactory;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JSplitPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.ListSelectionModel;
import javax.swing.table.DefaultTableModel;
import model.Movie;
import model.Show;
import service.BookingService;
import util.ValidationUtil;

/**
 * Admin Panel: Show Schedule Management.
 * Implements CRUD for Shows with Movie dropdown and booking consistency checks.
 */
public class ManageShowPanel extends JPanel {

    private final BookingService bookingService;
    private final JTable showTable;
    private final DefaultTableModel tableModel;

    private final JComboBox<MovieComboItem> movieCombo;
    private final JTextField txtDate;
    private final JTextField txtTime;
    private final JTextField txtPrice;
    private final JTextField txtTotalSeats;

    private final JButton btnAdd;
    private final JButton btnUpdate;
    private final JButton btnDelete;
    private final JButton btnClear;

    private int selectedShowId = -1;
    private List<Show> showList;
    private List<Movie> movieList;

    public ManageShowPanel(BookingService bookingService) {
        this.bookingService = bookingService;
        setLayout(new BorderLayout(14, 14));
        setBackground(UITheme.BG_DARK);
        setBorder(BorderFactory.createEmptyBorder(16, 16, 16, 16));

        // Top Header
        JPanel topHeader = new JPanel(new BorderLayout());
        topHeader.setBackground(UITheme.BG_DARK);
        JLabel title = UITheme.createHeaderLabel("📅 Show Schedule Management");
        JLabel sub = new JLabel("Schedule new screening showtimes, configure ticket rates and theater seating capacity.");
        sub.setFont(UITheme.FONT_REGULAR);
        sub.setForeground(UITheme.TEXT_MUTED);
        topHeader.add(title, BorderLayout.NORTH);
        topHeader.add(sub, BorderLayout.SOUTH);
        add(topHeader, BorderLayout.NORTH);

        // Center Split: Left = Input Form, Right = JTable
        JPanel formCard = UITheme.createCardPanel();
        formCard.setLayout(new GridBagLayout());
        formCard.setPreferredSize(new Dimension(380, 500));

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.insets = new Insets(5, 8, 5, 8);
        gbc.weightx = 1.0;

        int row = 0;
        gbc.gridx = 0; gbc.gridy = row++;
        JLabel formHeading = new JLabel("Show Parameters");
        formHeading.setFont(UITheme.FONT_SUBTITLE);
        formHeading.setForeground(UITheme.TEXT_LIGHT);
        formCard.add(formHeading, gbc);

        // Movie Dropdown
        gbc.gridy = row++;
        JLabel lblM = new JLabel("Select Movie:");
        lblM.setForeground(UITheme.TEXT_LIGHT);
        formCard.add(lblM, gbc);
        movieCombo = new JComboBox<>();
        movieCombo.setFont(UITheme.FONT_REGULAR);
        movieCombo.setBackground(UITheme.INPUT_BG);
        movieCombo.setForeground(UITheme.TEXT_LIGHT);
        movieCombo.setPreferredSize(new Dimension(280, 36));
        gbc.gridy = row++;
        formCard.add(movieCombo, gbc);

        // Show Date (YYYY-MM-DD)
        gbc.gridy = row++;
        JLabel lblD = new JLabel("Show Date (YYYY-MM-DD):");
        lblD.setForeground(UITheme.TEXT_LIGHT);
        formCard.add(lblD, gbc);
        txtDate = UITheme.createTextField(20);
        txtDate.setText(LocalDate.now().toString());
        gbc.gridy = row++;
        formCard.add(txtDate, gbc);

        // Show Time (HH:MM:SS)
        gbc.gridy = row++;
        JLabel lblT = new JLabel("Show Time (HH:MM:SS):");
        lblT.setForeground(UITheme.TEXT_LIGHT);
        formCard.add(lblT, gbc);
        txtTime = UITheme.createTextField(20);
        txtTime.setText("18:00:00");
        gbc.gridy = row++;
        formCard.add(txtTime, gbc);

        // Ticket Price
        gbc.gridy = row++;
        JLabel lblP = new JLabel("Ticket Price (₹):");
        lblP.setForeground(UITheme.TEXT_LIGHT);
        formCard.add(lblP, gbc);
        txtPrice = UITheme.createTextField(20);
        txtPrice.setText("200.00");
        gbc.gridy = row++;
        formCard.add(txtPrice, gbc);

        // Total Seats
        gbc.gridy = row++;
        JLabel lblS = new JLabel("Total Seats Capacity:");
        lblS.setForeground(UITheme.TEXT_LIGHT);
        formCard.add(lblS, gbc);
        txtTotalSeats = UITheme.createTextField(20);
        txtTotalSeats.setText("50");
        gbc.gridy = row++;
        formCard.add(txtTotalSeats, gbc);

        // Action Buttons
        gbc.gridy = row++;
        gbc.insets = new Insets(12, 8, 6, 8);
        JPanel btnPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 6, 6));
        btnPanel.setBackground(UITheme.CARD_BG);

        btnAdd = UITheme.createPrimaryButton("Add Show");
        btnUpdate = UITheme.createSuccessButton("Update");
        btnDelete = UITheme.createDangerButton("Delete");
        btnClear = UITheme.createSecondaryButton("Clear");

        btnUpdate.setEnabled(false);
        btnDelete.setEnabled(false);

        btnPanel.add(btnAdd);
        btnPanel.add(btnUpdate);
        btnPanel.add(btnDelete);
        btnPanel.add(btnClear);
        formCard.add(btnPanel, gbc);

        // Right Table Card
        JPanel tableCard = UITheme.createCardPanel();
        tableCard.setLayout(new BorderLayout(8, 8));

        JPanel tableHeader = new JPanel(new BorderLayout());
        tableHeader.setBackground(UITheme.CARD_BG);
        JLabel tblTitle = new JLabel("All Scheduled Shows");
        tblTitle.setFont(UITheme.FONT_SUBTITLE);
        tblTitle.setForeground(UITheme.TEXT_LIGHT);
        tableHeader.add(tblTitle, BorderLayout.WEST);

        JButton refreshBtn = UITheme.createSecondaryButton("↻ Refresh Table");
        refreshBtn.addActionListener(e -> {
            loadMoviesCombo();
            loadShows();
        });
        tableHeader.add(refreshBtn, BorderLayout.EAST);
        tableCard.add(tableHeader, BorderLayout.NORTH);

        String[] cols = {"Show ID", "Movie", "Date", "Time", "Price", "Total Seats", "Available"};
        tableModel = new DefaultTableModel(cols, 0) {
            @Override
            public boolean isCellEditable(int row, int col) { return false; }
        };
        showTable = new JTable(tableModel);
        UITheme.styleTable(showTable);
        showTable.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);

        tableCard.add(new JScrollPane(showTable), BorderLayout.CENTER);

        // Split Pane
        JSplitPane split = new JSplitPane(JSplitPane.HORIZONTAL_SPLIT, formCard, tableCard);
        split.setDividerLocation(400);
        split.setDividerSize(6);
        split.setBackground(UITheme.BG_DARK);
        add(split, BorderLayout.CENTER);

        // Listeners
        btnAdd.addActionListener(e -> handleAddShow());
        btnUpdate.addActionListener(e -> handleUpdateShow());
        btnDelete.addActionListener(e -> handleDeleteShow());
        btnClear.addActionListener(e -> clearForm());

        showTable.getSelectionModel().addListSelectionListener(e -> {
            if (!e.getValueIsAdjusting()) {
                int rowIdx = showTable.getSelectedRow();
                if (rowIdx >= 0 && showList != null && rowIdx < showList.size()) {
                    Show s = showList.get(rowIdx);
                    selectedShowId = s.getShowId();

                    // Pre-select movie in combo
                    for (int i = 0; i < movieCombo.getItemCount(); i++) {
                        MovieComboItem item = movieCombo.getItemAt(i);
                        if (item.movie.getMovieId() == s.getMovieId()) {
                            movieCombo.setSelectedIndex(i);
                            break;
                        }
                    }

                    txtDate.setText(s.getShowDate().toString());
                    txtTime.setText(s.getShowTime().toString());
                    txtPrice.setText(String.format("%.2f", s.getPrice()));
                    txtTotalSeats.setText(String.valueOf(s.getTotalSeats()));

                    btnAdd.setEnabled(false);
                    btnUpdate.setEnabled(true);
                    btnDelete.setEnabled(true);
                }
            }
        });

        loadMoviesCombo();
        loadShows();
    }

    public void loadMoviesCombo() {
        try {
            movieList = bookingService.getAllMovies();
            DefaultComboBoxModel<MovieComboItem> model = new DefaultComboBoxModel<>();
            for (Movie m : movieList) {
                model.addElement(new MovieComboItem(m));
            }
            movieCombo.setModel(model);
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Error fetching movies for dropdown: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    public void loadShows() {
        try {
            showList = bookingService.getAllShows();
            tableModel.setRowCount(0);
            for (Show s : showList) {
                tableModel.addRow(new Object[]{
                        s.getShowId(),
                        s.getMovieTitle(),
                        s.getShowDate(),
                        s.getShowTime(),
                        String.format("₹%.2f", s.getPrice()),
                        s.getTotalSeats(),
                        s.getAvailableSeats()
                });
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Error loading shows: " + e.getMessage(), "Database Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void handleAddShow() {
        MovieComboItem item = (MovieComboItem) movieCombo.getSelectedItem();
        if (item == null) {
            JOptionPane.showMessageDialog(this, "Please select a movie.", "Validation Error", JOptionPane.WARNING_MESSAGE);
            return;
        }

        String dateStr = txtDate.getText().trim();
        String timeStr = txtTime.getText().trim();
        String priceStr = txtPrice.getText().trim();
        String seatsStr = txtTotalSeats.getText().trim();

        if (!ValidationUtil.isValidDateFormat(dateStr)) {
            JOptionPane.showMessageDialog(this, "Please enter a valid date in YYYY-MM-DD format.", "Invalid Date", JOptionPane.WARNING_MESSAGE);
            return;
        }

        if (!ValidationUtil.isValidTimeFormat(timeStr)) {
            JOptionPane.showMessageDialog(this, "Please enter a valid time in HH:MM:SS or HH:MM format.", "Invalid Time", JOptionPane.WARNING_MESSAGE);
            return;
        }

        if (!ValidationUtil.isPositiveDouble(priceStr)) {
            JOptionPane.showMessageDialog(this, "Ticket price must be a positive number.", "Invalid Price", JOptionPane.WARNING_MESSAGE);
            return;
        }

        if (!ValidationUtil.isPositiveInteger(seatsStr)) {
            JOptionPane.showMessageDialog(this, "Total seats must be a positive integer.", "Invalid Seats", JOptionPane.WARNING_MESSAGE);
            return;
        }

        if (timeStr.length() == 5) timeStr += ":00";

        Date sqlDate = Date.valueOf(dateStr);
        Time sqlTime = Time.valueOf(timeStr);
        double price = Double.parseDouble(priceStr);
        int totalSeats = Integer.parseInt(seatsStr);

        try {
            boolean success = bookingService.addShow(item.movie.getMovieId(), sqlDate, sqlTime, price, totalSeats);
            if (success) {
                JOptionPane.showMessageDialog(this, "Show scheduled successfully for " + item.movie.getTitle() + "!", "Success", JOptionPane.INFORMATION_MESSAGE);
                clearForm();
                loadShows();
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Database error adding show: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void handleUpdateShow() {
        if (selectedShowId <= 0) return;

        MovieComboItem item = (MovieComboItem) movieCombo.getSelectedItem();
        if (item == null) return;

        String dateStr = txtDate.getText().trim();
        String timeStr = txtTime.getText().trim();
        String priceStr = txtPrice.getText().trim();
        String seatsStr = txtTotalSeats.getText().trim();

        if (!ValidationUtil.isValidDateFormat(dateStr) || !ValidationUtil.isValidTimeFormat(timeStr)) {
            JOptionPane.showMessageDialog(this, "Invalid date or time format.", "Validation Error", JOptionPane.WARNING_MESSAGE);
            return;
        }

        if (!ValidationUtil.isPositiveDouble(priceStr) || !ValidationUtil.isPositiveInteger(seatsStr)) {
            JOptionPane.showMessageDialog(this, "Price and seats must be valid positive numbers.", "Validation Error", JOptionPane.WARNING_MESSAGE);
            return;
        }

        if (timeStr.length() == 5) timeStr += ":00";

        Date sqlDate = Date.valueOf(dateStr);
        Time sqlTime = Time.valueOf(timeStr);
        double price = Double.parseDouble(priceStr);
        int totalSeats = Integer.parseInt(seatsStr);

        try {
            boolean success = bookingService.updateShow(selectedShowId, item.movie.getMovieId(), sqlDate, sqlTime, price, totalSeats);
            if (success) {
                JOptionPane.showMessageDialog(this, "Show #" + selectedShowId + " updated successfully!", "Success", JOptionPane.INFORMATION_MESSAGE);
                clearForm();
                loadShows();
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Database error updating show: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void handleDeleteShow() {
        if (selectedShowId <= 0) return;

        int choice = JOptionPane.showConfirmDialog(this,
                "Are you sure you want to delete show #" + selectedShowId + "?\n"
                        + "This operation will be rejected if customer bookings exist for this show.",
                "Confirm Delete", JOptionPane.YES_NO_OPTION, JOptionPane.WARNING_MESSAGE);

        if (choice != JOptionPane.YES_OPTION) return;

        try {
            boolean success = bookingService.deleteShow(selectedShowId);
            if (success) {
                JOptionPane.showMessageDialog(this, "Show #" + selectedShowId + " deleted successfully.", "Success", JOptionPane.INFORMATION_MESSAGE);
                clearForm();
                loadShows();
            }
        } catch (IllegalStateException e) {
            JOptionPane.showMessageDialog(this, e.getMessage(), "Safety Restriction", JOptionPane.WARNING_MESSAGE);
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Database error deleting show: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void clearForm() {
        selectedShowId = -1;
        txtDate.setText(LocalDate.now().toString());
        txtTime.setText("18:00:00");
        txtPrice.setText("200.00");
        txtTotalSeats.setText("50");
        showTable.clearSelection();
        btnAdd.setEnabled(true);
        btnUpdate.setEnabled(false);
        btnDelete.setEnabled(false);
    }

    private static class MovieComboItem {
        final Movie movie;
        MovieComboItem(Movie movie) { this.movie = movie; }
        @Override
        public String toString() {
            return movie.getTitle() + " (" + movie.getLanguage() + ")";
        }
    }
}
