package gui;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.sql.SQLException;
import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;
import model.Admin;
import service.BookingService;

/**
 * Admin Authentication Screen.
 * Validates admin credentials against MySQL database.
 */
public class AdminLoginPanel extends JPanel {

    public interface LoginSuccessListener {
        void onAdminLoginSuccess(Admin admin);
    }

    private final BookingService bookingService;
    private final JTextField usernameField;
    private final JPasswordField passwordField;
    private LoginSuccessListener loginListener;

    public AdminLoginPanel(BookingService bookingService) {
        this.bookingService = bookingService;
        setLayout(new GridBagLayout());
        setBackground(UITheme.BG_DARK);

        // Center Login Card
        JPanel card = UITheme.createCardPanel();
        card.setLayout(new GridBagLayout());
        card.setPreferredSize(new Dimension(440, 390));
        card.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createMatteBorder(0, 0, 4, 0, UITheme.ACCENT_ROSE),
                BorderFactory.createCompoundBorder(
                        BorderFactory.createLineBorder(UITheme.CARD_BORDER, 1, true),
                        BorderFactory.createEmptyBorder(20, 24, 20, 24)
                )
        ));

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.insets = new Insets(8, 12, 8, 12);
        gbc.weightx = 1.0;

        int row = 0;

        // Title Header
        gbc.gridx = 0; gbc.gridy = row++;
        gbc.gridwidth = 2;
        JLabel title = new JLabel("🔒 Admin Portal Login", JLabel.CENTER);
        title.setFont(UITheme.FONT_TITLE);
        title.setForeground(UITheme.ACCENT_CYAN);
        card.add(title, gbc);

        gbc.gridy = row++;
        JLabel subtitle = new JLabel("Authenticate with your administrator credentials", JLabel.CENTER);
        subtitle.setFont(UITheme.FONT_SMALL);
        subtitle.setForeground(UITheme.TEXT_MUTED);
        card.add(subtitle, gbc);

        // Separator space
        gbc.gridy = row++;
        card.add(new JLabel(" "), gbc);

        // Username
        gbc.gridy = row++;
        gbc.gridwidth = 2;
        JLabel lblUser = new JLabel("Username:");
        lblUser.setFont(UITheme.FONT_BOLD);
        lblUser.setForeground(UITheme.TEXT_LIGHT);
        card.add(lblUser, gbc);

        gbc.gridy = row++;
        usernameField = UITheme.createTextField(20);
        card.add(usernameField, gbc);

        // Password
        gbc.gridy = row++;
        JLabel lblPass = new JLabel("Password:");
        lblPass.setFont(UITheme.FONT_BOLD);
        lblPass.setForeground(UITheme.TEXT_LIGHT);
        card.add(lblPass, gbc);

        gbc.gridy = row++;
        passwordField = new JPasswordField(20);
        passwordField.setFont(UITheme.FONT_REGULAR);
        passwordField.setBackground(UITheme.INPUT_BG);
        passwordField.setForeground(UITheme.TEXT_LIGHT);
        passwordField.setCaretColor(UITheme.TEXT_LIGHT);
        passwordField.setPreferredSize(new Dimension(passwordField.getPreferredSize().width, 36));
        passwordField.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(UITheme.CARD_BORDER, 1, true),
                BorderFactory.createEmptyBorder(6, 10, 6, 10)
        ));
        card.add(passwordField, gbc);

        // Submit Button
        gbc.gridy = row++;
        gbc.insets = new Insets(18, 12, 8, 12);
        JButton loginBtn = UITheme.createPrimaryButton("⚡ Secure Admin Login");
        loginBtn.setPreferredSize(new Dimension(220, 42));
        loginBtn.addActionListener(e -> handleLogin());
        card.add(loginBtn, gbc);

        // Default Credentials hint
        gbc.gridy = row++;
        gbc.insets = new Insets(4, 12, 8, 12);
        JLabel hint = new JLabel("Default Admin: admin / admin123", JLabel.CENTER);
        hint.setFont(UITheme.FONT_SMALL);
        hint.setForeground(UITheme.TEXT_MUTED);
        card.add(hint, gbc);

        // Listen for Enter key
        passwordField.addActionListener(e -> handleLogin());
        usernameField.addActionListener(e -> handleLogin());

        add(card);
    }

    private void handleLogin() {
        String username = usernameField.getText().trim();
        String password = new String(passwordField.getPassword()).trim();

        if (username.isEmpty() || password.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Please enter both username and password.",
                    "Input Error", JOptionPane.WARNING_MESSAGE);
            return;
        }

        try {
            Admin admin = bookingService.authenticateAdmin(username, password);
            if (admin != null) {
                JOptionPane.showMessageDialog(this,
                        "Welcome back, " + admin.getUsername() + "! Access granted to Admin Dashboard.",
                        "Login Success", JOptionPane.INFORMATION_MESSAGE);
                usernameField.setText("");
                passwordField.setText("");
                if (loginListener != null) {
                    loginListener.onAdminLoginSuccess(admin);
                }
            } else {
                JOptionPane.showMessageDialog(this,
                        "Invalid username or password. Please verify credentials.",
                        "Authentication Failed", JOptionPane.ERROR_MESSAGE);
                passwordField.setText("");
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this,
                    "Database error during authentication: " + e.getMessage(),
                    "Database Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    public void setLoginSuccessListener(LoginSuccessListener listener) {
        this.loginListener = listener;
    }
}
