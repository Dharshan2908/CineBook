package gui;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.sql.SQLException;
import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;
import model.Booking;
import service.BookingService;
import util.PosterManager;
import util.ValidationUtil;

/**
 * Customer Panel: View Existing Booking.
 * Search by Booking ID and displays detailed ticket details, status, and quick actions.
 */
public class ViewBookingPanel extends JPanel {

    public interface BookingActionListener {
        void onModifyRequested(int bookingId);
        void onBookingCancelled();
    }

    private final BookingService bookingService;
    private final JTextField searchIdField;
    private final JPanel detailsCard;
    private final JLabel lblPoster;
    private Booking currentBooking = null;
    private BookingActionListener actionListener;

    // Detail display fields
    private final JLabel lblBookingIdVal = new JLabel("-");
    private final JLabel lblCustomerVal = new JLabel("-");
    private final JLabel lblPhoneVal = new JLabel("-");
    private final JLabel lblMovieVal = new JLabel("-");
    private final JLabel lblShowVal = new JLabel("-");
    private final JLabel lblSeatsVal = new JLabel("-");
    private final JLabel lblTicketsVal = new JLabel("-");
    private final JLabel lblAmountVal = new JLabel("-");
    private final JLabel lblStatusVal = new JLabel("-");
    private final JLabel lblDateVal = new JLabel("-");

    private final JButton btnModify;
    private final JButton btnCancel;

    public ViewBookingPanel(BookingService bookingService) {
        this.bookingService = bookingService;
        setLayout(new BorderLayout(16, 16));
        setBackground(UITheme.BG_DARK);
        setBorder(BorderFactory.createEmptyBorder(16, 16, 16, 16));

        // Header
        JPanel header = new JPanel(new BorderLayout());
        header.setBackground(UITheme.BG_DARK);
        JLabel title = UITheme.createHeaderLabel("🔍 View & Track Existing Booking");
        JLabel sub = new JLabel("Enter your Booking ID to view your ticket reservation details and status.");
        sub.setFont(UITheme.FONT_REGULAR);
        sub.setForeground(UITheme.TEXT_MUTED);
        header.add(title, BorderLayout.NORTH);
        header.add(sub, BorderLayout.SOUTH);
        add(header, BorderLayout.NORTH);

        // Center Panel: Search bar + Details Card
        JPanel centerPanel = new JPanel(new BorderLayout(14, 14));
        centerPanel.setBackground(UITheme.BG_DARK);

        // Search Bar Card
        JPanel searchCard = UITheme.createCardPanel();
        searchCard.setLayout(new FlowLayout(FlowLayout.LEFT, 12, 10));

        JLabel searchPrompt = new JLabel("Enter Booking ID:");
        searchPrompt.setFont(UITheme.FONT_BOLD);
        searchPrompt.setForeground(UITheme.TEXT_LIGHT);
        searchCard.add(searchPrompt);

        searchIdField = UITheme.createTextField(12);
        searchCard.add(searchIdField);

        JButton searchBtn = UITheme.createPrimaryButton("Search Booking");
        searchBtn.addActionListener(e -> handleSearch());
        searchCard.add(searchBtn);

        JButton clearBtn = UITheme.createSecondaryButton("Clear");
        clearBtn.addActionListener(e -> clearDetails());
        searchCard.add(clearBtn);

        searchIdField.addActionListener(e -> handleSearch());
        centerPanel.add(searchCard, BorderLayout.NORTH);

        // Details Display Card with Poster
        detailsCard = UITheme.createCardPanel();
        detailsCard.setLayout(new BorderLayout(20, 10));

        // Poster panel on Left
        JPanel posterPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 0, 10));
        posterPanel.setOpaque(false);
        posterPanel.setPreferredSize(new Dimension(170, 250));
        lblPoster = new JLabel();
        lblPoster.setPreferredSize(new Dimension(150, 225));
        lblPoster.setBorder(BorderFactory.createLineBorder(UITheme.CARD_BORDER, 1));
        posterPanel.add(lblPoster);
        detailsCard.add(posterPanel, BorderLayout.WEST);

        // Fields table in Center
        JPanel fieldsPanel = new JPanel(new GridBagLayout());
        fieldsPanel.setOpaque(false);
        setupDetailsCard(fieldsPanel);
        detailsCard.add(fieldsPanel, BorderLayout.CENTER);

        centerPanel.add(detailsCard, BorderLayout.CENTER);

        // Action Buttons at bottom of Details Card
        JPanel actionPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT, 12, 10));
        actionPanel.setBackground(UITheme.BG_DARK);

        btnModify = UITheme.createPrimaryButton("✏ Modify This Booking");
        btnModify.setEnabled(false);
        btnModify.addActionListener(e -> {
            if (currentBooking != null && actionListener != null) {
                actionListener.onModifyRequested(currentBooking.getBookingId());
            }
        });

        btnCancel = UITheme.createDangerButton("✕ Cancel This Booking");
        btnCancel.setEnabled(false);
        btnCancel.addActionListener(e -> handleCancelCurrentBooking());

        actionPanel.add(btnModify);
        actionPanel.add(btnCancel);
        add(actionPanel, BorderLayout.SOUTH);

        add(centerPanel, BorderLayout.CENTER);
    }

    private void setupDetailsCard(JPanel target) {
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(8, 12, 8, 12);
        gbc.anchor = GridBagConstraints.WEST;

        int row = 0;
        addDetailRow(target, "Booking ID:", lblBookingIdVal, row++, gbc);
        addDetailRow(target, "Customer Name:", lblCustomerVal, row++, gbc);
        addDetailRow(target, "Phone Number:", lblPhoneVal, row++, gbc);
        addDetailRow(target, "Movie Title:", lblMovieVal, row++, gbc);
        addDetailRow(target, "Show Date & Time:", lblShowVal, row++, gbc);
        addDetailRow(target, "Seats Reserved:", lblSeatsVal, row++, gbc);
        addDetailRow(target, "Number of Tickets:", lblTicketsVal, row++, gbc);
        addDetailRow(target, "Total Amount Paid:", lblAmountVal, row++, gbc);
        addDetailRow(target, "Booking Date:", lblDateVal, row++, gbc);
        addDetailRow(target, "Booking Status:", lblStatusVal, row++, gbc);

        lblStatusVal.setFont(UITheme.FONT_SUBTITLE);
        lblBookingIdVal.setFont(UITheme.FONT_SUBTITLE);
        lblAmountVal.setFont(UITheme.FONT_SUBTITLE);
        lblAmountVal.setForeground(UITheme.SUCCESS);
    }

    private void addDetailRow(JPanel target, String labelText, JLabel valueLabel, int row, GridBagConstraints gbc) {
        gbc.gridx = 0;
        gbc.gridy = row;
        gbc.weightx = 0.3;
        JLabel lbl = new JLabel(labelText);
        lbl.setFont(UITheme.FONT_BOLD);
        lbl.setForeground(UITheme.TEXT_MUTED);
        target.add(lbl, gbc);

        gbc.gridx = 1;
        gbc.weightx = 0.7;
        valueLabel.setFont(UITheme.FONT_REGULAR);
        valueLabel.setForeground(UITheme.TEXT_LIGHT);
        target.add(valueLabel, gbc);
    }

    public void searchForBookingId(int bookingId) {
        searchIdField.setText(String.valueOf(bookingId));
        handleSearch();
    }

    private void handleSearch() {
        String idText = searchIdField.getText().trim();
        if (!ValidationUtil.isPositiveInteger(idText)) {
            JOptionPane.showMessageDialog(this, "Please enter a valid numeric Booking ID.",
                    "Input Error", JOptionPane.WARNING_MESSAGE);
            searchIdField.requestFocus();
            return;
        }

        int bookingId = Integer.parseInt(idText);
        try {
            Booking booking = bookingService.getBookingById(bookingId);
            if (booking == null) {
                clearDetails();
                JOptionPane.showMessageDialog(this, "No booking found with Booking ID: " + bookingId,
                        "Booking Not Found", JOptionPane.INFORMATION_MESSAGE);
                return;
            }

            displayBooking(booking);
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Database error retrieving booking: " + e.getMessage(),
                    "Database Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void displayBooking(Booking booking) {
        this.currentBooking = booking;
        lblBookingIdVal.setText("#" + booking.getBookingId());
        lblCustomerVal.setText(booking.getCustomerName());
        lblPhoneVal.setText(booking.getPhone());
        lblMovieVal.setText(booking.getMovieTitle());
        lblShowVal.setText(booking.getShowDate() + " at " + booking.getShowTime());
        lblSeatsVal.setText(booking.getSeats());
        lblTicketsVal.setText(String.valueOf(booking.getTickets()));
        lblAmountVal.setText(String.format("₹%.2f", booking.getTotalAmount()));
        lblDateVal.setText(booking.getBookingDate() != null ? booking.getBookingDate().toString() : "N/A");

        lblStatusVal.setText(booking.getStatus());
        if ("CONFIRMED".equalsIgnoreCase(booking.getStatus())) {
            lblStatusVal.setForeground(UITheme.SUCCESS);
            btnModify.setEnabled(true);
            btnCancel.setEnabled(true);
        } else {
            lblStatusVal.setForeground(UITheme.DANGER);
            btnModify.setEnabled(false);
            btnCancel.setEnabled(false);
        }

        lblPoster.setIcon(PosterManager.getPoster(booking.getMovieTitle(), 150, 225));
    }

    private void clearDetails() {
        currentBooking = null;
        lblPoster.setIcon(null);
        lblBookingIdVal.setText("-");
        lblCustomerVal.setText("-");
        lblPhoneVal.setText("-");
        lblMovieVal.setText("-");
        lblShowVal.setText("-");
        lblSeatsVal.setText("-");
        lblTicketsVal.setText("-");
        lblAmountVal.setText("-");
        lblDateVal.setText("-");
        lblStatusVal.setText("-");
        lblStatusVal.setForeground(UITheme.TEXT_DARK);
        btnModify.setEnabled(false);
        btnCancel.setEnabled(false);
    }

    private void handleCancelCurrentBooking() {
        if (currentBooking == null) return;

        int choice = JOptionPane.showConfirmDialog(this,
                "Are you sure you want to cancel booking #" + currentBooking.getBookingId() + " (" + currentBooking.getMovieTitle() + ")?\n"
                        + "Your seats (" + currentBooking.getSeats() + ") will be released immediately.",
                "Confirm Cancellation", JOptionPane.YES_NO_OPTION, JOptionPane.WARNING_MESSAGE);

        if (choice != JOptionPane.YES_OPTION) return;

        try {
            boolean success = bookingService.cancelBooking(currentBooking.getBookingId());
            if (success) {
                JOptionPane.showMessageDialog(this,
                        "Booking #" + currentBooking.getBookingId() + " has been successfully CANCELLED.\n"
                                + "The reserved seats have been released back to availability.",
                        "Cancellation Confirmed", JOptionPane.INFORMATION_MESSAGE);
                handleSearch(); // Refresh view
                if (actionListener != null) {
                    actionListener.onBookingCancelled();
                }
            } else {
                JOptionPane.showMessageDialog(this, "Failed to cancel booking. Please try again.", "Error", JOptionPane.ERROR_MESSAGE);
            }
        } catch (SQLException | IllegalStateException e) {
            JOptionPane.showMessageDialog(this, "Error cancelling booking: " + e.getMessage(), "Cancellation Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    public void setBookingActionListener(BookingActionListener listener) {
        this.actionListener = listener;
    }
}
