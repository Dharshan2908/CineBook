package gui;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.GridLayout;
import java.awt.Insets;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import javax.swing.BorderFactory;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextField;
import model.Movie;
import model.Show;
import service.BookingService;
import util.PosterManager;
import util.ValidationUtil;

/**
 * Customer Panel: Ticket Booking Flow.
 * Handles movie & show selection, customer inputs, interactive seat selection,
 * real-time price calculation, and transactional booking confirmation.
 */
public class BookingPanel extends JPanel {

    public interface BookingSuccessListener {
        void onBookingConfirmed(int bookingId);
    }

    private final BookingService bookingService;
    private final JComboBox<MovieItem> movieCombo;
    private final JComboBox<ShowItem> showCombo;
    private final JLabel moviePosterThumb;
    private final JTextField nameField;
    private final JTextField phoneField;
    private final JComboBox<Integer> ticketsCombo;
    private final JLabel pricePerTicketLabel;
    private final JLabel totalAmountLabel;
    private final JLabel selectedSeatsLabel;
    private final SeatGridPanel seatGridPanel;
    private final JButton confirmButton;

    private List<Movie> moviesList = new ArrayList<>();
    private List<Show> showsList = new ArrayList<>();
    private Show currentSelectedShow = null;
    private BookingSuccessListener successListener;

    public BookingPanel(BookingService bookingService) {
        this.bookingService = bookingService;
        setLayout(new BorderLayout(16, 16));
        setBackground(UITheme.BG_DARK);
        setBorder(BorderFactory.createEmptyBorder(16, 16, 16, 16));

        // Header
        JPanel header = new JPanel(new BorderLayout());
        header.setBackground(UITheme.BG_DARK);
        JLabel title = UITheme.createHeaderLabel("🎟 Reserve Your Cinema Seats");
        JLabel sub = new JLabel("Fill in customer details, choose your preferred show, and pick your seats on the visual grid.");
        sub.setFont(UITheme.FONT_REGULAR);
        sub.setForeground(UITheme.TEXT_MUTED);
        header.add(title, BorderLayout.NORTH);
        header.add(sub, BorderLayout.SOUTH);
        add(header, BorderLayout.NORTH);

        // Center Split: Left details form (scrollable), Right visual seat selection
        JPanel leftContainer = UITheme.createCardPanel();
        leftContainer.setLayout(new BorderLayout(0, 10));
        leftContainer.setPreferredSize(new Dimension(390, 620));

        JPanel formFields = new JPanel(new GridBagLayout());
        formFields.setOpaque(false);

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.insets = new Insets(2, 4, 2, 4);
        gbc.weightx = 1.0;

        int row = 0;

        // Movie Poster Preview Banner
        gbc.gridx = 0; gbc.gridy = row++;
        JPanel posterCard = new JPanel(new FlowLayout(FlowLayout.CENTER, 0, 2));
        posterCard.setOpaque(false);
        moviePosterThumb = new JLabel();
        moviePosterThumb.setPreferredSize(new Dimension(65, 92));
        moviePosterThumb.setBorder(BorderFactory.createLineBorder(UITheme.CARD_BORDER, 1));
        posterCard.add(moviePosterThumb);
        formFields.add(posterCard, gbc);

        // Movie Selection
        gbc.gridx = 0; gbc.gridy = row++;
        JLabel lblMovie = new JLabel("1. Select Movie:");
        lblMovie.setFont(UITheme.FONT_BOLD);
        lblMovie.setForeground(UITheme.TEXT_LIGHT);
        formFields.add(lblMovie, gbc);

        movieCombo = new JComboBox<>();
        movieCombo.setFont(UITheme.FONT_REGULAR);
        movieCombo.setBackground(UITheme.INPUT_BG);
        movieCombo.setForeground(UITheme.TEXT_LIGHT);
        movieCombo.setPreferredSize(new Dimension(280, 34));
        gbc.gridy = row++;
        formFields.add(movieCombo, gbc);

        // Show Selection
        gbc.gridy = row++;
        JLabel lblShow = new JLabel("2. Select Show & Time:");
        lblShow.setFont(UITheme.FONT_BOLD);
        lblShow.setForeground(UITheme.TEXT_LIGHT);
        formFields.add(lblShow, gbc);

        showCombo = new JComboBox<>();
        showCombo.setFont(UITheme.FONT_REGULAR);
        showCombo.setBackground(UITheme.INPUT_BG);
        showCombo.setForeground(UITheme.TEXT_LIGHT);
        showCombo.setPreferredSize(new Dimension(280, 34));
        gbc.gridy = row++;
        formFields.add(showCombo, gbc);

        // Customer Name
        gbc.gridy = row++;
        JLabel lblName = new JLabel("3. Customer Full Name:");
        lblName.setFont(UITheme.FONT_BOLD);
        lblName.setForeground(UITheme.TEXT_LIGHT);
        formFields.add(lblName, gbc);

        nameField = UITheme.createTextField(20);
        gbc.gridy = row++;
        formFields.add(nameField, gbc);

        // Phone Number
        gbc.gridy = row++;
        JLabel lblPhone = new JLabel("4. Phone Number (10 digits):");
        lblPhone.setFont(UITheme.FONT_BOLD);
        lblPhone.setForeground(UITheme.TEXT_LIGHT);
        formFields.add(lblPhone, gbc);

        phoneField = UITheme.createTextField(20);
        gbc.gridy = row++;
        formFields.add(phoneField, gbc);

        // Number of Tickets
        gbc.gridy = row++;
        JLabel lblTickets = new JLabel("5. Number of Tickets:");
        lblTickets.setFont(UITheme.FONT_BOLD);
        lblTickets.setForeground(UITheme.TEXT_LIGHT);
        formFields.add(lblTickets, gbc);

        Integer[] ticketOptions = {1, 2, 3, 4, 5, 6, 8, 10};
        ticketsCombo = new JComboBox<>(ticketOptions);
        ticketsCombo.setFont(UITheme.FONT_REGULAR);
        ticketsCombo.setBackground(UITheme.INPUT_BG);
        ticketsCombo.setForeground(UITheme.TEXT_LIGHT);
        ticketsCombo.setPreferredSize(new Dimension(280, 34));
        gbc.gridy = row++;
        formFields.add(ticketsCombo, gbc);

        // Price Information Box
        gbc.gridy = row++;
        JPanel priceSummary = new JPanel(new GridLayout(3, 1, 3, 3));
        priceSummary.setBackground(new Color(15, 23, 42));
        priceSummary.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(UITheme.CARD_BORDER, 1, true),
                BorderFactory.createEmptyBorder(6, 10, 6, 10)
        ));

        pricePerTicketLabel = new JLabel("Price per ticket: ₹0.00");
        pricePerTicketLabel.setFont(UITheme.FONT_REGULAR);
        pricePerTicketLabel.setForeground(UITheme.TEXT_MUTED);

        selectedSeatsLabel = new JLabel("Selected Seats: None (0/1)");
        selectedSeatsLabel.setFont(UITheme.FONT_BOLD);
        selectedSeatsLabel.setForeground(UITheme.ACCENT_GOLD);

        totalAmountLabel = new JLabel("Total Payable: ₹0.00");
        totalAmountLabel.setFont(UITheme.FONT_SUBTITLE);
        totalAmountLabel.setForeground(UITheme.SUCCESS);

        priceSummary.add(pricePerTicketLabel);
        priceSummary.add(selectedSeatsLabel);
        priceSummary.add(totalAmountLabel);
        formFields.add(priceSummary, gbc);

        // Wrap fields in smooth scroll pane
        JScrollPane formScroll = new JScrollPane(formFields);
        formScroll.setBorder(null);
        formScroll.setOpaque(false);
        formScroll.getViewport().setOpaque(false);
        formScroll.getVerticalScrollBar().setUnitIncrement(16);
        formScroll.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);
        leftContainer.add(formScroll, BorderLayout.CENTER);

        // Pinned Bottom Button Bar - ALWAYS 100% VISIBLE
        JPanel confirmBar = new JPanel(new BorderLayout());
        confirmBar.setOpaque(false);
        confirmBar.setBorder(BorderFactory.createEmptyBorder(6, 2, 2, 2));

        confirmButton = UITheme.createPrimaryButton("⚡ Confirm & Book Ticket");
        confirmButton.setPreferredSize(new Dimension(320, 48));
        confirmButton.setFont(new Font("Segoe UI", Font.BOLD, 15));
        confirmButton.addActionListener(e -> handleConfirmBooking());
        confirmBar.add(confirmButton, BorderLayout.CENTER);

        leftContainer.add(confirmBar, BorderLayout.SOUTH);

        // Right Card: Seat Selection Grid
        JPanel rightCard = UITheme.createCardPanel();
        rightCard.setLayout(new BorderLayout(10, 10));

        JPanel rightHeader = new JPanel(new BorderLayout());
        rightHeader.setBackground(UITheme.CARD_BG);
        JLabel seatHeaderLbl = new JLabel("6. Select Your Seats");
        seatHeaderLbl.setFont(UITheme.FONT_SUBTITLE);
        seatHeaderLbl.setForeground(UITheme.TEXT_LIGHT);
        rightHeader.add(seatHeaderLbl, BorderLayout.WEST);

        JButton clearSeatsBtn = UITheme.createSecondaryButton("Clear Selection");
        rightHeader.add(clearSeatsBtn, BorderLayout.EAST);
        rightCard.add(rightHeader, BorderLayout.NORTH);

        seatGridPanel = new SeatGridPanel();
        seatGridPanel.setMaxSelectable(1);
        clearSeatsBtn.addActionListener(e -> seatGridPanel.clearSelection());

        rightCard.add(new JScrollPane(seatGridPanel), BorderLayout.CENTER);

        // Layout center split
        JPanel center = new JPanel(new BorderLayout(12, 12));
        center.setBackground(UITheme.BG_DARK);
        center.add(leftContainer, BorderLayout.WEST);
        center.add(rightCard, BorderLayout.CENTER);
        add(center, BorderLayout.CENTER);

        // Listeners
        movieCombo.addActionListener(e -> onMovieChanged());
        showCombo.addActionListener(e -> onShowChanged());
        ticketsCombo.addActionListener(e -> onTicketCountChanged());

        seatGridPanel.setSeatSelectionListener(selected -> {
            int ticketCount = (Integer) ticketsCombo.getSelectedItem();
            selectedSeatsLabel.setText("Selected Seats: " + (selected.isEmpty() ? "None" : String.join(", ", selected))
                    + " (" + selected.size() + "/" + ticketCount + ")");
            if (selected.size() == ticketCount) {
                selectedSeatsLabel.setForeground(UITheme.SUCCESS);
            } else {
                selectedSeatsLabel.setForeground(UITheme.ACCENT_GOLD);
            }
        });

        // Load initial data
        refreshData();
    }

    public void refreshData() {
        try {
            moviesList = bookingService.getAllMovies();
            DefaultComboBoxModel<MovieItem> mModel = new DefaultComboBoxModel<>();
            for (Movie m : moviesList) {
                mModel.addElement(new MovieItem(m));
            }
            movieCombo.setModel(mModel);

            if (!moviesList.isEmpty()) {
                onMovieChanged();
            } else {
                showCombo.setModel(new DefaultComboBoxModel<>());
                seatGridPanel.buildGrid(50);
                seatGridPanel.setBookedSeats(new ArrayList<>());
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this,
                    "Failed to load movies for booking: " + e.getMessage(),
                    "Database Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    public void preselectShow(Movie movie, Show show) {
        refreshData();
        // Select movie
        for (int i = 0; i < movieCombo.getItemCount(); i++) {
            MovieItem item = movieCombo.getItemAt(i);
            if (item.movie.getMovieId() == movie.getMovieId()) {
                movieCombo.setSelectedIndex(i);
                break;
            }
        }
        // Select show
        for (int i = 0; i < showCombo.getItemCount(); i++) {
            ShowItem item = showCombo.getItemAt(i);
            if (item.show.getShowId() == show.getShowId()) {
                showCombo.setSelectedIndex(i);
                break;
            }
        }
    }

    private void onMovieChanged() {
        MovieItem selected = (MovieItem) movieCombo.getSelectedItem();
        if (selected == null) {
            moviePosterThumb.setIcon(null);
            return;
        }

        moviePosterThumb.setIcon(PosterManager.getPoster(selected.movie.getTitle(), 85, 120));

        try {
            showsList = bookingService.getShowsByMovieId(selected.movie.getMovieId());
            DefaultComboBoxModel<ShowItem> sModel = new DefaultComboBoxModel<>();
            for (Show s : showsList) {
                sModel.addElement(new ShowItem(s));
            }
            showCombo.setModel(sModel);

            if (!showsList.isEmpty()) {
                onShowChanged();
            } else {
                currentSelectedShow = null;
                seatGridPanel.setBookedSeats(new ArrayList<>());
                updatePricing();
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Failed to load shows: " + e.getMessage(),
                    "Database Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void onShowChanged() {
        ShowItem selected = (ShowItem) showCombo.getSelectedItem();
        if (selected == null) {
            currentSelectedShow = null;
            updatePricing();
            return;
        }

        currentSelectedShow = selected.show;
        try {
            // Configure seat grid capacity and fetch currently booked seats
            seatGridPanel.buildGrid(currentSelectedShow.getTotalSeats());
            List<String> bookedSeats = bookingService.getBookedSeats(currentSelectedShow.getShowId());
            seatGridPanel.setBookedSeats(bookedSeats);
            onTicketCountChanged();
            updatePricing();
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Error fetching booked seats: " + e.getMessage(),
                    "Database Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void onTicketCountChanged() {
        Integer count = (Integer) ticketsCombo.getSelectedItem();
        if (count == null) count = 1;
        seatGridPanel.setMaxSelectable(count);
        updatePricing();
    }

    private void updatePricing() {
        int tickets = (Integer) (ticketsCombo.getSelectedItem() != null ? ticketsCombo.getSelectedItem() : 1);
        if (currentSelectedShow != null) {
            double price = currentSelectedShow.getPrice();
            double total = tickets * price;
            pricePerTicketLabel.setText(String.format("Price per ticket: ₹%.2f", price));
            totalAmountLabel.setText(String.format("Total Payable: ₹%.2f", total));
        } else {
            pricePerTicketLabel.setText("Price per ticket: ₹0.00");
            totalAmountLabel.setText("Total Payable: ₹0.00");
        }
    }

    private void handleConfirmBooking() {
        // 1. Movie & Show validation
        if (movieCombo.getSelectedItem() == null) {
            JOptionPane.showMessageDialog(this, "Please select a movie.", "Validation Error", JOptionPane.WARNING_MESSAGE);
            return;
        }
        if (currentSelectedShow == null) {
            JOptionPane.showMessageDialog(this, "Please select a valid show.", "Validation Error", JOptionPane.WARNING_MESSAGE);
            return;
        }

        // 2. Customer name validation
        String name = nameField.getText().trim();
        if (!ValidationUtil.isValidName(name)) {
            JOptionPane.showMessageDialog(this, "Please enter a valid customer name (at least 2 letters, alphabetic).",
                    "Invalid Name", JOptionPane.WARNING_MESSAGE);
            nameField.requestFocus();
            return;
        }

        // 3. Phone validation
        String phone = phoneField.getText().trim();
        if (!ValidationUtil.isValidPhone(phone)) {
            JOptionPane.showMessageDialog(this, "Please enter a valid 10-digit mobile phone number.",
                    "Invalid Phone Number", JOptionPane.WARNING_MESSAGE);
            phoneField.requestFocus();
            return;
        }

        // 4. Tickets & Seat count matching
        int ticketCount = (Integer) ticketsCombo.getSelectedItem();
        List<String> selectedSeats = seatGridPanel.getSelectedSeats();

        if (selectedSeats.size() != ticketCount) {
            JOptionPane.showMessageDialog(this,
                    "You have chosen " + ticketCount + " ticket(s), but selected " + selectedSeats.size() + " seat(s).\n"
                            + "Please select exactly " + ticketCount + " seat(s) on the visual grid.",
                    "Seat Selection Mismatch", JOptionPane.WARNING_MESSAGE);
            return;
        }

        // 5. Confirmation preview dialog
        double totalAmount = ticketCount * currentSelectedShow.getPrice();
        MovieItem movieItem = (MovieItem) movieCombo.getSelectedItem();

        String confirmationMsg = String.format(
                "Confirm Booking Details:\n\n"
                        + "Customer: %s\n"
                        + "Phone: %s\n"
                        + "Movie: %s\n"
                        + "Show Time: %s (%s)\n"
                        + "Tickets: %d\n"
                        + "Selected Seats: %s\n"
                        + "Total Amount: ₹%.2f\n\n"
                        + "Proceed with booking?",
                name, phone, movieItem.movie.getTitle(),
                currentSelectedShow.getShowTime(), currentSelectedShow.getShowDate(),
                ticketCount, String.join(", ", selectedSeats), totalAmount
        );

        int confirmChoice = JOptionPane.showConfirmDialog(this, confirmationMsg, "Confirm Booking", JOptionPane.YES_NO_OPTION);
        if (confirmChoice != JOptionPane.YES_OPTION) {
            return;
        }

        // 6. Execute booking via service
        try {
            int bookingId = bookingService.createBooking(
                    currentSelectedShow.getShowId(),
                    name,
                    phone,
                    ticketCount,
                    selectedSeats
            );

            // Display formal booking confirmation screen
            String receipt = "========================================\n"
                    + "       BOOKING CONFIRMATION RECEIPT       \n"
                    + "========================================\n"
                    + "Booking ID   : " + bookingId + "\n"
                    + "Customer     : " + name + "\n"
                    + "Phone        : " + phone + "\n"
                    + "Movie        : " + movieItem.movie.getTitle() + "\n"
                    + "Show Date    : " + currentSelectedShow.getShowDate() + "\n"
                    + "Show Time    : " + currentSelectedShow.getShowTime() + "\n"
                    + "Seats        : " + String.join(", ", selectedSeats) + "\n"
                    + "Tickets      : " + ticketCount + "\n"
                    + "Total Amount : ₹" + String.format("%.2f", totalAmount) + "\n"
                    + "Status       : CONFIRMED\n"
                    + "========================================\n"
                    + "Thank you for booking with us! Enjoy your movie.";

            JOptionPane.showMessageDialog(this, receipt, "Booking Successful!", JOptionPane.INFORMATION_MESSAGE);

            // Reset form
            nameField.setText("");
            phoneField.setText("");
            ticketsCombo.setSelectedIndex(0);
            onShowChanged();

            if (successListener != null) {
                successListener.onBookingConfirmed(bookingId);
            }
        } catch (IllegalArgumentException | IllegalStateException ex) {
            JOptionPane.showMessageDialog(this, ex.getMessage(), "Booking Notice", JOptionPane.WARNING_MESSAGE);
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, "Database transaction error: " + ex.getMessage(),
                    "Booking Failed", JOptionPane.ERROR_MESSAGE);
        }
    }

    public void setBookingSuccessListener(BookingSuccessListener listener) {
        this.successListener = listener;
    }

    // Helper wrapper classes for ComboBox items
    private static class MovieItem {
        final Movie movie;
        MovieItem(Movie movie) { this.movie = movie; }
        @Override
        public String toString() {
            return movie.getTitle() + " (" + movie.getLanguage() + " - " + movie.getGenre() + ")";
        }
    }

    private static class ShowItem {
        final Show show;
        ShowItem(Show show) { this.show = show; }
        @Override
        public String toString() {
            return show.getShowDate() + " at " + show.getShowTime()
                    + " | ₹" + show.getPrice() + " (" + show.getAvailableSeats() + " seats left)";
        }
    }
}
