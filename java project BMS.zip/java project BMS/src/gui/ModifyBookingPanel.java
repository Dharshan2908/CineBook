package gui;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextField;
import model.Booking;
import model.Show;
import service.BookingService;
import util.ValidationUtil;

/**
 * Customer Panel: Modify Existing Booking.
 * Allows searching by Booking ID, altering customer contact details,
 * changing ticket quantity, and re-allocating seats on the visual grid.
 */
public class ModifyBookingPanel extends JPanel {

    public interface ModificationSuccessListener {
        void onBookingModified(int bookingId);
    }

    private final BookingService bookingService;
    private final JTextField searchBookingIdField;
    private final JLabel lblMovieShowInfo;
    private final JTextField nameField;
    private final JTextField phoneField;
    private final JComboBox<Integer> ticketsCombo;
    private final JLabel pricePerTicketLabel;
    private final JLabel totalAmountLabel;
    private final JLabel selectedSeatsLabel;
    private final SeatGridPanel seatGridPanel;
    private final JButton updateButton;

    private Booking loadedBooking = null;
    private Show loadedShow = null;
    private ModificationSuccessListener successListener;

    public ModifyBookingPanel(BookingService bookingService) {
        this.bookingService = bookingService;
        setLayout(new BorderLayout(16, 16));
        setBackground(UITheme.BG_DARK);
        setBorder(BorderFactory.createEmptyBorder(16, 16, 16, 16));

        // Header
        JPanel header = new JPanel(new BorderLayout());
        header.setBackground(UITheme.BG_DARK);
        JLabel title = UITheme.createHeaderLabel("✏ Modify Your Cinema Booking");
        JLabel sub = new JLabel("Fetch your existing booking, update your contact details, and re-pick your seats if needed.");
        sub.setFont(UITheme.FONT_REGULAR);
        sub.setForeground(UITheme.TEXT_MUTED);
        header.add(title, BorderLayout.NORTH);
        header.add(sub, BorderLayout.SOUTH);
        add(header, BorderLayout.NORTH);

        // Center split: Search & Form on Left, Seat Grid on Right
        JPanel leftContainer = new JPanel(new BorderLayout(10, 10));
        leftContainer.setBackground(UITheme.BG_DARK);
        leftContainer.setPreferredSize(new Dimension(390, 620));

        // Search Card (Single clean row: NEVER wraps or clips)
        JPanel searchCard = UITheme.createCardPanel();
        searchCard.setLayout(new BorderLayout(10, 0));
        searchCard.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(UITheme.CARD_BORDER, 1, true),
                BorderFactory.createEmptyBorder(10, 12, 10, 12)
        ));

        JLabel searchPrompt = new JLabel("Booking ID:");
        searchPrompt.setFont(UITheme.FONT_BOLD);
        searchPrompt.setForeground(UITheme.TEXT_LIGHT);
        searchCard.add(searchPrompt, BorderLayout.WEST);

        searchBookingIdField = UITheme.createTextField(8);
        searchCard.add(searchBookingIdField, BorderLayout.CENTER);

        JButton loadBtn = UITheme.createPrimaryButton("🔍 Fetch");
        loadBtn.setFont(UITheme.FONT_BOLD);
        loadBtn.setPreferredSize(new Dimension(100, 36));
        loadBtn.addActionListener(e -> handleFetchBooking());
        searchCard.add(loadBtn, BorderLayout.EAST);

        searchBookingIdField.addActionListener(e -> handleFetchBooking());
        leftContainer.add(searchCard, BorderLayout.NORTH);

        // Edit Form Card (Scrollable fields + Pinned South Action Button)
        JPanel formCard = UITheme.createCardPanel();
        formCard.setLayout(new BorderLayout(0, 8));

        JPanel formFields = new JPanel(new GridBagLayout());
        formFields.setOpaque(false);

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.insets = new Insets(3, 4, 3, 4);
        gbc.weightx = 1.0;

        int row = 0;

        // Movie / Show Fixed Info
        gbc.gridx = 0; gbc.gridy = row++;
        JLabel lblShowTitle = new JLabel("Movie & Show (Fixed):");
        lblShowTitle.setFont(UITheme.FONT_BOLD);
        lblShowTitle.setForeground(UITheme.TEXT_LIGHT);
        formFields.add(lblShowTitle, gbc);

        lblMovieShowInfo = new JLabel("None loaded");
        lblMovieShowInfo.setFont(UITheme.FONT_REGULAR);
        lblMovieShowInfo.setForeground(UITheme.ACCENT_CYAN);
        gbc.gridy = row++;
        formFields.add(lblMovieShowInfo, gbc);

        // Name
        gbc.gridx = 0; gbc.gridy = row++;
        JLabel lblName = new JLabel("Customer Name:");
        lblName.setFont(UITheme.FONT_BOLD);
        lblName.setForeground(UITheme.TEXT_LIGHT);
        formFields.add(lblName, gbc);

        nameField = UITheme.createTextField(20);
        nameField.setEnabled(false);
        gbc.gridy = row++;
        formFields.add(nameField, gbc);

        // Phone
        gbc.gridx = 0; gbc.gridy = row++;
        JLabel lblPhone = new JLabel("Phone Number:");
        lblPhone.setFont(UITheme.FONT_BOLD);
        lblPhone.setForeground(UITheme.TEXT_LIGHT);
        formFields.add(lblPhone, gbc);

        phoneField = UITheme.createTextField(20);
        phoneField.setEnabled(false);
        gbc.gridy = row++;
        formFields.add(phoneField, gbc);

        // Ticket Count
        gbc.gridy = row++;
        JLabel lblTickets = new JLabel("Number of Tickets:");
        lblTickets.setFont(UITheme.FONT_BOLD);
        lblTickets.setForeground(UITheme.TEXT_LIGHT);
        formFields.add(lblTickets, gbc);

        Integer[] ticketOptions = {1, 2, 3, 4, 5, 6, 8, 10};
        ticketsCombo = new JComboBox<>(ticketOptions);
        ticketsCombo.setFont(UITheme.FONT_REGULAR);
        ticketsCombo.setBackground(UITheme.INPUT_BG);
        ticketsCombo.setForeground(UITheme.TEXT_LIGHT);
        ticketsCombo.setEnabled(false);
        ticketsCombo.addActionListener(e -> onTicketCountChanged());
        gbc.gridy = row++;
        formFields.add(ticketsCombo, gbc);

        // Price Summary
        gbc.gridy = row++;
        JPanel priceSummary = new JPanel(new java.awt.GridLayout(3, 1, 3, 3));
        priceSummary.setBackground(new Color(15, 23, 42));
        priceSummary.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(UITheme.CARD_BORDER, 1, true),
                BorderFactory.createEmptyBorder(6, 8, 6, 8)
        ));

        pricePerTicketLabel = new JLabel("Price per ticket: ₹0.00");
        pricePerTicketLabel.setFont(UITheme.FONT_REGULAR);
        pricePerTicketLabel.setForeground(UITheme.TEXT_MUTED);

        selectedSeatsLabel = new JLabel("Selected Seats: None (0/0)");
        selectedSeatsLabel.setFont(UITheme.FONT_BOLD);
        selectedSeatsLabel.setForeground(UITheme.ACCENT_GOLD);

        totalAmountLabel = new JLabel("Updated Total: ₹0.00");
        totalAmountLabel.setFont(UITheme.FONT_SUBTITLE);
        totalAmountLabel.setForeground(UITheme.SUCCESS);

        priceSummary.add(pricePerTicketLabel);
        priceSummary.add(selectedSeatsLabel);
        priceSummary.add(totalAmountLabel);
        formFields.add(priceSummary, gbc);

        // Wrap fields in smooth scroll pane
        JScrollPane formScroll = new JScrollPane(formFields);
        formScroll.setBorder(null);
        formScroll.setOpaque(false);
        formScroll.getViewport().setOpaque(false);
        formScroll.getVerticalScrollBar().setUnitIncrement(16);
        formScroll.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);
        formCard.add(formScroll, BorderLayout.CENTER);

        // Pinned Bottom Update Button - ALWAYS 100% VISIBLE
        JPanel updateBar = new JPanel(new BorderLayout());
        updateBar.setOpaque(false);
        updateBar.setBorder(BorderFactory.createEmptyBorder(6, 2, 2, 2));

        updateButton = UITheme.createPrimaryButton("💾 Save & Update Booking");
        updateButton.setEnabled(false);
        updateButton.setPreferredSize(new Dimension(300, 46));
        updateButton.setFont(new Font("Segoe UI", Font.BOLD, 15));
        updateButton.addActionListener(e -> handleUpdateBooking());
        updateBar.add(updateButton, BorderLayout.CENTER);

        formCard.add(updateBar, BorderLayout.SOUTH);

        leftContainer.add(formCard, BorderLayout.CENTER);

        // Right Card: Seat Selection Grid
        JPanel rightCard = UITheme.createCardPanel();
        rightCard.setLayout(new BorderLayout(10, 10));

        JPanel rightHeader = new JPanel(new BorderLayout());
        rightHeader.setBackground(UITheme.CARD_BG);
        JLabel seatHeaderLbl = new JLabel("Re-Select Seats (Your original seats are highlighted & available)");
        seatHeaderLbl.setFont(UITheme.FONT_SUBTITLE);
        seatHeaderLbl.setForeground(UITheme.TEXT_LIGHT);
        rightHeader.add(seatHeaderLbl, BorderLayout.WEST);

        JButton clearSeatsBtn = UITheme.createSecondaryButton("Clear Seats");
        rightHeader.add(clearSeatsBtn, BorderLayout.EAST);
        rightCard.add(rightHeader, BorderLayout.NORTH);

        seatGridPanel = new SeatGridPanel();
        seatGridPanel.setInteractive(false);
        clearSeatsBtn.addActionListener(e -> seatGridPanel.clearSelection());

        rightCard.add(new JScrollPane(seatGridPanel), BorderLayout.CENTER);

        // Layout
        JPanel center = new JPanel(new BorderLayout(12, 12));
        center.setBackground(UITheme.BG_DARK);
        center.add(leftContainer, BorderLayout.WEST);
        center.add(rightCard, BorderLayout.CENTER);
        add(center, BorderLayout.CENTER);

        seatGridPanel.setSeatSelectionListener(selected -> {
            int ticketCount = (Integer) (ticketsCombo.getSelectedItem() != null ? ticketsCombo.getSelectedItem() : 1);
            selectedSeatsLabel.setText("Selected Seats: " + (selected.isEmpty() ? "None" : String.join(", ", selected))
                    + " (" + selected.size() + "/" + ticketCount + ")");
            if (selected.size() == ticketCount) {
                selectedSeatsLabel.setForeground(UITheme.SUCCESS);
            } else {
                selectedSeatsLabel.setForeground(UITheme.WARNING);
            }
        });
    }

    public void loadBookingForModification(int bookingId) {
        searchBookingIdField.setText(String.valueOf(bookingId));
        handleFetchBooking();
    }

    private void handleFetchBooking() {
        String idText = searchBookingIdField.getText().trim();
        if (!ValidationUtil.isPositiveInteger(idText)) {
            JOptionPane.showMessageDialog(this, "Please enter a valid numeric Booking ID.", "Input Error", JOptionPane.WARNING_MESSAGE);
            return;
        }

        int bookingId = Integer.parseInt(idText);
        try {
            Booking booking = bookingService.getBookingById(bookingId);
            if (booking == null) {
                JOptionPane.showMessageDialog(this, "No booking found with Booking ID: " + bookingId, "Not Found", JOptionPane.INFORMATION_MESSAGE);
                resetForm();
                return;
            }

            if ("CANCELLED".equalsIgnoreCase(booking.getStatus())) {
                JOptionPane.showMessageDialog(this, "Cannot modify booking #" + bookingId + " because it is CANCELLED.", "Cancelled Booking", JOptionPane.WARNING_MESSAGE);
                resetForm();
                return;
            }

            Show show = bookingService.getShowById(booking.getShowId());
            if (show == null) {
                JOptionPane.showMessageDialog(this, "Could not load show information for this booking.", "Error", JOptionPane.ERROR_MESSAGE);
                resetForm();
                return;
            }

            loadedBooking = booking;
            loadedShow = show;

            // Populate form
            lblMovieShowInfo.setText(booking.getMovieTitle() + " | " + booking.getShowDate() + " " + booking.getShowTime());
            nameField.setText(booking.getCustomerName());
            phoneField.setText(booking.getPhone());
            ticketsCombo.setSelectedItem(booking.getTickets());

            nameField.setEnabled(true);
            phoneField.setEnabled(true);
            ticketsCombo.setEnabled(true);
            updateButton.setEnabled(true);
            seatGridPanel.setInteractive(true);

            // Rebuild seat grid and exclude this booking from booked seats so current seats are available!
            seatGridPanel.buildGrid(show.getTotalSeats());
            List<String> bookedByOthers = bookingService.getBookedSeatsExcludingBooking(show.getShowId(), bookingId);
            seatGridPanel.setBookedSeats(bookedByOthers);

            // Pre-select current booking's seats
            List<String> currentSeatsList = new ArrayList<>();
            if (booking.getSeats() != null) {
                for (String s : booking.getSeats().split(",")) {
                    currentSeatsList.add(s.trim());
                }
            }
            seatGridPanel.setMaxSelectable(booking.getTickets());
            seatGridPanel.setSelectedSeats(currentSeatsList);

            updatePricing();
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Database error: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void onTicketCountChanged() {
        if (loadedShow == null) return;
        Integer count = (Integer) ticketsCombo.getSelectedItem();
        if (count == null) count = 1;
        seatGridPanel.setMaxSelectable(count);
        updatePricing();
    }

    private void updatePricing() {
        if (loadedShow != null) {
            int tickets = (Integer) (ticketsCombo.getSelectedItem() != null ? ticketsCombo.getSelectedItem() : 1);
            double price = loadedShow.getPrice();
            double total = tickets * price;
            pricePerTicketLabel.setText(String.format("Price per ticket: ₹%.2f", price));
            totalAmountLabel.setText(String.format("Updated Total: ₹%.2f", total));
        } else {
            pricePerTicketLabel.setText("Price per ticket: ₹0.00");
            totalAmountLabel.setText("Updated Total: ₹0.00");
        }
    }

    private void handleUpdateBooking() {
        if (loadedBooking == null || loadedShow == null) return;

        String name = nameField.getText().trim();
        if (!ValidationUtil.isValidName(name)) {
            JOptionPane.showMessageDialog(this, "Please enter a valid customer name.", "Validation Error", JOptionPane.WARNING_MESSAGE);
            return;
        }

        String phone = phoneField.getText().trim();
        if (!ValidationUtil.isValidPhone(phone)) {
            JOptionPane.showMessageDialog(this, "Please enter a valid 10-digit phone number.", "Validation Error", JOptionPane.WARNING_MESSAGE);
            return;
        }

        int tickets = (Integer) ticketsCombo.getSelectedItem();
        List<String> selectedSeats = seatGridPanel.getSelectedSeats();

        if (selectedSeats.size() != tickets) {
            JOptionPane.showMessageDialog(this,
                    "Ticket count is " + tickets + ", but you selected " + selectedSeats.size() + " seat(s).\n"
                            + "Please select exactly " + tickets + " seat(s).",
                    "Seat Count Mismatch", JOptionPane.WARNING_MESSAGE);
            return;
        }

        double newTotal = tickets * loadedShow.getPrice();
        int confirm = JOptionPane.showConfirmDialog(this,
                "Confirm Booking #" + loadedBooking.getBookingId() + " Updates:\n\n"
                        + "Customer: " + name + "\n"
                        + "Phone: " + phone + "\n"
                        + "Tickets: " + tickets + "\n"
                        + "Seats: " + String.join(", ", selectedSeats) + "\n"
                        + "Updated Total: ₹" + String.format("%.2f", newTotal) + "\n\n"
                        + "Save these changes?",
                "Confirm Changes", JOptionPane.YES_NO_OPTION);

        if (confirm != JOptionPane.YES_OPTION) return;

        try {
            boolean success = bookingService.modifyBooking(
                    loadedBooking.getBookingId(),
                    name,
                    phone,
                    tickets,
                    selectedSeats
            );

            if (success) {
                JOptionPane.showMessageDialog(this,
                        "Booking #" + loadedBooking.getBookingId() + " has been successfully updated in MySQL!\n"
                                + "New Seats: " + String.join(", ", selectedSeats) + "\n"
                                + "New Amount: ₹" + String.format("%.2f", newTotal),
                        "Booking Updated", JOptionPane.INFORMATION_MESSAGE);

                if (successListener != null) {
                    successListener.onBookingModified(loadedBooking.getBookingId());
                }
                resetForm();
            }
        } catch (IllegalArgumentException | IllegalStateException e) {
            JOptionPane.showMessageDialog(this, e.getMessage(), "Update Notice", JOptionPane.WARNING_MESSAGE);
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Database update error: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void resetForm() {
        loadedBooking = null;
        loadedShow = null;
        lblMovieShowInfo.setText("None loaded");
        nameField.setText("");
        phoneField.setText("");
        nameField.setEnabled(false);
        phoneField.setEnabled(false);
        ticketsCombo.setEnabled(false);
        updateButton.setEnabled(false);
        seatGridPanel.clearSelection();
        seatGridPanel.setInteractive(false);
        pricePerTicketLabel.setText("Price per ticket: ₹0.00");
        totalAmountLabel.setText("Updated Total: ₹0.00");
        selectedSeatsLabel.setText("Selected Seats: None (0/0)");
    }

    public void setModificationSuccessListener(ModificationSuccessListener listener) {
        this.successListener = listener;
    }
}
