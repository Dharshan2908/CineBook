package gui;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.GridLayout;
import java.sql.SQLException;
import java.util.List;
import javax.swing.BorderFactory;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import model.Movie;
import model.Show;
import service.BookingService;

/**
 * Admin Panel: Seat Availability & Visual Hall Layout.
 * Real-time inspection of total, booked, and remaining seats for any show.
 */
public class SeatAvailabilityPanel extends JPanel {

    private final BookingService bookingService;
    private final JComboBox<MovieItem> movieCombo;
    private final JComboBox<ShowItem> showCombo;
    private final JLabel lblTotalSeats;
    private final JLabel lblBookedSeats;
    private final JLabel lblAvailableSeats;
    private final SeatGridPanel seatGridPanel;

    private List<Movie> movieList;
    private List<Show> showList;

    public SeatAvailabilityPanel(BookingService bookingService) {
        this.bookingService = bookingService;
        setLayout(new BorderLayout(14, 14));
        setBackground(UITheme.BG_DARK);
        setBorder(BorderFactory.createEmptyBorder(16, 16, 16, 16));

        // Top Header
        JPanel topHeader = new JPanel(new BorderLayout());
        topHeader.setBackground(UITheme.BG_DARK);
        JLabel title = UITheme.createHeaderLabel("🎭 Live Seat Availability & Hall View");
        JLabel sub = new JLabel("Select any movie and screening show to view real-time theater seating occupation.");
        sub.setFont(UITheme.FONT_REGULAR);
        sub.setForeground(UITheme.TEXT_MUTED);
        topHeader.add(title, BorderLayout.NORTH);
        topHeader.add(sub, BorderLayout.SOUTH);
        add(topHeader, BorderLayout.NORTH);

        // Center Container
        JPanel center = new JPanel(new BorderLayout(12, 12));
        center.setBackground(UITheme.BG_DARK);

        // Selectors and Statistics Card
        JPanel topControlCard = UITheme.createCardPanel();
        topControlCard.setLayout(new BorderLayout(10, 10));

        JPanel selectorsPanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 14, 6));
        selectorsPanel.setBackground(UITheme.CARD_BG);

        JLabel lblM = new JLabel("Select Movie:");
        lblM.setForeground(UITheme.TEXT_LIGHT);
        selectorsPanel.add(lblM);
        movieCombo = new JComboBox<>();
        movieCombo.setFont(UITheme.FONT_REGULAR);
        movieCombo.setBackground(UITheme.INPUT_BG);
        movieCombo.setForeground(UITheme.TEXT_LIGHT);
        movieCombo.setPreferredSize(new Dimension(240, 36));
        selectorsPanel.add(movieCombo);

        JLabel lblS = new JLabel("Select Show:");
        lblS.setForeground(UITheme.TEXT_LIGHT);
        selectorsPanel.add(lblS);
        showCombo = new JComboBox<>();
        showCombo.setFont(UITheme.FONT_REGULAR);
        showCombo.setBackground(UITheme.INPUT_BG);
        showCombo.setForeground(UITheme.TEXT_LIGHT);
        showCombo.setPreferredSize(new Dimension(320, 36));
        selectorsPanel.add(showCombo);

        topControlCard.add(selectorsPanel, BorderLayout.NORTH);

        // Stats summary chips
        JPanel statsPanel = new JPanel(new GridLayout(1, 3, 14, 0));
        statsPanel.setBackground(UITheme.CARD_BG);
        statsPanel.setBorder(BorderFactory.createEmptyBorder(8, 4, 8, 4));

        lblTotalSeats = createStatBadge("Total Capacity", "50", UITheme.ACCENT_CYAN);
        lblBookedSeats = createStatBadge("Booked Seats", "0", UITheme.ACCENT_ROSE);
        lblAvailableSeats = createStatBadge("Available Seats", "50", UITheme.SUCCESS);

        statsPanel.add(lblTotalSeats.getParent());
        statsPanel.add(lblBookedSeats.getParent());
        statsPanel.add(lblAvailableSeats.getParent());

        topControlCard.add(statsPanel, BorderLayout.SOUTH);
        center.add(topControlCard, BorderLayout.NORTH);

        // Visual Seat Layout Card
        JPanel layoutCard = UITheme.createCardPanel();
        layoutCard.setLayout(new BorderLayout(10, 10));

        JLabel layoutTitle = new JLabel("Interactive Seating Chart");
        layoutTitle.setFont(UITheme.FONT_SUBTITLE);
        layoutTitle.setForeground(UITheme.TEXT_LIGHT);
        layoutCard.add(layoutTitle, BorderLayout.NORTH);

        seatGridPanel = new SeatGridPanel();
        seatGridPanel.setInteractive(false); // View only for admin check
        layoutCard.add(new JScrollPane(seatGridPanel), BorderLayout.CENTER);

        center.add(layoutCard, BorderLayout.CENTER);
        add(center, BorderLayout.CENTER);

        movieCombo.addActionListener(e -> onMovieChanged());
        showCombo.addActionListener(e -> onShowChanged());

        refreshData();
    }

    private JLabel createStatBadge(String title, String initialVal, Color accent) {
        JPanel badge = new JPanel(new GridLayout(2, 1, 2, 2));
        badge.setBackground(new Color(15, 23, 42));
        badge.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createMatteBorder(0, 4, 0, 0, accent),
                BorderFactory.createCompoundBorder(
                        BorderFactory.createLineBorder(UITheme.CARD_BORDER, 1),
                        BorderFactory.createEmptyBorder(10, 14, 10, 14)
                )
        ));

        JLabel valLbl = new JLabel(initialVal);
        valLbl.setFont(new Font("Segoe UI", Font.BOLD, 22));
        valLbl.setForeground(accent);

        JLabel titleLbl = new JLabel(title);
        titleLbl.setFont(UITheme.FONT_SMALL);
        titleLbl.setForeground(UITheme.TEXT_MUTED);

        badge.add(titleLbl);
        badge.add(valLbl);
        return valLbl;
    }

    public void refreshData() {
        try {
            movieList = bookingService.getAllMovies();
            DefaultComboBoxModel<MovieItem> model = new DefaultComboBoxModel<>();
            for (Movie m : movieList) {
                model.addElement(new MovieItem(m));
            }
            movieCombo.setModel(model);

            if (!movieList.isEmpty()) {
                onMovieChanged();
            } else {
                showCombo.setModel(new DefaultComboBoxModel<>());
                lblTotalSeats.setText("0");
                lblBookedSeats.setText("0");
                lblAvailableSeats.setText("0");
                seatGridPanel.buildGrid(50);
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Error fetching movies: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void onMovieChanged() {
        MovieItem item = (MovieItem) movieCombo.getSelectedItem();
        if (item == null) return;

        try {
            showList = bookingService.getShowsByMovieId(item.movie.getMovieId());
            DefaultComboBoxModel<ShowItem> model = new DefaultComboBoxModel<>();
            for (Show s : showList) {
                model.addElement(new ShowItem(s));
            }
            showCombo.setModel(model);

            if (!showList.isEmpty()) {
                onShowChanged();
            } else {
                lblTotalSeats.setText("0");
                lblBookedSeats.setText("0");
                lblAvailableSeats.setText("0");
                seatGridPanel.setBookedSeats(null);
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Error fetching shows: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void onShowChanged() {
        ShowItem item = (ShowItem) showCombo.getSelectedItem();
        if (item == null) return;

        try {
            Show show = bookingService.getShowById(item.show.getShowId());
            if (show == null) return;

            List<String> bookedSeats = bookingService.getBookedSeats(show.getShowId());
            int total = show.getTotalSeats();
            int bookedCount = bookedSeats.size();
            int available = Math.max(0, total - bookedCount);

            lblTotalSeats.setText(String.valueOf(total));
            lblBookedSeats.setText(String.valueOf(bookedCount));
            lblAvailableSeats.setText(String.valueOf(available));

            seatGridPanel.buildGrid(total);
            seatGridPanel.setBookedSeats(bookedSeats);
            seatGridPanel.setInteractive(false);
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Error querying seat status: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private static class MovieItem {
        final Movie movie;
        MovieItem(Movie movie) { this.movie = movie; }
        @Override
        public String toString() {
            return movie.getTitle();
        }
    }

    private static class ShowItem {
        final Show show;
        ShowItem(Show show) { this.show = show; }
        @Override
        public String toString() {
            return show.getShowDate() + " " + show.getShowTime() + " (₹" + show.getPrice() + ")";
        }
    }
}
