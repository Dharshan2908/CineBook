package gui;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.sql.SQLException;
import java.util.List;
import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JSplitPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.ListSelectionModel;
import javax.swing.table.DefaultTableModel;
import model.Movie;
import service.BookingService;
import util.ValidationUtil;

/**
 * Admin Panel: Movie Management.
 * Implements complete CRUD operations (Add, View, Update, Delete) for Movies.
 */
public class ManageMoviePanel extends JPanel {

    private final BookingService bookingService;
    private final JTable movieTable;
    private final DefaultTableModel tableModel;

    private final JTextField txtTitle;
    private final JTextField txtGenre;
    private final JTextField txtLanguage;
    private final JTextField txtDuration;

    private final JButton btnAdd;
    private final JButton btnUpdate;
    private final JButton btnDelete;
    private final JButton btnClear;

    private int selectedMovieId = -1;
    private List<Movie> movieList;

    public ManageMoviePanel(BookingService bookingService) {
        this.bookingService = bookingService;
        setLayout(new BorderLayout(14, 14));
        setBackground(UITheme.BG_DARK);
        setBorder(BorderFactory.createEmptyBorder(16, 16, 16, 16));

        // Top Header
        JPanel topHeader = new JPanel(new BorderLayout());
        topHeader.setBackground(UITheme.BG_DARK);
        JLabel title = UITheme.createHeaderLabel("🎬 Movie Catalog Management");
        JLabel sub = new JLabel("Add new films, update genres and runtimes, or remove movies safely from the database.");
        sub.setFont(UITheme.FONT_REGULAR);
        sub.setForeground(UITheme.TEXT_MUTED);
        topHeader.add(title, BorderLayout.NORTH);
        topHeader.add(sub, BorderLayout.SOUTH);
        add(topHeader, BorderLayout.NORTH);

        // Center Split: Left = Input Form, Right = JTable
        JPanel formCard = UITheme.createCardPanel();
        formCard.setLayout(new GridBagLayout());
        formCard.setPreferredSize(new Dimension(360, 480));

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.insets = new Insets(6, 8, 6, 8);
        gbc.weightx = 1.0;

        int row = 0;
        gbc.gridx = 0; gbc.gridy = row++;
        JLabel formHeading = new JLabel("Movie Details");
        formHeading.setFont(UITheme.FONT_SUBTITLE);
        formHeading.setForeground(UITheme.TEXT_LIGHT);
        formCard.add(formHeading, gbc);

        // Title
        gbc.gridy = row++;
        JLabel lblT = new JLabel("Movie Title:");
        lblT.setForeground(UITheme.TEXT_LIGHT);
        formCard.add(lblT, gbc);
        txtTitle = UITheme.createTextField(20);
        gbc.gridy = row++;
        formCard.add(txtTitle, gbc);

        // Genre
        gbc.gridy = row++;
        JLabel lblG = new JLabel("Genre:");
        lblG.setForeground(UITheme.TEXT_LIGHT);
        formCard.add(lblG, gbc);
        txtGenre = UITheme.createTextField(20);
        gbc.gridy = row++;
        formCard.add(txtGenre, gbc);

        // Language
        gbc.gridy = row++;
        JLabel lblL = new JLabel("Language:");
        lblL.setForeground(UITheme.TEXT_LIGHT);
        formCard.add(lblL, gbc);
        txtLanguage = UITheme.createTextField(20);
        gbc.gridy = row++;
        formCard.add(txtLanguage, gbc);

        // Duration
        gbc.gridy = row++;
        JLabel lblD = new JLabel("Duration (minutes):");
        lblD.setForeground(UITheme.TEXT_LIGHT);
        formCard.add(lblD, gbc);
        txtDuration = UITheme.createTextField(20);
        gbc.gridy = row++;
        formCard.add(txtDuration, gbc);

        // Button Panel
        gbc.gridy = row++;
        gbc.insets = new Insets(14, 8, 6, 8);
        JPanel btnPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 8, 6));
        btnPanel.setBackground(UITheme.CARD_BG);

        btnAdd = UITheme.createPrimaryButton("Add Movie");
        btnUpdate = UITheme.createSuccessButton("Update");
        btnDelete = UITheme.createDangerButton("Delete");
        btnClear = UITheme.createSecondaryButton("Clear");

        btnUpdate.setEnabled(false);
        btnDelete.setEnabled(false);

        btnPanel.add(btnAdd);
        btnPanel.add(btnUpdate);
        btnPanel.add(btnDelete);
        btnPanel.add(btnClear);
        formCard.add(btnPanel, gbc);

        // Right Table Card
        JPanel tableCard = UITheme.createCardPanel();
        tableCard.setLayout(new BorderLayout(8, 8));

        JPanel tableHeader = new JPanel(new BorderLayout());
        tableHeader.setBackground(UITheme.CARD_BG);
        JLabel tblTitle = new JLabel("All Registered Movies");
        tblTitle.setFont(UITheme.FONT_SUBTITLE);
        tblTitle.setForeground(UITheme.TEXT_LIGHT);
        tableHeader.add(tblTitle, BorderLayout.WEST);

        JButton refreshBtn = UITheme.createSecondaryButton("↻ Refresh Table");
        refreshBtn.addActionListener(e -> loadMovies());
        tableHeader.add(refreshBtn, BorderLayout.EAST);
        tableCard.add(tableHeader, BorderLayout.NORTH);

        String[] cols = {"Movie ID", "Title", "Genre", "Language", "Duration"};
        tableModel = new DefaultTableModel(cols, 0) {
            @Override
            public boolean isCellEditable(int row, int col) { return false; }
        };
        movieTable = new JTable(tableModel);
        UITheme.styleTable(movieTable);
        movieTable.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);

        tableCard.add(new JScrollPane(movieTable), BorderLayout.CENTER);

        // Split pane
        JSplitPane split = new JSplitPane(JSplitPane.HORIZONTAL_SPLIT, formCard, tableCard);
        split.setDividerLocation(380);
        split.setDividerSize(6);
        split.setBackground(UITheme.BG_DARK);
        add(split, BorderLayout.CENTER);

        // Actions
        btnAdd.addActionListener(e -> handleAddMovie());
        btnUpdate.addActionListener(e -> handleUpdateMovie());
        btnDelete.addActionListener(e -> handleDeleteMovie());
        btnClear.addActionListener(e -> clearForm());

        movieTable.getSelectionModel().addListSelectionListener(e -> {
            if (!e.getValueIsAdjusting()) {
                int rowIdx = movieTable.getSelectedRow();
                if (rowIdx >= 0 && movieList != null && rowIdx < movieList.size()) {
                    Movie m = movieList.get(rowIdx);
                    selectedMovieId = m.getMovieId();
                    txtTitle.setText(m.getTitle());
                    txtGenre.setText(m.getGenre());
                    txtLanguage.setText(m.getLanguage());
                    txtDuration.setText(String.valueOf(m.getDuration()));

                    btnAdd.setEnabled(false);
                    btnUpdate.setEnabled(true);
                    btnDelete.setEnabled(true);
                }
            }
        });

        loadMovies();
    }

    public void loadMovies() {
        try {
            movieList = bookingService.getAllMovies();
            tableModel.setRowCount(0);
            for (Movie m : movieList) {
                tableModel.addRow(new Object[]{
                        m.getMovieId(),
                        m.getTitle(),
                        m.getGenre(),
                        m.getLanguage(),
                        m.getDuration() + " mins"
                });
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Error fetching movies: " + e.getMessage(), "Database Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void handleAddMovie() {
        String title = txtTitle.getText().trim();
        String genre = txtGenre.getText().trim();
        String language = txtLanguage.getText().trim();
        String durationStr = txtDuration.getText().trim();

        if (ValidationUtil.isEmpty(title) || ValidationUtil.isEmpty(genre) || ValidationUtil.isEmpty(language)) {
            JOptionPane.showMessageDialog(this, "Title, Genre, and Language cannot be empty.", "Validation Error", JOptionPane.WARNING_MESSAGE);
            return;
        }

        if (!ValidationUtil.isPositiveInteger(durationStr)) {
            JOptionPane.showMessageDialog(this, "Duration must be a positive integer in minutes.", "Validation Error", JOptionPane.WARNING_MESSAGE);
            return;
        }

        int duration = Integer.parseInt(durationStr);

        try {
            boolean success = bookingService.addMovie(title, genre, language, duration);
            if (success) {
                JOptionPane.showMessageDialog(this, "Movie '" + title + "' added successfully!", "Success", JOptionPane.INFORMATION_MESSAGE);
                clearForm();
                loadMovies();
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Database error adding movie: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void handleUpdateMovie() {
        if (selectedMovieId <= 0) return;

        String title = txtTitle.getText().trim();
        String genre = txtGenre.getText().trim();
        String language = txtLanguage.getText().trim();
        String durationStr = txtDuration.getText().trim();

        if (ValidationUtil.isEmpty(title) || ValidationUtil.isEmpty(genre) || ValidationUtil.isEmpty(language)) {
            JOptionPane.showMessageDialog(this, "Title, Genre, and Language cannot be empty.", "Validation Error", JOptionPane.WARNING_MESSAGE);
            return;
        }

        if (!ValidationUtil.isPositiveInteger(durationStr)) {
            JOptionPane.showMessageDialog(this, "Duration must be a positive integer in minutes.", "Validation Error", JOptionPane.WARNING_MESSAGE);
            return;
        }

        int duration = Integer.parseInt(durationStr);

        try {
            boolean success = bookingService.updateMovie(selectedMovieId, title, genre, language, duration);
            if (success) {
                JOptionPane.showMessageDialog(this, "Movie #" + selectedMovieId + " updated successfully!", "Success", JOptionPane.INFORMATION_MESSAGE);
                clearForm();
                loadMovies();
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Database error updating movie: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void handleDeleteMovie() {
        if (selectedMovieId <= 0) return;

        int choice = JOptionPane.showConfirmDialog(this,
                "Are you sure you want to delete movie #" + selectedMovieId + " (" + txtTitle.getText() + ")?\n"
                        + "This operation will be rejected if existing shows reference this movie.",
                "Confirm Delete", JOptionPane.YES_NO_OPTION, JOptionPane.WARNING_MESSAGE);

        if (choice != JOptionPane.YES_OPTION) return;

        try {
            boolean success = bookingService.deleteMovie(selectedMovieId);
            if (success) {
                JOptionPane.showMessageDialog(this, "Movie #" + selectedMovieId + " was permanently deleted.", "Success", JOptionPane.INFORMATION_MESSAGE);
                clearForm();
                loadMovies();
            }
        } catch (IllegalStateException e) {
            JOptionPane.showMessageDialog(this, e.getMessage(), "Safety Restriction", JOptionPane.WARNING_MESSAGE);
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Database error deleting movie: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void clearForm() {
        selectedMovieId = -1;
        txtTitle.setText("");
        txtGenre.setText("");
        txtLanguage.setText("");
        txtDuration.setText("");
        movieTable.clearSelection();
        btnAdd.setEnabled(true);
        btnUpdate.setEnabled(false);
        btnDelete.setEnabled(false);
    }
}
