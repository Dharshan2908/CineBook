@echo off
echo ========================================================
echo Running CineBook Integration Tests...
echo ========================================================

java -cp "bin;lib/*" test.SystemWorkflowTest

pause
